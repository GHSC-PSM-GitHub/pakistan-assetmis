<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php include 'classes/config.php'; 
$whType = '';
$provId = '';
$distId = '';
$tehsilId = '';

$res3="SELECT
				Province.PkLocID,
				Province.LocName
			FROM
				tbl_locations AS Province
			WHERE
				Province.PkLocID = 3
			ORDER BY
				Province.PkLocID ASC";
$result4 = mysqli_query($conn, $res3);
$res3="SELECT
            locations.location_name,
            locations.geo_level_id,
            locations.pk_id
            FROM
                    locations
            WHERE
                    locations.province_id = 3
            AND locations.geo_level_id = 4";

$result5 = mysqli_query($conn, $res3);

if (isset($_POST['submit'])) {
    //Posted Data Collection
//    //get selected month
//    $selMonth = !empty($_REQUEST['ending_month']) ? $_REQUEST['ending_month'] : '';
//    //get selected year
//    $selYear = !empty($_REQUEST['year_sel']) ? $_REQUEST['year_sel'] : '';
//    //get warehouse type
//    $whType = !empty($_REQUEST['wh_type']) ? $_REQUEST['wh_type'] : '';
//    //get stakeholder of c level
//    $skOfcLvl = !empty($_REQUEST['SkOfcLvl']) ? $_REQUEST['SkOfcLvl'] : '';
//    //get province id
    $provId = !empty($_REQUEST['province']) ? $_REQUEST['province'] : '';
    //get district id
    $distId = !empty($_REQUEST['district']) ? $_REQUEST['district'] : '';
    //get tehsil id
    $tehsilId = !empty($_REQUEST['tehsil']) ? $_REQUEST['tehsil'] : '';
    //get uc id
    $ucId = !empty($_REQUEST['uc']) ? $_REQUEST['uc'] : '';
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
        
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
        <!-- Bootstrap CSS File  -->
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <style>
            .content {display:none;}
.preload { width:100px;
    height: 100px;
    position: fixed;
    top: 50%;
    left: 50%;}
        </style>
    </head>

    <body onload="fetch_data()">

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.php" class="logo">
                        <span>
                            <img src="assets/images/logo.png" alt="" >
                        </span>
                        <i>
                            <img src="assets/images/logo-sm.png" alt="" height="22">
                        </i>
                    </a>
                </div>

                <nav class="navbar-custom">
                    <ul class="navbar-right d-flex list-inline float-right mb-0">

                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="index.php" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="noti-icon"> <?php echo $_SESSION['username']; ?></i>
                                <!--<span class="badge badge-pill badge-info noti-icon-badge">3</span>-->
                            </a>
                        </li>
                        <li class="dropdown notification-list">
                            <div class="dropdown notification-list nav-pro-img">
                                <a class="dropdown-toggle nav-link arrow-none waves-effect nav-user waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                    <a class="dropdown-item" href="changepassword.php"><i style="font-size: 15px;" class="mdi mdi-account-circle m-r-5">Change Password</i> <?php // echo $_SESSION['username']; ?></a>
<!--                                    <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5"></i> My Wallet</a>
                                    <a class="dropdown-item d-block" href="#"><span class="badge badge-success float-right">11</span><i class="mdi mdi-settings m-r-5"></i> Settings</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-lock-open-outline m-r-5"></i> Lock screen</a>-->
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php"><i class="mdi mdi-power text-danger"></i> Logout</a>
                                </div>                                                                    
                            </div>
                        </li>

                    </ul>
                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>                        
                        <li class="d-none d-sm-block">
                            <div class="dropdown pt-3 d-inline-block">
                                <a class="waves-effect waves-light" href="#"  aria-haspopup="true" aria-expanded="false">
                                    <h4 style="color: white;">Configuration Management System</h4>
                                </a>
                                
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </li>
                    </ul>

                </nav>

            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'left_menu.php';?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">User Role Management</h4>
<!--                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Agroxa</a></li>
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Forms</a></li>
                                        <li class="breadcrumb-item active">Form Validation</li>
                                    </ol>-->
            
<!--                                    <div class="state-information d-none d-sm-block">
                                        <div class="state-graph">
                                            <div id="header-chart-1"></div>
                                            <div class="info">Balance $ 2,317</div>
                                        </div>
                                        <div class="state-graph">
                                            <div id="header-chart-2"></div>
                                            <div class="info">Item Sold 1230</div>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="page-content-wrapper">
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
            
                                            <!--<h4 class="mt-0 header-title">Range validation</h4>-->
                                            
<form method="POST" id="form_id" autocomplete="off">
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Role ID</label>
      <input type="text" name="role_id" placeholder="Auto Generated" class="form-control" id="role_id" readonly>
    </div>
      <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Role Name <span style="color:red;">*</span></label>
      <input type="text" name="role_name" placeholder="" class="form-control" id="role_name" required>
    </div>
<!--      <div class="col-md-4 mb-3">
      <label for="validationDefault01">Level <span style="color:red;">*</span></label>
      <input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>
    <select class="form-control mr-2" name="role_level" id="role_level">
        <option value='KP DOH' selected='selected'>KP DOH</option>
          <?php
//   $sel_query1 = "Select * FROM role_level";
//                    $result2 = mysqli_query($conn, $sel_query1);
//                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php //    echo '<option value="'.$row['id'].'">'.$row['role_level'].'</option>'; ?>
        
      <?php
//                    }
      ?>
        </select>
    </div>-->
      <!--<input type="hidden" id="id" name="id" value="">-->
<div class="col-md-4 mb-3">
        <div class="control-group">
            <label>Select Level</label>
            <div class="controls">
                <select name="wh_type" id="wh_type" class="form-control input-sm" required>
                    <option value="">Select</option>
                    <option value="2" <?php echo ($whType == 2) ? 'selected="selected"' : ''; ?>>Provincial</option>
                    <option value="3" <?php echo ($whType == 3) ? 'selected="selected"' : ''; ?>>District</option>
                    <option value="7" <?php echo ($whType == 7) ? 'selected="selected"' : ''; ?>>DHQ</option>
                    <option value="4" <?php echo ($whType == 4) ? 'selected="selected"' : ''; ?>>Tehsil</option>
                    <option value="5" <?php echo ($whType == 5) ? 'selected="selected"' : ''; ?>>UC</option>
                    <option value="6" <?php echo ($whType == 6) ? 'selected="selected"' : ''; ?>>HF</option>
                </select>
            </div>
        </div>
     </div>
  </div>
    <div class="form-row">
        <div class="col-md-4 mb-3" id="province_combo" style="display:none;">
    <div class="control-group">
        <label>Province/Region</label>
        <div class="controls">
            <select name="province" id="province" class="form-control input-sm">
                <option value="">Loading...</option>
                     <?php  
//                        while($row=mysqli_fetch_array($result4))
//            {
            ?>
            <!--<option value="<?php // echo $row['PkLocID'];?>"><?php // echo $row['LocName']; ?></option>-->
            <?php
//            }
            ?>   
            </select>
        </div>
    </div>
    </div>
        <div class="col-md-4 mb-3" id="district_combo" style="display:none;">
    <div class="control-group">
        <label>District</label>
        <div class="controls">
            <select name="district[]" id="district" multiple="multiple" class="form-control input-sm">
                <option value="">Loading...</option>
                     <?php  
                        while($row=mysqli_fetch_array($result5))
            {
            ?>
            <option value="<?php echo $row['pk_id'];?>"><?php echo $row['location_name']; ?></option>
            <?php
            }
            ?>   
            </select>
             <label class="control-label">
                <span class="">
                    <label class="text-danger">By press <b>CTRL</b> key you can select multiple values</label>
                    </span>
            </label>
        </div>
    </div>
    </div>
        <div class="col-md-4 mb-3" id="dhq_combo" style="display:none;">
            <div class="control-group">
                <label>DHQ</label>
                <div class="controls">
                    <select name="dhq[]" multiple="multiple" id="dhq" class="form-control input-sm">
                        <option value="">Loading...</option>
                    </select>
            <label class="control-label">
                <span class="">
                    <label class="text-danger">By press <b>CTRL</b> key you can select multiple values</label>
                    </span>
            </label>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3" id="tehsil_combo" style="display:none;">
            <div class="control-group">
                <label>Tehsil</label>
                <div class="controls">
                    <select name="tehsil[]" multiple="multiple" id="tehsil" class="form-control input-sm">
                        <option value="">Loading...</option>
                    </select>
            <label class="control-label">
                <span class="">
                    <label class="text-danger">By press <b>CTRL</b> key you can select multiple values</label>
                    </span>
            </label>
                </div>
            </div>
        </div>
    </div>
    <div class="form-row">
        <div class="col-md-4 mb-3" id="uc_combo" style="display:none;">
    <div class="control-group">
        <label>UC</label>
        <div class="controls">
            <select name="uc[]" id="uc" multiple="multiple" class="form-control input-sm">
                <option value="">Loading...</option>
                     <?php  
//                        while($row=mysqli_fetch_array($result5))
//            {
            ?>
            <!--<option value="<?php // echo $row['PkLocID'];?>"><?php // echo $row['LocName']; ?></option>-->
            <?php
//            }
            ?>   
            </select>
            <label class="control-label">
                <span class="">
                    <label class="text-danger">By press <b>CTRL</b> key you can select multiple values</label>
                    </span>
            </label>
        </div>
    </div>
    </div>
        <div class="col-md-4 mb-3" id="hf_combo" style="display:none;">
    <div class="control-group">
        <label>HF</label>
        <div class="controls">
            <select name="hf[]" id="hf" multiple="multiple" class="form-control input-sm">
                <option value="">Loading...</option>
                     <?php  
//                        while($row=mysqli_fetch_array($result5))
//            {
            ?>
            <!--<option value="<?php // echo $row['PkLocID'];?>"><?php // echo $row['LocName']; ?></option>-->
            <?php
//            }
            ?>   
            </select>
            <label class="control-label">
                <span class="">
                    <label class="text-danger">By press <b>CTRL</b> key you can select multiple values</label>
                    </span>
            </label>
        </div>
    </div>
    </div>
    </div>
    
    <div class="form-row">
        <div class="col-md-4 mb-3" id="access_combo">
    <div class="control-group">
        <label>Access</label>
        <div class="controls">
            <select name="access" id="access" class="form-control input-sm" required>
                     <?php  
                     $res="SELECT
                                access.id,
                                access.access_name
                                FROM
                                access
                                ";
$results = mysqli_query($conn, $res);
                        while($row=mysqli_fetch_array($results))
            {
            ?>
            <option value="<?php echo $row['id'];?>"><?php echo $row['access_name']; ?></option>
            <?php
            }
            ?>   
            </select>
        </div>
    </div>
    </div>
        
    </div>
    
            <input type="hidden" id="id" name="id" value="">
          <div class="modal-footer">
              <button type="submit" href="#lab_history" id="add" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Add</button>
            <a href="role_mang.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
<!--                                            <h3>Records:</h3>-->
<br>
          <i id="btnExport" onclick="fnExcelReport();" class="fa fa-file-excel-o" style="font-size:32px;color:#33B23F;float: right;"></i>
          <br>
                                            <!--<h3>Records:</h3>-->
            <div id="restrict" style="color:red;text-align: center;"><h3>You have not access to add new Role!</h3></div>
            <div id="error" style="color:red;text-align: center;"><h3>This Role Already Exist!</h3></div>
            <div id="insert" style="color:#33B23F;text-align: center;"><h3>Data Inserted successfully!</h3></div>
            <div id="update" style="color:#33B23F;text-align: center;"><h3>Data Update successfully!</h3></div>
            <div class="check">
                <div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
                </div>
                <div class="content" id="all_data">

                        </div>
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->  
                        </div>
                        <!-- end page content-->

                    </div> <!-- container-fluid -->

                </div> <!-- content -->

                <footer class="footer">
                    <!--© 2018 Agroxa <span class="d-none d-sm-inline-block">- Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand.</span>-->
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- Parsley js -->
        <script src="../plugins/parsleyjs/parsley.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script src="js/script.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
        <script>
            $("#error").hide();
            $("#restrict").hide();
            $("#insert").hide();
            $("#update").hide();
            $(document).ready(function() {
    $(".preload").fadeOut(1000, function() {
        $(".content").fadeIn(500);        
    });
    });
            
            $(document).ready(function() {
            $('#district').multiselect({
    columns: 1,
    placeholder: 'Select',
    search: true
    });
});
 $(document).ready(function() {
            $('#tehsil').multiselect({
    columns: 1,
    placeholder: 'Select',
    search: true
    });
});
 $(document).ready(function() {
            $('#uc').multiselect({
    columns: 1,
    placeholder: 'Select',
    search: true
    });
});
 $(document).ready(function() {
            $('#hf').multiselect({
    columns: 1,
    placeholder: 'Select',
    search: true
    });
});
 $(document).ready(function() {
            $('#dhq').multiselect({
    columns: 1,
    placeholder: 'Select',
    search: true
    });
});
            $(document).ready(function() {
                $('form').parsley();
            });
             
            $(function() {
<?php if (isset($_POST['submit'])) { ?>
                officeType('<?php echo $whType; ?>');
                showProv('<?php echo $whType; ?>');
                showDistricts('<?php echo $provId; ?>');
<?php } ?>
             
//             $('.updatebtn').click(function() {
//                var whType = $('#wh_type').val();
////                alert(whType);
//                $('#district_combo').fadeOut();
//                    $('#district').empty();
//                    $('#tehsil_combo').fadeOut();
//                    $('#tehsil').empty();
//                    $('#uc_combo').fadeOut();
//                    $('#uc').empty();
////                officeType(whType);
//            });
                
                
            $('#wh_type').change(function() {
                var whType = $(this).val();
                officeType(whType);
            });
            $('#province').change(function() {
                var provId = $(this).val();
//                alert(provId);
                if (provId != 'all')
                {
//                    alert(provId);
                    showDistricts(provId);
                }
                else
                {
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                    $('#dhq_combo').fadeOut();
                    $('#dhq').empty();
                }
            });
            $('#district').click(function() {
                var dist = [];
                dist = $('#district').val();
//                alert(selected);
                var prov = $('#province').val();
//                var dist = $(this).val();
//                alert(prov,dist);
                if (dist != 'all')
                {
                    showDhq(prov,dist);
                    showTehsil(prov,dist);
                }
                else
                {
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                    $('#dhq_combo').fadeOut();
                    $('#dhq').empty();
                    
                }
            });
//            $('#dhq').change(function() {
//                var prov = $('#province').val();
//                var dist = $('#district').val();
//                var tehsil = $(this).val();
//                if (tehsil != 'all')
//                {
//                    showUC(prov,dist,tehsil);
//                }
//                else
//                {
//                    $('#uc_combo').fadeOut();
//                    $('#uc').empty();
//                    $('#hf_combo').fadeOut();
//                    $('#hf').empty();
//                    
//                }
//            });
            $('#tehsil').change(function() {
                var prov = $('#province').val();
                var dist = $('#district').val();
                var tehsil = $(this).val();
                if (tehsil != 'all')
                {
                    showUC(prov,dist,tehsil);
                }
                else
                {
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                    
                }
            });
            $('#uc').change(function() {
                var prov = $('#province').val();
                var dist = $('#district').val();
                var tehsil = $('#tehsil').val();
                var uc = $(this).val();
                if (uc != 'all')
                {
                    showHF(prov,dist,tehsil,uc);
                }
                else
                {
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                }
            });
});
        function officeType(whType)
        {
            if (whType == '')
            {
                $('#province_combo').fadeOut();
                $('#province').empty();
                $('#district_combo').fadeOut();
                $('#district').empty();
                $('#tehsil_combo').fadeOut();
                $('#tehsil').empty();
                $('#uc_combo').fadeOut();
                $('#uc').empty();
                $('#hf_combo').fadeOut();
                $('#hf').empty();
                $('#dhq_combo').fadeOut();
                $('#dhq').empty();
            }
            else if (whType == 2)
                {
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                    $('#dhq_combo').fadeOut();
                    $('#dhq').empty();
                }
                else if (whType == 3)
                {
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                    $('#dhq_combo').fadeOut();
                    $('#dhq').empty();
                }
                else if (whType == 4)
                {
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                    $('#dhq_combo').fadeOut();
                    $('#dhq').empty();
                }
                else if (whType == 5)
                {
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                    $('#dhq_combo').fadeOut();
                    $('#dhq').empty();
                }
                else if (whType == 6)
                {
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                    $('#dhq_combo').fadeOut();
                    $('#dhq').empty();
                }
                else if (whType == 7)
                {
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
                    $('#dhq_combo').fadeOut();
                    $('#dhq').empty();
                }
                showProv(whType);
//            }
        }
        function showProv(whType)
        {
            if (whType != 1)
            {
                $('#province_combo').fadeIn();
                $('#province').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provSelId: '<?php echo $provId; ?>'},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#province').html(data);
                        var selProv = $('#province').val();
                        if (selProv != 'all')
                        {
                            showDistricts(selProv);
                        }
                    }
                });
            }
        }
        function showDistricts(provId)
        {
            var whType = $('#wh_type').val();
//            alert(whType);
            if (whType == 3 || whType == 4 || whType == 5 || whType == 6 || whType == 7)
            {
                $('#district_combo').fadeIn();
                $('#district').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provId: provId, distSelId: '<?php echo $distId; ?>'},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#district').html(data);
                    }
                });
            }
        }
        function showDhq(prov,dist)
        {
            var whType = $('#wh_type').val();
//            alert(whType);
            if (whType == 7)
            {
                $('#dhq_combo').fadeIn();
                $('#dhq').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provId: prov, distSelId: dist},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#dhq').html(data);
                    }
                });
            }
        }
        function showTehsil(prov,dist)
        {
//            alert(dist);
            var whType = $('#wh_type').val();
            if (whType == 4 || whType == 5 || whType == 6)
            {
                $('#tehsil_combo').fadeIn();
                $('#tehsil').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provId: prov, distSelId: dist},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#tehsil').html(data);
                    }
                });
            }
        }
        function showUC(prov,dist,tehsil)
        {
            var whType = $('#wh_type').val();
            if (whType == 5 || whType == 6)
            {
                $('#uc_combo').fadeIn();
                $('#uc').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provId: prov, distSelId: dist,tehSelId : tehsil},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#uc').html(data);
                    }
                });
            }
        }
        function showHF(prov,dist,tehsil,uc)
        {
            var whType = $('#wh_type').val();
            if (whType == 6)
            {
                $('#hf_combo').fadeIn();
                $('#hf').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provId: prov, distSelId: dist,tehSelId : tehsil,ucSelId : uc},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#hf').html(data);
                    }
                });
            }
        }
            
            
            
            
            function showProvUpdate(whType,dist)
        {
            if (whType != 1)
            {
                $('#province_combo').fadeIn();
                $('#province').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provSelId: '<?php echo $provId; ?>'},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#province').html(data);
                        var selProv = $('#province').val();
                        if (selProv != 'all')
                        {
                            showDistrictsUpdate(selProv,dist);
                        }
                    }
                });
            }
        }
        function showDistrictsUpdate(provId,dist)
        {
            var whType = $('#wh_type').val();
//            alert(whType);
            if (whType == 3 || whType == 4 || whType == 5 || whType == 6)
            {
                $('#district_combo').fadeIn();
                $('#district').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provId: provId, distSelId: '<?php echo $distId; ?>'},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#district').html(data);
                        var selectedOptions = dist.toString().split(",");
                            for(var i in selectedOptions) {
                                var optionVal = selectedOptions[i];
//                                alert(optionVal);
                                $("select").find("option[value="+optionVal+"]").prop("selected", "selected");
                            }
//                            $("select").multiselect('refresh');
                    }
                });
            }
        }
        function showTehsilUpdate(prov,dist,tehsil)
        {
//            alert(dist);
            var whType = $('#wh_type').val();
            if (whType == 4 || whType == 5 || whType == 6)
            {
                $('#tehsil_combo').fadeIn();
                $('#tehsil').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provId: prov, distSelId: dist},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#tehsil').html(data);
                        var selectedOptions = tehsil.toString().split(",");
                            for(var i in selectedOptions) {
                                var optionVal = selectedOptions[i];
//                                alert(optionVal);
                                $("select").find("option[value="+optionVal+"]").prop("selected", "selected");
                            }
//                            $("select").multiselect('refresh');
                    }
                });
            }
        }
//        function showwhTypeUpdate(whtypeid)
//        {
//            var whType = $('#wh_type').val();
////            alert(whType);
//            if (whType == 4 || whType == 5 || whType == 6 || (whType == 3 && $("#whid").val() != ''))
//            {
//                $('#dhq_combo').fadeIn();
//                $('#district').html('<option value="">Loading...</option>');
//                $.ajax({
//                    type: "POST",
//                    url: "ajax/ajax_combos.php",
//                    data: {SkOfcLvl: whType, provId: provId, distSelId: '<?php echo $distId; ?>'},
//                    dataType: 'html',
//                    success: function(data)
//                    {
//                        $('#dhq_combo').html(data);
//                        $('#district').val(distid);
//                    }
//                });
//            }
//                $('#dhq_combo').fadeIn();
//                $('#dhq').val(whtypeid);
//        }
        function showUCUpdate(prov,dist,tehsil,uc)
        {
            var whType = $('#wh_type').val();
            if (whType == 5 || whType == 6)
            {
                $('#uc_combo').fadeIn();
                $('#uc').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provId: prov, distSelId: dist,tehSelId : tehsil},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#uc').html(data);
//                        $('#uc').html(uc);
                        var selectedOptions = uc.toString().split(",");
                            for(var i in selectedOptions) {
                                var optionVal = selectedOptions[i];
//                                alert(optionVal);
                                $("select").find("option[value="+optionVal+"]").prop("selected", "selected");
                            }
//                            $("select").multiselect('refresh');
                    }
                });
            }
        }
        function showHFUpdate(prov,dist,uc,hf)
        {
            var whType = $('#wh_type').val();
            if (whType == 6)
            {
                $('#hf_combo').fadeIn();
                $('#hf').html('<option value="">Loading...</option>');
                $.ajax({
                    type: "POST",
                    url: "ajax/ajax_role_combos.php",
                    data: {SkOfcLvl: whType, provId: prov, distSelId: dist,ucSelId : uc},
                    dataType: 'html',
                    success: function(data)
                    {
                        $('#hf').html(data);
                        var selectedOptions = hf.toString().split(",");
                            for(var i in selectedOptions) {
                                var optionVal = selectedOptions[i];
                                $("select").find("option[value="+optionVal+"]").prop("selected", "selected");
                            }
////                            $("select").multiselect('refresh');
                    }
                });
            }
        }
        
        
        
        $(document).ready(function(){
   
 $('#form_id').on('submit', function(event){
//     var id = $('#id').val();
  event.preventDefault();
  $.ajax({
   url:"role_management.php",
   method:"POST",
   data:$(this).serialize(),
   success:function(data){
       fetch_data();
//       alert(id);
var user = JSON.parse(data);
//alert(user.match);
        if(user.match == '1' || user.match == '0')
       {
            $("#error").show();
             setTimeout(function() { $("#error").hide(); }, 3000);
       }else 
           if(user.match == '2')
       {
            $("#restrict").show();
             setTimeout(function() { $("#restrict").hide(); }, 3000);
        }
       else 
           if(user.chkid == 0)
       {
            $("#insert").show();
             setTimeout(function() { $("#insert").hide(); }, 3000);
        }
        else
        {
            $("#update").show();
            setTimeout(function() { $("#update").hide(); }, 3000);
        }
    },
   Error:function(data){
       alert("Failed to Insert the data");
   }
  });
 });
});
  
  function fetch_data(){
    var operations = "fetching_the_data";
    $.ajax({
       type:"POST",
       url:"role_management.php",
       data:{operation:operations},
       success:function(data)
       {
           $("#all_data").html(data);
       },
       Error:function(data)
       {
           alert("Failed to retrieve");
       }
    });
}

  
function fnExcelReport()
{
    var tab_text="<table border='2px'><tr bgcolor='#33B23F'>";
    var textRange; var j=0;
    tab = document.getElementById('example'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}

        </script>
    
    </body>

</html>

