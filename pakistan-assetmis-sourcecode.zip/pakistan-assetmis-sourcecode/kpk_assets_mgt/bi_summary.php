<?php include 'classes/config.php';

$result = "SELECT
IFNULL(
	asset_info.asset_name,
	'No Name'
) Asset_Name,
IFNULL(
	category.`name`,
	'No Category'
) Category,
IFNULL(
	warehouses.warehouse_name,
	'Not Assigned'
) Organization,
IFNULL(
	asset_info.purchase_price,
	0
) Total_Cost,
IFNULL(
	asset_info.purchase_year,
	2000
) Purchase_Year,
IFNULL(asset_info.expire_years, 5) Expiry_Year,
IFNULL(
	asset_info.purchase_warranty,
	12
) Purchase_Warranty
FROM
asset_info
INNER JOIN category ON asset_info.category_id = category.id
LEFT JOIN warehouses ON asset_info.asset_location = warehouses.pk_id LIMIT 10";
$result = mysqli_query($conn, $result);

$data = array();
if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
		$data[] = $row;
	}
}

echo json_encode($data);