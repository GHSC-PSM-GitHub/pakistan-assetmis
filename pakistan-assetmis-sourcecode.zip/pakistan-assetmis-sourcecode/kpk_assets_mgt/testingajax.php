<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }

    include 'classes/config.php';
//    $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
//                        $last_id = $row['MAX(id)'];
//                    }
//      if(isset($_REQUEST['org_name'])) {

    //get the name and comment entered by user
    $name = $_REQUEST['org_name'];
//    $level = $_POST['wh_type'];
                if($_REQUEST['wh_type'] == '2')
                {
                    $org_level = 2;
//                    $prov = $_REQUEST['province'];
//                $dist = $_REQUEST['district'];
//                $tehsil = $_REQUEST['tehsil'];
//                    $uid = 3;
                }
                else if($_REQUEST['wh_type'] == '3')
                {
                    $org_level = 4;
                    $prov = $_REQUEST['province'];
//                $dist = $_REQUEST['district'];
//                $tehsil = $_REQUEST['tehsil'];
//                    $uid = 4;
                }
                else if($_REQUEST['wh_type'] == '4')
                {
                    $org_level = 5;
                    $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
//                $tehsil = $_REQUEST['tehsil'];
//                    $uid = 5;
                }
                else if($_REQUEST['wh_type'] == '5')
                {
                    $org_level = 6;
                    $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
                $tehsil = $_REQUEST['tehsil'];
//                    $uid = 5;
                }
                else if($_REQUEST['wh_type'] == '6')
                {
                    $org_level = 6;
                    $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
                $uc = $_REQUEST['uc'];
//                    $uid = 5;
                }
    //connect to the database
//    $dbc = mysqli_connect('host', 'username', 'password', 'dbname') or die('Error connecting to MySQL server');
    if($org_level == 2)
    {
        $check=mysqli_query($conn,"select * from locations where location_name='$name' && geo_level_id = '$org_level'");
    }
    if($org_level == 4)
    {
        $check=mysqli_query($conn,"select * from locations where location_name='$name' && geo_level_id = '$org_level' && province_id = '$prov'");
    }
    if($org_level == 5)
    {
        $check=mysqli_query($conn,"select * from locations where location_name='$name' && geo_level_id = '$org_level' && province_id = '$prov' && district_id = '$dist'");
    }
    if($org_level == 6 && isset($tehsil) && !empty($tehsil) && !isset($uc) && empty($uc))
    {
        $check=mysqli_query($conn,"select * from locations where location_name='$name' && geo_level_id = '$org_level' && province_id = '$prov' && district_id = '$dist' && parent_id = '$tehsil'");
    }
    else if($org_level == 6 && isset($uc) && !empty($uc))
    {
        $check=mysqli_query($conn,"select * from warehouses where warehouse_name='$name' && stakeholder_office_id = '$org_level'  && province_id = '$prov' && district_id = '$dist' && location_id = '$uc'");
    }
    $checkrows=mysqli_num_rows($check);


       
    if(empty($_REQUEST['uc']) && empty($_REQUEST['id']) && empty($_REQUEST['whid']) && empty($_REQUEST['sel_opt']) && empty($_REQUEST['sel_teh']) && (isset($_REQUEST['tehsil']) || isset($_REQUEST['district']) || isset($_REQUEST['province'])))
    {
        
        
        
        $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else 
   {
//		$org_code = $_REQUEST['org_code'];
                $org_name = $_REQUEST['org_name'];
//                $org_level = $_REQUEST['wh_type'];
                $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
                $tehsil = $_REQUEST['tehsil'];
                if($_REQUEST['wh_type'] == '2')
                {
                    $org_level = 2;
                }
                else if($_REQUEST['wh_type'] == '3')
                {
                    $org_level = 4;
//                    $uid = 4;
                }
                else if($_REQUEST['wh_type'] == '4')
                {
                    $org_level = 5;
//                    $uid = 5;
                }
                else if($_REQUEST['wh_type'] == '5')
                {
                    $org_level = 6;
//                    $uid = 5;
                }
//                else if($_REQUEST['wh_type'] == '6')
//                {
//                    $org_level = 7;
////                    $uid = 5;
//                }
                $uid = $org_level-1;
//                $tehsil = $_REQUEST['uc'];
                if(empty($tehsil) || $tehsil=='' || !isset($tehsil)){
                    $tehsil='0';
                }
                if(empty($dist) || $dist=='' || !isset($dist)){
                    $dist='0';
                }
                $query = "INSERT INTO locations (location_name,geo_level_id,id_for_update,province_id,district_id,parent_id,status)
                VALUES ('$org_name', '$org_level','$uid','$prov','$dist','$tehsil','1')";
//		$query = "UPDATE tbl_locations SET code='$org_code',LocName='$org_name',LocLvl='$org_level',prov_id='$prov',dist_id='$dist' WHERE PkLocID=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
                }
                $response   =   array("chkid"=>"0");
                echo json_encode($response);
	}
        
    }
        if(isset($_REQUEST['sel_opt']) && !empty($_REQUEST['sel_opt']) && empty($_REQUEST['whid']) && empty($_REQUEST['tehsil']))
    {
            $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else {
//		$org_code = $_REQUEST['org_code'];
                $org_name = $_REQUEST['org_name'];
//                $org_level = $_REQUEST['wh_type'];
                $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
//                $uc = $_REQUEST['uc'];
                if($_REQUEST['wh_type'] == '2')
                {
                    $org_level = 4;
                }
                else if($_REQUEST['wh_type'] == '3')
                {
                    $org_level = 5;
                }
                else if($_REQUEST['wh_type'] == '4')
                {
                    $org_level = 6;
                }
//                $tehsil = $_REQUEST['uc'];
                $query = "INSERT INTO warehouses (warehouse_name,province_id,district_id,location_id,stakeholder_office_id,status)
                VALUES ('$org_name','$prov','$dist','$dist','4','1')";
//		$query = "UPDATE tbl_locations SET code='$org_code',LocName='$org_name',LocLvl='$org_level',prov_id='$prov',dist_id='$dist' WHERE PkLocID=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
                }
                $response   =   array("chkid"=>"0");
                echo json_encode($response);
	}
    }
         if(isset($_REQUEST['sel_teh']) && !empty($_REQUEST['sel_teh']) && empty($_REQUEST['whid']) && empty($_REQUEST['uc']))
    {
             
             $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else {
//		$org_code = $_REQUEST['org_code'];
                $org_name = $_REQUEST['org_name'];
//                $org_level = $_REQUEST['wh_type'];
                $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
                $tehsil = $_REQUEST['tehsil'];
//                $uc = $_REQUEST['uc'];
                if($_REQUEST['wh_type'] == '2')
                {
                    $org_level = 4;
                }
                else if($_REQUEST['wh_type'] == '3')
                {
                    $org_level = 5;
                }
                else if($_REQUEST['wh_type'] == '4')
                {
                    $org_level = 6;
                }
//                $tehsil = $_REQUEST['uc'];
                $query = "INSERT INTO warehouses (warehouse_name,province_id,district_id,location_id,stakeholder_office_id,status)
                VALUES ('$org_name','$prov','$dist','$tehsil','5','1')";
//		$query = "UPDATE tbl_locations SET code='$org_code',LocName='$org_name',LocLvl='$org_level',prov_id='$prov',dist_id='$dist' WHERE PkLocID=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
                }
                $response   =   array("chkid"=>"0");
                echo json_encode($response);
	}
    }
        if(isset($_REQUEST['uc']) && !empty($_REQUEST['uc']) && empty($_REQUEST['whid']))
    {
            $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else {
//		$org_code = $_REQUEST['org_code'];
                $org_name = $_REQUEST['org_name'];
//                $org_level = $_REQUEST['wh_type'];
                $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
                $uc = $_REQUEST['uc'];
                if($_REQUEST['wh_type'] == '2')
                {
                    $org_level = 4;
                }
                else if($_REQUEST['wh_type'] == '3')
                {
                    $org_level = 5;
                }
                else if($_REQUEST['wh_type'] == '4')
                {
                    $org_level = 6;
                }
//                $tehsil = $_REQUEST['uc'];
                $query = "INSERT INTO warehouses (warehouse_name,province_id,district_id,location_id,stakeholder_office_id,status)
                VALUES ('$org_name','$prov','$dist','$uc','6','1')";
//		$query = "UPDATE tbl_locations SET code='$org_code',LocName='$org_name',LocLvl='$org_level',prov_id='$prov',dist_id='$dist' WHERE PkLocID=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
                }
         $response   =   array("chkid"=>"0");
       echo json_encode($response);
        }
    }
            if(isset($_REQUEST['id']) && !empty($_REQUEST['id']))
    {
                $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else {
       
                $id = $_REQUEST['id'];
//		$org_code = $_REQUEST['org_code'];
                $org_name = $_REQUEST['org_name'];
//                $org_level = $_REQUEST['wh_type'];
                $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
                $tehsil = $_REQUEST['tehsil'];
                if($_REQUEST['wh_type'] == '2')
                {
                    $org_level = 2;
                    $uid = 2;
                }
                else if($_REQUEST['wh_type'] == '3')
                {
                    $org_level = 4;
                    $uid = 3;
                }
                else if($_REQUEST['wh_type'] == '4')
                {
                    $org_level = 5;
                    $uid = 4;                    
                }
                else if($_REQUEST['wh_type'] == '5')
                {
                    $org_level = 6;
                    $uid = 5;                    
                }
//                $u1 = $org_level-1;
                
//                $tehsil = $_REQUEST['uc'];
                if(empty($tehsil) || $tehsil=='' || !isset($tehsil)){
                    $tehsil='0';
                }
                if(empty($dist) || $dist=='' || !isset($dist)){
                    $dist='0';
                }
               $query = "UPDATE locations SET location_name='$org_name',geo_level_id='$org_level',parent_id='$tehsil',province_id='$prov',district_id='$dist',id_for_update='$uid' WHERE pk_id=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
         $response   =   array("chkid"=>"1");
       echo json_encode($response);
    }
}
         if(isset($_REQUEST['whid']) && !empty($_REQUEST['whid']) && !empty($_REQUEST['tehsil']) && !empty($_REQUEST['uc']))
    {
             $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else {
                $id = $_REQUEST['whid'];
//		$org_code = $_REQUEST['org_code'];
                $org_name = $_REQUEST['org_name'];
//                $org_level = $_REQUEST['wh_type'];
                $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
                $uc = $_REQUEST['uc'];
                if($_REQUEST['wh_type'] == '2')
                {
                    $org_level = 2;
                    $uid = 2;
                }
                else if($_REQUEST['wh_type'] == '3')
                {
                    $org_level = 4;
                    $uid = 3;
                }
                else if($_REQUEST['wh_type'] == '4')
                {
                    $org_level = 5;
                    $uid = 4;                    
                }
//                $u1 = $org_level-1;
                
//                $tehsil = $_REQUEST['uc'];
               $query = "UPDATE warehouses SET warehouse_name='$org_name',location_id='$uc',province_id='$prov',district_id='$dist' WHERE pk_id=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
         $response   =   array("chkid"=>"1");
       echo json_encode($response);
    }
}
         if(isset($_REQUEST['whid']) && !empty($_REQUEST['whid']) && empty($_REQUEST['tehsil']))
    {
             $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else {
                $id = $_REQUEST['whid'];
//		$org_code = $_REQUEST['org_code'];
                $org_name = $_REQUEST['org_name'];
//                $org_level = $_REQUEST['wh_type'];
                $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
//                $uc = $_REQUEST['uc'];
                if($_REQUEST['wh_type'] == '2')
                {
                    $org_level = 2;
                    $uid = 2;
                }
                else if($_REQUEST['wh_type'] == '3')
                {
                    $org_level = 4;
                    $uid = 3;
                }
                else if($_REQUEST['wh_type'] == '4')
                {
                    $org_level = 5;
                    $uid = 4;                    
                }
//                $u1 = $org_level-1;
                
//                $tehsil = $_REQUEST['uc'];
               $query = "UPDATE warehouses SET warehouse_name='$org_name',location_id='$dist',province_id='$prov',district_id='$dist' WHERE pk_id=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
         $response   =   array("chkid"=>"1");
       echo json_encode($response);
    }
}
        if(isset($_REQUEST['whid']) && !empty($_REQUEST['whid']) && !empty($_REQUEST['tehsil']) && empty($_REQUEST['uc']))
    {
            $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else {
                $id = $_REQUEST['whid'];
//		$org_code = $_REQUEST['org_code'];
                $org_name = $_REQUEST['org_name'];
//                $org_level = $_REQUEST['wh_type'];
                $prov = $_REQUEST['province'];
                $dist = $_REQUEST['district'];
                $tehsil = $_REQUEST['tehsil'];
                if($_REQUEST['wh_type'] == '2')
                {
                    $org_level = 2;
                    $uid = 2;
                }
                else if($_REQUEST['wh_type'] == '3')
                {
                    $org_level = 4;
                    $uid = 3;
                }
                else if($_REQUEST['wh_type'] == '4')
                {
                    $org_level = 5;
                    $uid = 4;                    
                }
//                $u1 = $org_level-1;
                
//                $tehsil = $_REQUEST['uc'];
               $query = "UPDATE warehouses SET warehouse_name='$org_name',location_id='$tehsil',province_id='$prov',district_id='$dist' WHERE pk_id=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
         $response   =   array("chkid"=>"1");
       echo json_encode($response);
    }
}
?>
<?php
if(isset($_POST['operation']))
{ 
    ?>
 <table id="example" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Name</th>
                                                        <th>Level</th>
                <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '')
        {
            ?>
                                                        <th>Action</th>
                                                        <th>Status</th>
                <?php }
                ?>
                                                </tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                locations.pk_id,
                                                                locations.location_name,
                                                                locations.geo_level_id,
                                                                locations.parent_id,
                                                                locations.location_type_id,
                                                                locations.province_id,
                                                                locations.district_id,
                                                                locations.`status`,
                                                                geo_levels.geo_level_name
                                                        FROM
                                                                locations
                                                        INNER JOIN geo_levels ON geo_levels.pk_id = locations.geo_level_id
                                                        WHERE
                                                                locations.province_id = 3
                                                                ";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <!--<td><?php // echo $row['code']; ?></td>-->
            <td><?php echo $row['location_name']; ?></td>
            <td><?php echo $row['geo_level_name']; ?></td>
    <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '')
        {
    ?>
            <td>
                    <button id="<?php echo $row["pk_id"]; ?>" onclick="edit_organization_detail(this.id)" class="btn btn-success updatebtn">Update</button>
            </td>
            <td>
               <?php if($row['status'] == 1)
               {?>
                <button onclick="activeorganization(<?php echo $row['pk_id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactiveorganization(<?php echo $row['pk_id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>
    <?php }
    ?>
    		</tr>
<?php
$number++;
        }
    }
?>

                  <?php
                                                $query = "SELECT
                                                            warehouses.warehouse_name,
                                                            warehouses.location_id,
                                                            warehouses.district_id,
                                                            warehouses.province_id,
                                                            warehouses.pk_id,
                                                            warehouses.status
                                                            FROM
                                                            warehouses
                                                            INNER JOIN locations ON locations.pk_id = warehouses.location_id
                                                            WHERE
                                                            warehouses.province_id = 3 AND
                                                            warehouses.stakeholder_office_id IN (4,5,6)
                                                        ";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
//    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <!--<td><?php // echo $row['code']; ?></td>-->
            <td><?php echo $row['warehouse_name']; ?></td>
            <td><?php echo 'HF'; ?></td>
            <td>
                    <button id="<?php echo $row["pk_id"]; ?>" onclick="edit_organization_detail_hf(this.id)" class="btn btn-success updatebtn">Update</button>
            </td>
            <td>
               <?php if($row['status'] == 1)
               {?>
                <button onclick="activeorganizationwh(<?php echo $row['pk_id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactiveorganizationwh(<?php echo $row['pk_id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>
    		</tr>
<?php
$number++;
        }
    }
?>
        </tbody>
             </table>
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
    </script>

<?php
}    
?>