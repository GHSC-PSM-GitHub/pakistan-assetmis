<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php include 'classes/config.php'; 
// session_start();
$id = '';
$mindate = date('y-m-d');
if(isset($_REQUEST['id']) && $_REQUEST['id'] != '')
    {
        $id = $_REQUEST['id'];
    }
      
 $currently_selected = date('Y'); 
  // Year to start available options at
  $earliest_year = 1990; 
  // Set your latest year you want in the range, in this case we use PHP to just set it to the current year.
  $latest_year = date('Y'); 

?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">
         
        <link href="plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">

        <link href="plugins/bootstrap-md-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">

        <link href="plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" >
        <link href="plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" >
        
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <!-- Bootstrap CSS File  -->
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            .navbar{
               background:  #6BA2D2;
               color: white;
            }
        </style>
    </head>
    <?php
$districid='';
if (isset($_SESSION['did']) && $_SESSION['did'] != ''){
    $districid=" AND warehouses.district_id IN (". implode(', ',(array)$_SESSION['did']).")";
}
$thid='';
if ($_SESSION['tid'] != '' && $_SESSION['tid'] != 'NULL'){
    $thid =" AND warehouses.location_id IN (". implode(', ',(array)$_SESSION['tid']).")";
}
$ucid='';
if (isset($_SESSION['ucid']) && $_SESSION['ucid'] != '' && $_SESSION['ucid'] != 'NULL'){
    $ucid =" AND warehouses.location_id IN (". implode(', ',(array)$_SESSION['ucid']) .")";
}
$hfid='';
if (isset($_SESSION['hfid']) && $_SESSION['hfid'] != '' && $_SESSION['hfid'] != 'NULL'){
    $hfid =" AND warehouses.pk_id IN (". implode(', ',(array)$_SESSION['hfid']).")";
}
?>
    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.php" class="logo">
                        <span>
                            <img src="assets/images/logo.png" alt="" >
                        </span>
                        <i>
                            <img src="assets/images/logo-sm.png" alt="" height="22">
                        </i>
                    </a>
                </div>

                <nav class="navbar-custom">
                    <ul class="navbar-right d-flex list-inline float-right mb-0">

                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="index.php" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="noti-icon"> <?php echo $_SESSION['username']; ?></i>
                                <!--<span class="badge badge-pill badge-info noti-icon-badge">3</span>-->
                            </a>
                        </li>
                        <li class="dropdown notification-list">
                            <div class="dropdown notification-list nav-pro-img">
                                <a class="dropdown-toggle nav-link arrow-none waves-effect nav-user waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                    <a class="dropdown-item" href="changepassword.php"><i style="font-size: 15px;" class="mdi mdi-account-circle m-r-5">Change Password</i> <?php // echo $_SESSION['username']; ?></a>
<!--                                    <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5"></i> My Wallet</a>
                                    <a class="dropdown-item d-block" href="#"><span class="badge badge-success float-right">11</span><i class="mdi mdi-settings m-r-5"></i> Settings</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-lock-open-outline m-r-5"></i> Lock screen</a>-->
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php"><i class="mdi mdi-power text-danger"></i> Logout</a>
                                </div>                                                                    
                            </div>
                        </li>

                    </ul>
                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>                        
                        <li class="d-none d-sm-block">
                            <div class="dropdown pt-3 d-inline-block">
                                <a class="waves-effect waves-light" href="#"  aria-haspopup="true" aria-expanded="false">
                                    <h4 style="color: white;">Assets Data Management</h4>
                                </a>
                                
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </li>
                    </ul>

                </nav>

            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'left_menu.php';?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Assets Form</h4>
<!--                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Agroxa</a></li>
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Forms</a></li>
                                        <li class="breadcrumb-item active">Form Validation</li>
                                    </ol>-->
            
<!--                                    <div class="state-information d-none d-sm-block">
                                        <div class="state-graph">
                                            <div id="header-chart-1"></div>
                                            <div class="info">Balance $ 2,317</div>
                                        </div>
                                        <div class="state-graph">
                                            <div id="header-chart-2"></div>
                                            <div class="info">Item Sold 1230</div>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="page-content-wrapper">
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
            
                                            <!--<h4 class="mt-0 header-title">Range validation</h4>-->
<form method="POST" id="form_id" name="form_id" autocomplete="off" enctype="multipart/form-data">
    <nav class="navbar navbar-expand-sm navbar-dark">
        <!--<a class="navbar-brand" href="#">-->
            <img src="assets/images/Basic Information.png" width="30" height="30" class="d-inline-block align-top" alt="">
            &nbsp;&nbsp;<h4>Asset Basic Information</h4>
  <!--</a>-->

</nav>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault01">Sys Asset#</label>
      <!--<input type="number" step="0.01" name="live_birth_perc" min="0" placeholder="Patient Id" class="form-control" id="validationDefault01" placeholder="" required>-->
      <input type="text" class="form-control" placeholder="Auto GID" name="asset_id" id="asset_id" value="" readonly>
    </div>
<!--      <div class="col-md-4 mb-3">
      <label for="validationDefault01">Category <span style="color:red;">*</span></label>
      <input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>
      <select class="form-control mr-2" onchange="info_using_category()" name="category" id="category" required>
        <option value="">Select</option>
          <?php
   $sel_query1 = "Select * FROM category WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option  value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>-->
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Asset Name <span style="color:red;">*</span></label>
      <!--<input type="text" name="asset_name"  class="form-control" id="asset_name">-->
      <select class="form-control select2" onchange="info_using_assetname()" name="asset_name" id="asset_name" required>
          <option value="">Select</option>
          <?php
          $sel_querey = "SELECT
                            asset_and_specs.id,
                            asset_and_specs.category_id,
                            asset_and_specs.`name`,
                            asset_and_specs.specification,
                            MAX(asset_and_specs.specs_year) AS specs_year,
                            asset_and_specs.inserted_by,
                            asset_and_specs.inserted_date,
                            asset_and_specs.updated_by,
                            asset_and_specs.updated_date,
                            asset_and_specs.user_id,
                            asset_and_specs.`status`
                            FROM
                            asset_and_specs
                            GROUP BY `name`";
//   $sel_query1 = "Select * FROM asset_and_specs WHERE status='1' AND user_id = '".$_SESSION['uid']."' GROUP BY asset_and_specs.category_id ";
                    $result2 = mysqli_query($conn, $sel_querey);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php echo '<option  value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
      </select>
      <span class="error"><p id="asset_name_error"></p></span>
    </div>

    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Category</label>
      <input type="text" name="category_name" class="form-control" id="category" readonly>
      <input type="hidden" name="category" class="form-control" id="category_id">
      <!--<span class="error"><p id="model_error"></p></span>-->
    </div>

  </div>
    <div class="form-row"> 
           <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Specifications</label>
      <!--<div class="input-group mb-3">-->
      <input type="text" name="specification"  class="form-control" id="specification" readonly>
      <!--<div class="input-group-append">-->
        <!--<span class="input-group-addon" style="background: #60A8F2;color: white;" id="basic-addon2">Meter</span>-->
        <!--</div>-->
    <!--</div>-->
       </div>
         <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Specs Year</label>
      <input type="text" name="specs_year"  class="form-control" id="specs_year" readonly>
      <!--<span class="error"><p id="model_error"></p></span>-->
    </div>
        <div class="col-md-4 mb-3">
      <label for="validationDefault01">Asset Status </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="asset_status" id="asset_status" >
        <!--<option value='Functional' selected='selected'>Functional</option>-->
          <?php
   $sel_query1 = "Select * FROM status WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
    </div>
       <div class="form-row"> 
           <div class="col-md-4 mb-3">
      <label for="validationDefault01">Make / Manufacturer </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="manufacturer" id="manufacturer" >
        <option value=''>Select</option>
          <?php
   $sel_query1 = "Select * FROM manufacturer WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
           <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Model</label>
      <input type="text" name="model"  class="form-control" id="model" maxlength="25">
      <!--<span class="error"><p id="model_error"></p></span>-->
    </div>
          <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Serial Number / IMEI / Batch# </label>
      <input type="text" name="serial_no"  class="form-control" id="serial_no" maxlength="30">
      <!--<span class="error"><p id="serial_no_error"></p></span>-->
    </div>
       </div>
             
   <div class="form-row">
       <div class="col-md-4 mb-3">
                <label for="validationDefault03" >Expected Life / Expired Years</label>
      <input type="text" name="expiry" min="0" value ="5" maxlength="2"  class="form-control" id="expiry">
    </div>   
    <div class="col-md-4 mb-3">
      <label for="validationDefault03">Warranty</label>
      <div class="input-group mb-3">
          <input type="text" name="warranty" value="12" minlength = "0" maxlength = "2" class="form-control" id="warranty" >
        <!--<div class="input-group-append">-->
            <span class="input-group-addon" style="background: #60A8F2;color: white;" id="basic-addon2">Months</span>
        <!--</div>--> 
    </div>
       <!--<span class="error"><p id="warranty_error"></p></span>-->
    </div>   
       </div>
        
    
    <nav class="navbar navbar-expand-sm navbar-dark">
        <!--<a class="navbar-brand" href="#">-->
            <img src="assets/images/Purchasing Info.png" width="30" height="30" class="d-inline-block align-top" alt="">
            &nbsp;&nbsp;<h4>Purchasing Information</h4>
  <!--</a>-->

</nav>
        
        <div class="form-row"> 
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Purchase Type </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="purchase_type" id="purchase_type" >
        <!--<option value='Male' selected='selected'>Local</option>-->
          <?php
   $sel_query1 = "Select * FROM purchase_type WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">PO# / Document #</label>
      <input type="text" name="po_no"  class="form-control" id="po_no" maxlength="30">
      <!--<span class="error"><p id="po_no_error"></p></span>-->
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Purchase Year </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="p_year" id="p_year" >
        
          <?php
  // Loops over each int[year] from current year, back to the $earliest_year [1950]
  foreach ( range( $latest_year, $earliest_year ) as $i ) {
    // Prints the option with the next year in range.
    print '<option value="'.$i.'"'.($i === $currently_selected ? ' selected="selected"' : '').'>'.$i.'</option>';
  }
      ?>
          <option value='unknown'>Unknown</option>
        </select>
    </div>
  </div>
        
    <div class="form-row"> 
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Funding Source </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="funding_source" id="funding_source" >
        <!--<option value='KP DOH' selected='selected'>KP DOH</option>-->
          <?php
   $sel_query1 = "Select * FROM funding_source WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
             <div class="col-md-4 mb-3">
      <label for="validationDefault01">Supplier</label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="supplier" id="supplier">
        <!--<option value='ABC & CO' selected='selected'>ABC & CO</option>-->
          <?php
   $sel_query1 = "Select * FROM supplier WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationDefault01">Scale </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="scale_name" id="scale_name">
        <option value=''>Select</option>
        <option value='Billion'>Billion </option>
        <option value='Million'>Million</option>
      </select>
    </div> 
            <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Purchase Price </label>
      <input type="text" name="p_price" class="form-control" id="p_price" maxlength="10">
      <!--<span class="error"><p id="p_price_error"></p></span>-->
      <span class=""><p id="scale_pkr"></p></span>
    </div>
       </div>
    
      
    <nav class="navbar navbar-expand-sm navbar-dark">
        <!--<a class="navbar-brand" href="#">-->
            <img src="assets/images/Record.png" width="30" height="30" class="d-inline-block align-top" alt="">
            &nbsp;&nbsp;<h4>Record</h4>
  <!--</a>-->

</nav>
        <div class="form-row"> 
       <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Stock Register </label>
      <input type="text" name="stock_reg"  class="form-control" id="stock_reg">
      <span class="error"><p id="stock_reg_error"></p></span>
    </div>
<!--    <div class="col-md-4 mb-3">
      <label for="validationDefault01">Select District <span style="color:red;">*</span></label>
      <input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>
    <select class="form-control mr-2" name="seldist" id="seldist">
        <option value='ABC & CO' selected='selected'>ABC & CO</option>
          <?php
//   $sel_query1 = "SELECT
//                    locations.location_name,
//                    locations.pk_id
//                    FROM
//                    locations
//                    WHERE
//                    locations.province_id = 3 AND
//                    locations.geo_level_id = 4";
//                    $result2 = mysqli_query($conn, $sel_query1);
//                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php //    echo '<option value="'.$row['pk_id'].'">'.$row['location_name'].'</option>'; ?>
        
      <?php
//                    }
      ?>
        </select>
    </div>-->
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Location of Asset <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control select2" name="loc_of_asset" id="loc_of_asset" required>
        <!--<option value='DHQ Swat' selected='selected'>DHQ Swat</option>-->
       <?php 
       if($_SESSION['dhqid'] != '' && $_SESSION['dhqid'] != 'NULL')
       { ?>
                
          <?php
   $sel_query1 = "SELECT
                        warehouses.warehouse_name,
                        warehouses.pk_id,
                        warehouses.stakeholder_office_id,
                        warehouses.warehouse_type_id
                FROM
                        warehouses
                WHERE
                        warehouses.province_id = 3
                AND warehouses.stakeholder_office_id = 4
                AND warehouses.`status` = 1
                AND warehouses.warehouse_type_id = 4
                $districid
                ORDER BY
                        warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    
                    if ($result2->num_rows > 0) { ?>
                    
                        <optgroup label="DHQ Hospital">
   <?php                     
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }        
          
      ?>
                </optgroup>
       <?php
           }
       }
       else {
       
       
       if($_SESSION['did'] == '' || $_SESSION['did'] == 'NULL')
       { ?>
                
          <?php
   $sel_query1 = "SELECT
                    warehouses.warehouse_name,
                    warehouses.pk_id,
                    warehouses.stakeholder_office_id
                    FROM
                            warehouses
                    WHERE
                    warehouses.province_id = 3 AND
                    warehouses.stakeholder_office_id = 2
                    AND warehouses.status = 1
                    ORDER BY
                            warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    
                    if ($result2->num_rows > 0) { ?>
                
                        <optgroup label="Provincial Store">
                            
                    <?php
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php } 
       }
                if($_SESSION['tid'] == '' || $_SESSION['tid'] == 'NULL')
       {
       ?>
                
          <?php
   $sel_query1 = "SELECT
                    warehouses.warehouse_name,
                    warehouses.pk_id,
                    warehouses.stakeholder_office_id
                    FROM
                            warehouses
                    WHERE
                    warehouses.province_id = 3 AND
                    warehouses.stakeholder_office_id = 4
                    AND warehouses.status = 1
                    $districid
                    AND warehouse_type_id NOT IN (4)
                    ORDER BY
                            warehouse_name
                    ";
//   echo $sel_query1;
                    $result2 = mysqli_query($conn, $sel_query1);
                    
                    if ($result2->num_rows > 0) { ?>
                            
                        <optgroup label="Districts Store">
                
               <?php     while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php } 
       } if($_SESSION['ucid'] == '' || $_SESSION['ucid'] == 'NULL')
       {
       ?>
                
          <?php
   $sel_query1 = "SELECT
                        warehouses.warehouse_name,
                        warehouses.pk_id,
                        warehouses.stakeholder_office_id
                        FROM
                                warehouses
                        WHERE
                        warehouses.province_id = 3 AND
                        warehouses.stakeholder_office_id IN (5)
                        AND warehouses.status = 1
                        $districid
                        $thid
                        ORDER BY
                                warehouse_name
                    ";
//   echo $sel_query1;
                    $result2 = mysqli_query($conn, $sel_query1);
                    
                    if ($result2->num_rows > 0) { ?>
                    <optgroup label="Tehsil Store">
                  <?php  while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php }
       }
//       if($_SESSION['hfid'] == '' || $_SESSION['hfid'] == 'NULL')
//       {
       ?>
                <!--<optgroup label="UC Stores">-->
          <?php
//   $sel_query1 = "SELECT
//                        warehouses.warehouse_name,
//                        warehouses.pk_id,
//                        warehouses.stakeholder_office_id
//                        FROM
//                                warehouses
//                        WHERE
//                        warehouses.province_id = 3 AND
//                        warehouses.stakeholder_office_id IN (6)
//                        AND warehouses.status = 1
//                        $districid
//                        $ucid
//                        ORDER BY
//                                warehouse_name
//                    ";
//                    $result2 = mysqli_query($conn, $sel_query1);
//                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php //    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
//                    }
      ?>
                <!--</optgroup>-->
       <?php // }
       if($_SESSION['hfid'] != '' || $_SESSION['hfid'] == 'NULL')
       {
       ?>
                
          <?php
   $sel_query1 = "SELECT
                        warehouses.warehouse_name,
                        warehouses.pk_id,
                        warehouses.stakeholder_office_id
                        FROM
                                warehouses
                        WHERE
                        warehouses.province_id = 3 AND
                        warehouses.stakeholder_office_id IN (6)
                        AND warehouses.status = 1
                        $districid
                        $hfid
                        ORDER BY
                                warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                   
                     if ($result2->num_rows > 0) { ?>
                    <optgroup label="HF Stores">
                  <?php  while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php     }
            }
        } 
       ?>
        </select>
    </div>
<div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Assigned To </label>
      <input type="text" name="ass_to"  class="form-control" id="ass_to">
      <span class="error"><p id="ass_to_error"></p></span>
    </div>
       </div>
        
        <div class="form-row">
            
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">GL Code</label>
      <input type="text" name="gl_code"  class="form-control" id="gl_code" maxlength="25">
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Depreciation</label>
      <div class="input-group mb-3">
          <input type="number" name="depreciation" min="0" max="100"  class="form-control" id="depreciation">
      <!--<div class="input-group-append">-->
        <span class="input-group-addon" style="background: #60A8F2;color: white;" id="basic-addon2">%</span>
        <!--</div>-->
      </div>
      <!--<span class="error"><p id="depreciation_error"></p></span>-->
    </div>
          
       </div>
        
    <nav class="navbar navbar-expand-sm navbar-dark">
        <!--<a class="navbar-brand" href="#">-->
            <img src="assets/images/Details.png" width="30" height="30" class="d-inline-block align-top" alt="">
            &nbsp;&nbsp;<h4>Details</h4>
  <!--</a>-->

</nav>
    
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Operation Instructions (if any)</label>
    <textarea class="form-control" name="instructions" id="instructions" rows="3"></textarea>
  </div>
        <br>
         <div class="form-row">
    <label for="exampleFormControlTextarea1">Detail Description / Comments</label>
    <textarea class="form-control" name="d_description" id="d_description" rows="3"></textarea>
  </div>
        <br>
        <div class="form-row">
          <div class="form-group">
            <label>Select file</label>
            <input type="file" id="filePHOTO" name="myfile" class="filestyle" data-buttonname="btn-secondary">
            <span id="file_error"></span>
        </div>
        </div>
      
            <!--<input type="hidden" id="id" name="id" value="3487">-->
        <div id="error" style="color:red;text-align: right;"><h4>This Asset Already Exist!</h4></div>
          <div class="modal-footer">
            <button type="submit" href="" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Save</button>
            <a href="asset_form.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
                                            
                             </div>
                                    </div>
                                </div> <!-- end col -->
                            </div>  
                        <!--</div>-->
     <a name="timeline" />                       
<?php if(isset($id) && $id != '' )
{    
?>                            
                            <!--Accordion wrapper-->
<div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">

  <!-- Accordion card -->
  <div class="card">

    <!-- Card header -->
    <div class="card-header" role="tab" id="headingOne1" style="background: #6BA2D2">
      <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne1" aria-expanded="true"
        aria-controls="collapseOne1">
          <img src="assets/images/Accessories  Parts.png" width="35" height="35" class="pull-left mr-2" alt="">
        <h4 class="mb-0 text-white" >
          Accessories / Parts Management <i class="fas fa-angle-down rotate-icon "></i>
        </h4>
      </a>
    </div>

    <!-- Card body -->
    <div id="collapseOne1" class="collapse show" role="tabpanel" aria-labelledby="headingOne1"
      data-parent="#accordionEx">
      <div class="card-body">

                            
                            
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
                                            
                                            
                                            
                                            
    <form method="POST" action="asset_accessories_mang_info.php" id="form_id_acc" autocomplete="off">
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Letter#/Ref# <span style="color:red;">*</span></label>
      <input type="text" name="acc_ref_id"  class="form-control" id="acc_ref_id" required>
    </div>
     <div class="col-md-2 mb-3">
      <label for="validationDefault03">Date <span style="color:red;">*</span></label>
      <input type="date" name="acc_date" min='2020-01-01' value ="<?php echo date('Y-m-d') ?>" class="form-control" id="acc_date" required>
    </div>
  </div>
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Name / Description <span style="color:red;">*</span></label>
    <textarea class="form-control" name="acc_description" id="acc_description" rows="2" required></textarea>
  </div>
        <br>
        <div class="form-row">             
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Supplied By <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="acc_sup_by" id="acc_sup_by" required>
        <!--<option value='Supplier/Vendor' selected='selected'>Supplier/Vendor</option>-->
          <?php
   $sel_query1 = "Select * FROM supplier WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
        <div class="col-md-2 mb-3">
      <label for="validationDefault03" class="required">Price <span style="color:red;">*</span></label>
      <input type="text" name="acc_price"  class="form-control" id="acc_price" required>
    </div>
            <div class="col-md-2 mb-3">
      <label for="validationDefault03" class="required">Quantity <span style="color:red;">*</span></label>
      <input type="text" name="acc_quantity"  class="form-control" id="acc_quantity" required>
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Status <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="acc_status" id="acc_status" required>
         <?php
   $sel_query1 = "Select * FROM status WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
  </div>
        <input type="hidden" id="asset_id" name="asset_id" value="<?php echo $id; ?>">
        
         <div class="form-row">
    <label for="exampleFormControlTextarea1">Detail Description / Comments</label>
    <textarea class="form-control" name="acc_detail" id="acc_detail" rows="3"></textarea>
    <span style="color:red;">Note: You can enter maximum 300 character's.</span>
  </div>
        <br>
            <!--<input type="hidden" id="id" name="id" value="3487">-->
          <div class="modal-footer">
            <button type="submit" href="#lab_history" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Save</button>
            <a href="asset_form.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
                                            <h3>Records:</h3>
            <div class="check">
             <table id="example" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<!--<th>No.</th>-->
                                                        <th>System ID (Auto)</th>
                                                        <th>Letter#/ Ref#</th>
                                                        <th>Description</th>
                                                        <th>Date</th>
							<th>Supplied By</th>
                                                        <th>Qty</th>
                                                        <th>Comments</th>
<!--                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>-->
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                asset_accessorie_mang_info.id,
                                                                asset_accessorie_mang_info.ref_no,
                                                                asset_accessorie_mang_info.date,
                                                                asset_accessorie_mang_info.description,
                                                                asset_accessorie_mang_info.supplied_by,
                                                                asset_accessorie_mang_info.price,
                                                                asset_accessorie_mang_info.quantity,
                                                                asset_accessorie_mang_info.`status`,
                                                                asset_accessorie_mang_info.`comment`,
                                                                supplier.`name`
                                                        FROM
                                                                asset_accessorie_mang_info
                                                        INNER JOIN supplier ON asset_accessorie_mang_info.supplied_by = supplier.id
                                                        WHERE
                                                                asset_accessorie_mang_info.asset_no = $id
                                                    ";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <!--<td><?php echo $number; ?></td>-->
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['ref_no']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td><?php echo $row['comment']; ?></td>
<!--            <td>
                    <button onclick="GetUserDetails(<?php echo $row['id']; ?>)" class="btn btn-warning">Update</button>
            </td>
            <td>
                    <button onclick="DeleteUser(<?php echo $row['id']; ?>)" class="btn btn-danger">Delete</button>
               <?php if($row['ref_no'] == 1)
               {?>
                <button onclick="active(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>-->
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
            </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                                
</div>
                                
                                
                                
     <a name="timelinerep" />                           
<div class="accordion md-accordion" id="accordionEx1" role="tablist" aria-multiselectable="true">

  <!-- Accordion card -->
  <div class="card">

    <!-- Card header -->
    <div class="card-header" role="tab" id="headingOne1" style="background: #6BA2D2">
      <a data-toggle="collapse" data-parent="#accordionEx1" href="#collapseOne2" aria-expanded="true"
        aria-controls="collapseOne2">
          <img src="assets/images/Repair  Maintenance.png" width="35" height="35" class="pull-left mr-2" alt="">
        <h4 class="mb-0 text-white" >
          Repair Management <i class="fas fa-angle-down rotate-icon "></i>
        </h4>
      </a>
    </div>

    <!-- Card body -->
    <div id="collapseOne2" class="collapse show" role="tabpanel" aria-labelledby="headingOne1"
      data-parent="#accordionEx1">
      <div class="card-body">

                            
                            
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
                                            
                                            
                                            
                                            
<form method="POST" action="asset_repair_info.php" id="form_id_rep" autocomplete="off">
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">PO#/Letter#/Ref# <span style="color:red;">*</span></label>
      <input type="text" name="repair_ref_no"  class="form-control" id="repair_ref_no" required>
    </div>
     <div class="col-md-4 mb-3">
      <label for="validationDefault03">Date <span style="color:red;">*</span></label>
      <input type="date" name="date" min='2020-01-01' value ="<?php echo date('Y-m-d') ?>" class="form-control" id="date" required>
    </div>
      <div class="col-md-4 mb-3">
      <label for="validationDefault01">Status <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="rstatus" id="rstatus" required>
       <?php
   $sel_query1 = "Select * FROM status WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
  </div>
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Description / Details <span style="color:red;">*</span></label>
    <textarea class="form-control" name="repair_detail" id="repair_detail" rows="2" required></textarea>
  </div>
        <br>
        <div class="form-row"> 
    <div class="col-md-4 mb-3">
      <label for="validationDefault01">Repaired by <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="repair_by" id="repair_by" required>
        <?php
   $sel_query1 = "Select * FROM supplier WHERE status='1' ORDER BY name ASC";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault03">Repair Warranty <span style="color:red;">*</span></label>
      <div class="input-group mb-3">
          <input type="text" name="repair_warranty"  minlength = "0" maxlength = "2" class="form-control" id="repair_warranty" value="12" required>
        <!--<div class="input-group-append">-->
            <span class="input-group-addon" style="background: #60A8F2;color: white;" id="basic-addon2">Months</span>
        <!--</div>--> 
    </div>
    </div>
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Repair Amount <span style="color:red;">*</span></label>
      <input type="text" name="repair_amount"  class="form-control" id="repair_amount" required>
    </div>
            
  </div>
        <input type="hidden" id="asset_id" name="asset_id" value="<?php echo $id ?>">
         <div class="form-row">
             <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Quantity <span style="color:red;">*</span></label>
      <input type="text" name="rquantity" placeholder="" class="form-control" id="rquantity" required>
    </div>
   <div class="col-md-8 mb-3">
    <label for="exampleFormControlTextarea1">Comments / Remarks</label>
    <textarea class="form-control" name="r_comment" id="r_comment" rows="3"></textarea>
    </div>
         </div>
            <!--<input type="hidden" id="id" name="id" value="3487">-->
          <div class="modal-footer">
            <button type="submit" href="#lab_history" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Save</button>
            <a href="asset_form.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
                                            <h3>Records:</h3>
            <div class="check">
             <table id="example1" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<!--<th>No.</th>-->
                                                        <th>System ID (Auto)</th>
                                                        <th>PO#/ Letter#/ Ref#</th>
                                                        <th>Repair Description</th>
                                                        <th>Repair Date</th>
							<th>Repair By</th>
                                                        <th>Status</th>
                                                        <th>Quantity</th>
                                                        <th>Warranty of Repair , if any</th>
                                                        <th>Vendor / Supplier</th>
                                                        <th>Comments</th>
<!--                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>-->
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                    A.*, B.*
                                                            FROM
                                                                    (
                                                                            SELECT
                                                                                    asset_repair_info.id,
                                                                                    supplier.`name` AS repairby
                                                                            FROM
                                                                                    asset_repair_info
                                                                            INNER JOIN supplier ON asset_repair_info.repaired_by_id = supplier.id
                                                                            WHERE
                                                                            asset_repair_info.asset_no = $id
                                                                    ) A
                                                            LEFT JOIN (
                                                                    SELECT
                                                                            asset_repair_info.id,
                                                                            asset_repair_info.repair_po_no,
                                                                            asset_repair_info.date,
                                                                            asset_repair_info.description,
                                                                            asset_repair_info.repaired_by_id,
                                                                            asset_repair_info.repair_warrenty,
                                                                            asset_repair_info.repair_amount,
                                                                            asset_repair_info.`comment`,
                                                                            `status`.`name`,
                                                                            asset_repair_info.`quantity`,
                                                                            asset_info.asset_id,
                                                                            supplier.`name` AS supliername
                                                                    FROM
                                                                            asset_repair_info
                                                                    INNER JOIN `status` ON asset_repair_info.`status` = `status`.id
                                                                    INNER JOIN asset_info ON asset_repair_info.asset_no = asset_info.asset_id
                                                                    INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                                    WHERE
                                                                            asset_repair_info.asset_no = $id
                                                            ) B ON A.id = B.id";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <!--<td><?php echo $number; ?></td>-->
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['repair_po_no']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['repairby']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td><?php echo $row['repair_warrenty']; ?></td>
            <td><?php echo $row['supliername']; ?></td>
            <td><?php echo $row['comment']; ?></td>
<!--            <td>
                    <button onclick="GetUserDetails(<?php echo $row['id']; ?>)" class="btn btn-warning">Update</button>
            </td>
            <td>
                    <button onclick="DeleteUser(<?php echo $row['id']; ?>)" class="btn btn-danger">Delete</button>
               <?php if($row['ref_no'] == 1)
               {?>
                <button onclick="active(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>-->
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
            
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
</div>
                                
<?php }
?>
                                
                                
                                
                                
                                
                            </div> <!-- end row -->  
                        </div>
                        <!-- end page content-->

                    </div> <!-- container-fluid -->

                </div>  

                <footer class="footer">
                    <!--© 2018 Agroxa <span class="d-none d-sm-inline-block">- Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand.</span>-->
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>
        
        <script src="plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
        <script src="plugins/bootstrap-md-datetimepicker/js/moment-with-locales.min.js"></script>
        <script src="plugins/bootstrap-md-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

        <!-- Plugins js -->
        <script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>

        <script src="plugins/select2/js/select2.min.js"></script>
        <script src="plugins/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js"></script>
        <script src="plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js"></script>
        
        <script src="plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        
        <!-- Parsley js -->
        <script src="plugins/parsleyjs/parsley.min.js"></script>
        <script src="assets/pages/form-advanced.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script src="js/script.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>-->
        
        <script>
            
            $("#error").hide();
            $(document).ready(function() {
                $('form').parsley();
            });
    
$(document).ready(function(){
    $("#filePHOTO").change(function(){
    
    var file = this.files[0];
    var fileType = file.type;
    var match = ['application/pdf', 'application/msword', 'application/vnd.ms-office', 'image/jpeg', 'image/png', 'image/jpg'];
    
    
    $("#file_error").html("");
    $(".filestyle").css("border-color","#F0F0F0");
    var file_size = $('#filePHOTO')[0].files[0].size;
    
    if(file_size > 1048576) {
        
    $("#file_error").html("<p style='color:#FF0000'>File size is greater than 1MB</p>");
    $(".filestyle").css("border-color","#FF0000");
    $("#filePHOTO").val('');
    return false;
    
    } 
    else if(!((fileType == match[0]) || (fileType == match[1]) || (fileType == match[2]) || (fileType == match[3]) || (fileType == match[4]) || (fileType == match[5]))){
       
//        alert('Sorry, only PDF, DOC, JPG, JPEG, & PNG files are allowed to upload.');
        $("#file_error").html("<p style='color:#FF0000'>Sorry, only PDF, DOC, JPG, JPEG, & PNG files are allowed to upload.</p>");
        $(".filestyle").css("border-color","#FF0000");
        $("#filePHOTO").val('');
        return false;
        
    }
//     else{
//            return true;
//    }
    });
});
    
//    $(document).ready(function(){
//    $("#seldist").change(function(){
//     var seldist = $('#seldist').val();
////            alert(whType);
//            if (seldist != '')
//            {
//                $.ajax({
//                    type: "POST",
//                    url: "ajax/ajax_get_hf.php",
//                    data: {district: seldist},
//                    dataType: 'html',
//                    success: function(data)
//                    {
//                        $('#loc_of_asset').html(data);
//                    }
//                });
//            }
//    });
//});
    
    
            $(document).ready(function() {
    $('#example').DataTable( {
    } );
} );



$(document).ready(function() {
    $('#example1').DataTable( {
        scrollX:        true,
    } );
} );

 $(document).ready(function(){
     
     $("#scale_name").change(function () {
//    alert($('#scale_name').val());
    $('#scale_pkr').html($('#scale_name').val());
});
     
function removeWarning() {
    document.getElementById(this.id + "_error").innerHTML = "";
    document.getElementById("asset_name").style.border= "solid 1px #CCCCCC";
//    document.getElementById("model").style.border= "solid 1px #CCCCCC";
//    document.getElementById("warranty").style.border= "solid 1px #CCCCCC";
//    document.getElementById("po_no").style.border= "solid 1px #CCCCCC";
    document.getElementById("p_price").style.border= "solid 1px #CCCCCC";
    document.getElementById("stock_reg").style.border= "solid 1px #CCCCCC";
    document.getElementById("ass_to").style.border= "solid 1px #CCCCCC";
//    document.getElementById("depreciation").style.border= "solid 1px #CCCCCC";
}

document.getElementById("asset_name").onkeyup = removeWarning;
//document.getElementById("model").onkeyup = removeWarning;
//document.getElementById("warranty").onkeyup = removeWarning;
//document.getElementById("po_no").onkeyup = removeWarning;
document.getElementById("p_price").onkeyup = removeWarning;
document.getElementById("stock_reg").onkeyup = removeWarning;
document.getElementById("ass_to").onkeyup = removeWarning;
//document.getElementById("depreciation").onkeyup = removeWarning;

 });

// $(document).ready(function(){
//$("#filePHOTO").change(function() {
//    var file = this.files[0];
//    var fileType = file.type;
//    var match = ['application/pdf', 'application/msword', 'application/vnd.ms-office', 'image/jpeg', 'image/png', 'image/jpg'];
//    if(!((fileType == match[0]) || (fileType == match[1]) || (fileType == match[2]) || (fileType == match[3]) || (fileType == match[4]) || (fileType == match[5]))){
//        alert('Sorry, only PDF, DOC, JPG, JPEG, & PNG files are allowed to upload.');
//        $("#filePHOTO").val('');
//        return false;
//    }
//});
//});

 $(document).ready(function(){
   
 $('#form_id').on('submit', function(event){
//        document.getElementById("file_error").innerHTML = "";
////        $("#file_error").html("");
////                $(".demoInputBox").css("border-color","#F0F0F0");
//        document.getElementByClassName("demoInputBox").style.border= "#F0F0F0";

   
//     var id = $('#id').val();

//var b = document.forms["form_id"]["model"].value;
//var c = document.forms["form_id"]["serial_no"].value;
//var d = document.forms["form_id"]["warranty"].value;
//var e = document.forms["form_id"]["po_no"].value;
//var a = document.forms["form_id"]["asset_name"].value;
//var f = document.forms["form_id"]["p_price"].value;
//var g = document.forms["form_id"]["stock_reg"].value;
//var h = document.forms["form_id"]["ass_to"].value;
//var i = document.forms["form_id"]["depreciation"].value;

//    var submit = true;
//    alert(x);
//    if (a == null || a == "") {
//        nameError = "Please enter Asset Name";
//        document.getElementById("asset_name_error").innerHTML = nameError;
//        document.getElementById("asset_name").style.border= "solid 2px red";
//        document.getElementById("asset_name").focus();
//        return false;
//    }
//    if (b == null || b == "") {
//        nameError = "Please enter Model";
//        document.getElementById("model_error").innerHTML = nameError;
//        document.getElementById("model").style.border= "solid 2px red";
//        document.getElementById("model").focus();
//        return false;
//    }
//    if (c == null || c == "") {
//        nameError = "Please enter Serial No";
//        document.getElementById("serial_no_error").innerHTML = nameError;
//        document.getElementById("serial_no").style.border= "solid 2px red";
//        document.getElementById("serial_no").focus();
//        return false;
//    }
//    if (d == null || d == "") {
//        nameError = "Please enter End Warranty";
//        document.getElementById("warranty_error").innerHTML = nameError;
//        document.getElementById("warranty").style.border= "solid 2px red";
//        document.getElementById("warranty").focus();
//        return false;
//    }
//    if (e == null || e == "") {
//        nameError = "Please enter Document No";
//        document.getElementById("po_no_error").innerHTML = nameError;
//        document.getElementById("po_no").style.border= "solid 2px red";
//        document.getElementById("po_no").focus();
//        return false;
//    }
//    if (f == null || f == "") {
//        nameError = "Please enter Purchase Price";
//        document.getElementById("p_price_error").innerHTML = nameError;
//        document.getElementById("p_price").style.border= "solid 2px red";
//        document.getElementById("p_price").focus();
//        return false;
//    }
//    if (g == null || g == "") {
//        nameError = "Please enter Stock Register Value";
//        document.getElementById("stock_reg_error").innerHTML = nameError;
//        document.getElementById("stock_reg").style.border= "solid 2px red";
//        document.getElementById("stock_reg").focus();
//        return false;
//    }
//    if (h == null || h == "") {
//        nameError = "Please enter Assign to Name";
//        document.getElementById("ass_to_error").innerHTML = nameError;
//        document.getElementById("ass_to").style.border= "solid 2px red";
//        document.getElementById("ass_to").focus();
//        return false;
//    }
//    if (i == null || i == "") {
//        nameError = "Please enter Depreciation";
//        document.getElementById("depreciation_error").innerHTML = nameError;
//        document.getElementById("depreciation").style.border= "solid 2px red";
//        document.getElementById("depreciation").focus();
//        return false;
//    }
    
//          var fileInput =  document.getElementById("file");
//                var objFSO = new ActiveXObject("Scripting.FileSystemObject");
//                var e = objFSO.getFile( fileInput.value);
//                var file_size = e.size;
//                alert(file_size);  
//                
////                var file_size = $('#file')[0].files[0].size;
//                if(file_size>1048576) {
////                        $("#file_error").html("File size is greater than 2MB");
//                        document.getElementById("file_error").innerHTML = "File size is greater than 1MB";
////                        $(".demoInputBox").css("border-color","#FF0000");
//                         document.getElementByClassName("demoInputBox").style.border= "#FF0000";
//                        return false;
//                }
//    else{
  event.preventDefault();
  $.ajax({
   type:"POST",
   url:"asset_save_info.php",
   data: new FormData(this),
    contentType: false,
    cache: false,
    processData:false,
   success:function(data){
//       fetch_data();
//       alert(id);
var user = JSON.parse(data);
//alert(user.lastid);
        if(user.match == '1' || user.match == '0')
       {
            $("#error").show();
             setTimeout(function() { $("#error").hide(); }, 3000);
       }
       
       else if(user.lastid != '')
       {
            location.href = "asset_form.php?id="+user.lastid+'#accordionEx';
       }
    },
   Error:function(data){
       alert("Failed to Insert the data");
   }
  });
//    }
 });
});
        </script>
    
    </body>

</html>