<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php
    include 'classes/config.php';
    
        
    if(isset($_REQUEST['id']) && $_REQUEST['id'] != '')
    {
        $id=$_REQUEST['id'];
        $phone = $_POST['sup_con_phone'];
        $email = $_POST['sup_con_email'];
        $name = $_POST['sup_name'];
//        $query = "select * from supplier where (contact_phone='$phone' OR contact_email='$email')  AND id NOT IN ('".$_REQUEST['id']."')";
        $query = "select * from supplier where (name='$name')  AND id NOT IN ('".$_REQUEST['id']."')";
//        echo $query;
//        exit;
        $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else 
   {
//		$sup_code = mt_rand(1000, 9999);
                date_default_timezone_set('Asia/Karachi');
                $updatedtime = date('Y-m-d H:i:s'); 
                $updatedby = $_SESSION['username'];
                $sup_name = $_REQUEST['sup_name'];
                $sup_con_name = $_REQUEST['sup_con_name'];
                $sup_con_phone = $_REQUEST['sup_con_phone'];
                $sup_con_email = $_REQUEST['sup_con_email'];
                $sup_address = $_REQUEST['sup_address'];
                $sup_con_name2 = $_REQUEST['sup_con_name2'];
                $sup_con_phone2 = $_REQUEST['sup_con_phone2'];
                $sup_con_email2 = $_REQUEST['sup_con_email2'];
                $main_address = $_REQUEST['main_address'];
                $sup_ntn = $_REQUEST['sup_ntn'];
                $sup_cstn = $_REQUEST['sup_gstn'];
//		$id = $_REQUEST['id'];
		$query = "UPDATE supplier SET name='$sup_name',contact_name='$sup_con_name',contact_phone='$sup_con_phone',contact_email='$sup_con_email',address='$sup_address',ntn='$sup_ntn',gstn='$sup_cstn',updated_by = '$updatedby',updated_date = '$updatedtime',contact_name2='$sup_con_name2',contact_phone2='$sup_con_phone2',contact_email2 = '$sup_con_email2',address2 = '$main_address' WHERE id=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            $response   =   array("chkid"=>"1");
       echo json_encode($response);
   }
}
 else if($_SESSION['userid'] != '4' && $_SESSION['userid'] != '6'  && isset($_REQUEST['sup_name'])){
        $phone = $_POST['sup_con_phone'];
        $email = $_POST['sup_con_email'];
        $sup_name = $_REQUEST['sup_name'];
        $check=mysqli_query($conn,"select * from supplier where name='$sup_name' AND user_id = '".$_SESSION['uid']."'");
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"1");
       echo json_encode($response);
   }
   else 
   {
		$sup_code = mt_rand(1000, 9999);
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
                $sup_name = $_REQUEST['sup_name'];
                $sup_con_name = $_REQUEST['sup_con_name'];
                $sup_con_phone = $_REQUEST['sup_con_phone'];
                $sup_con_email = $_REQUEST['sup_con_email'];
                $sup_address = $_REQUEST['sup_address'];
                $sup_con_name2 = $_REQUEST['sup_con_name2'];
                $sup_con_phone2 = $_REQUEST['sup_con_phone2'];
                $sup_con_email2 = $_REQUEST['sup_con_email2'];
                $main_address = $_REQUEST['main_address'];
                $sup_ntn = $_REQUEST['sup_ntn'];
                $sup_cstn = $_REQUEST['sup_gstn'];
                $uid = $_SESSION['uid'];
//		$query = "INSERT INTO patient_table (registration_date,name,cnic,gender,age,contact,email,lab,nationality,address,from_c,to_c,arrive,p_id) VALUES ('$registration_date','$name' ,'$cnic','$gender','$age','$contact','$email','$lab','$nationality','$address','$from','$to','$arrive','$p_id')";
                
                $query = "INSERT INTO supplier (code,name,contact_name,contact_phone,contact_email,address,ntn,gstn,status,user_id,inserted_by,inserted_date,updated_by,updated_date,contact_name2,contact_phone2,contact_email2,address2)
                VALUES ('$sup_code', '$sup_name', '$sup_con_name','$sup_con_phone','$sup_con_email','$sup_address','$sup_ntn','$sup_cstn','1','$uid','$insertedby','$insertedtime','$insertedby','$insertedtime','$sup_con_name2','$sup_con_phone2','$sup_con_email2','$main_address')";
                
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            $response   =   array("chkid"=>"0");
       echo json_encode($response);
   }
 } else if($_SESSION['userid'] == '4' || $_SESSION['userid'] == '6' && isset($_REQUEST['sup_name'])){
            $response   =   array("match"=>"2");
            echo json_encode($response);
     }
?>

<?php
if(isset($_POST['operation']))
{ ?>
<table id="example" class="stripe row-border order-column" style="width:100%;">
        <thead style="color: white;background: #33B23F;">
                                                <tr>
							<th>Sr No.</th>
                                                        <!--<th>Code</th>-->
                                                        <th>Name</th>
                                                        <th>Contact Name</th>
                                                        <th>Contact Phone</th>
                                                        <th>Contact Email</th>
                                                        <th>Address</th>
                                                        <th>NTN</th>
                                                        <th>GSTN</th>
                                                        <th>Created By</th>
                                                        <th>Created Date</th>
                                                        <th>Modified By</th>
                                                        <th>Modified Date</th>
            <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
                                                        <th>Action</th>
                                                        <th>Status</th>
            <?php }
            ?>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                supplier.id,
                                                                supplier.`code`,
                                                                supplier.`name`,
                                                                supplier.contact_name,
                                                                supplier.contact_phone,
                                                                supplier.contact_email,
                                                                supplier.address,
                                                                supplier.ntn,
                                                                supplier.gstn,
                                                                supplier.`status`,
                                                                supplier.inserted_by,
                                                                supplier.updated_by,
                                                                supplier.inserted_date,
                                                                supplier.updated_date
                                                                FROM
                                                                supplier
                                                                WHERE user_id = '".$_SESSION['uid']."' Order by supplier.id";
//                                                echo $query;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <!--<td><?php // echo $row['code']; ?></td>-->
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['contact_name']; ?></td>
            <td><?php echo $row['contact_phone']; ?></td>
            <td><?php echo $row['contact_email']; ?></td>
            <td><?php echo $row['address']; ?></td>
            <td><?php echo $row['ntn']; ?></td>
            <td><?php echo $row['gstn']; ?></td>
            <td><?php echo $row['inserted_by']; ?></td>
            <td><?php echo $row['inserted_date']; ?></td>
            <td><?php echo $row['updated_by']; ?></td>
            <td><?php echo $row['updated_date']; ?></td>
       <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
            <td>
                    <button id="<?php echo $row["id"]; ?>" onclick="edit_lab(this.id)" class="btn btn-success">Update</button>
            </td> 
            <td>
              <?php if($row['status'] == 1)
               {?>
                <button onclick="activesup(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactivesup(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>
        <?php }
        ?>
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
<script>
    $(document).ready(function() {
    $('#example').DataTable({
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        fixedColumns:   {
            leftColumns:2,
            rightColumns: 2
        },
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
});
    </script>

<?php
}    
?>