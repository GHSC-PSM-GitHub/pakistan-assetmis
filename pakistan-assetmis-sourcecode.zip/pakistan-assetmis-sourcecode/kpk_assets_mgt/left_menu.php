<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }

if($_SESSION["userid"] == '' || $_SESSION["userid"] == '0')
{
?>
<div class="left side-menu" style="padding-top: 70px;color: white;border-right: 1px solid buttonface;">
    <div class="slimscroll-menu" id="remove-scroll" style="border-top: 1px solid buttonface;">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title"></li>
                            <li>
                                <a href="index.php" class="waves-effect">
                                    <i class="mdi mdi-home"></i><span class="badge badge-primary float-right"></span> <span> Dashboard </span>
                                </a>
                            </li>

<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-email"></i><span> Email <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span></a>
                                <ul class="submenu">
                                    <li><a href="email-inbox.html">Inbox</a></li>
                                    <li><a href="email-read.html">Email Read</a></li>
                                    <li><a href="email-compose.html">Email Compose</a></li>
                                </ul>
                            </li>-->
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-black-mesa"></i> <span> CMS <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li>
                                        <a href="javascript:void(0);" class="waves-effect"> <i class="mdi mdi-buffer"></i> <span> User Management <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                        <ul class="submenu">
                                            <li><a style="margin-left: 30px;" href="role_mang.php">Roles</a></li>
                                                <li><a style="margin-left: 30px;" href="user_mang.php">Users</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="organization_mang.php">Organization</a></li>
                                    <!--<li><a href="manage_location.php">Manage Location</a></li>-->  
                                    <li><a href="manufacturer_mang.php">Manufacturer</a></li>
                                    <li><a href="supplier_mang.php">Supplier</a></li>
                                    <li><a href="category_mang.php">Category</a></li>
                                    <li><a href="asset_and_specs.php">Asset & Specs</a></li>
                                    <li><a href="status_mang.php">Status</a></li>
                                    <li><a href="purchase_type_mang.php">Purchase Type</a></li>
                                    <li><a href="funding_source_mang.php">Funding Source</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Assets Data Mgmt<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">                                    
                                    <li><a href="asset_form.php">Create Asset</a></li>
                                    <li><a href="update_asset.php">Search & Update Asset</a></li>
<!--                                    <li><a href="asset_accessories_manag.php">Accessories</a></li>
                                    <li><a href="asset_repair_mang.php">Repair</a></li>-->
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Reports<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="detail_report.php">Detail Report</a></li>
                                    <li><a href="summary_detail.php">Summary at Glance</a></li>
                                    <li><a href="logs_detail.php">User Detail</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Analytics<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="bitool.php">BI Tool</a></li>
                                    <!--<li><a href="#">Dashboard</a></li>-->
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
<?php } else if($_SESSION["userid"] == '1')
{
?>
<div class="left side-menu" style="padding-top: 70px;color: white">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title"></li>
                            <li>
                                <a href="index.php" class="waves-effect">
                                    <i class="mdi mdi-home"></i><span class="badge badge-primary float-right"></span> <span> Dashboard </span>
                                </a>
                            </li>

<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-email"></i><span> Email <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span></a>
                                <ul class="submenu">
                                    <li><a href="email-inbox.html">Inbox</a></li>
                                    <li><a href="email-read.html">Email Read</a></li>
                                    <li><a href="email-compose.html">Email Compose</a></li>
                                </ul>
                            </li>-->
<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-black-mesa"></i> <span> CMS <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="organization_mang.php">Organization</a></li>
                                    <li><a href="manage_location.php">Manage Location</a></li>                                    
                                    <li>
                                        <a href="javascript:void(0);" class="waves-effect"> <i class="mdi mdi-buffer"></i> <span> User Management <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                        <ul class="submenu">
                                            <li><a style="margin-left: 30px;" href="role_mang.php">Roles</a></li>
                                                <li><a style="margin-left: 30px;" href="user_mang.php">Users</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="manufacturer_mang.php">Manufacturer</a></li>
                                    <li><a href="supplier_mang.php">Supplier</a></li>
                                    <li><a href="category_mang.php">Category</a></li>
                                    <li><a href="asset_and_specs.php">Asset & Specs</a></li>
                                    <li><a href="status_mang.php">Status</a></li>
                                    <li><a href="purchase_type_mang.php">Purchase Type</a></li>
                                    <li><a href="funding_source_mang.php">Funding Source</a></li>
                                </ul>
                            </li>-->
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Enter Assets Data<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">                                    
                                    <li><a href="asset_form.php">Create Asset</a></li>
                                    <li><a href="update_asset.php">Search & Update Asset</a></li>
<!--                                    <li><a href="asset_accessories_manag.php">Accessories</a></li>
                                    <li><a href="asset_repair_mang.php">Repair</a></li>-->
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Reports<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="detail_report.php">Detail Report</a></li>
                                    <li><a href="summary_detail.php">Summary at Glance</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Analytics<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="bitool.php">BI Tool</a></li>
                                    <!--<li><a href="#">Dashboard</a></li>-->
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
<?php } else if($_SESSION["userid"] == '2')
{
?>
<div class="left side-menu" style="padding-top: 70px;color: white">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title"></li>
                            <li>
                                <a href="index.php" class="waves-effect">
                                    <i class="mdi mdi-home"></i><span class="badge badge-primary float-right"></span> <span> Dashboard </span>
                                </a>
                            </li>

<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-email"></i><span> Email <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span></a>
                                <ul class="submenu">
                                    <li><a href="email-inbox.html">Inbox</a></li>
                                    <li><a href="email-read.html">Email Read</a></li>
                                    <li><a href="email-compose.html">Email Compose</a></li>
                                </ul>
                            </li>-->
<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-black-mesa"></i> <span> CMS <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="organization_mang.php">Organization</a></li>
                                    <li><a href="manage_location.php">Manage Location</a></li>                                    
                                    <li>
                                        <a href="javascript:void(0);" class="waves-effect"> <i class="mdi mdi-buffer"></i> <span> User Management <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                        <ul class="submenu">
                                            <li><a style="margin-left: 30px;" href="role_mang.php">Roles</a></li>
                                                <li><a style="margin-left: 30px;" href="user_mang.php">Users</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="manufacturer_mang.php">Manufacturer</a></li>
                                    <li><a href="supplier_mang.php">Supplier</a></li>
                                    <li><a href="category_mang.php">Category</a></li>
                                    <li><a href="asset_and_specs.php">Asset & Specs</a></li>
                                    <li><a href="status_mang.php">Status</a></li>
                                    <li><a href="purchase_type_mang.php">Purchase Type</a></li>
                                    <li><a href="funding_source_mang.php">Funding Source</a></li>
                                </ul>
                            </li>-->
<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Enter Assets Data<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">                                    
                                    <li><a href="asset_form.php">Create Asset</a></li>
                                    <li><a href="update_asset.php">Search & Update Asset</a></li>
                                    <li><a href="asset_accessories_manag.php">Accessories</a></li>
                                    <li><a href="asset_repair_mang.php">Repair</a></li>
                                </ul>
                            </li>-->
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Reports<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="detail_report.php">Detail Report</a></li>
                                    <li><a href="summary_detail.php">Summary at Glance</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Analytics<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="bitool.php">BI Tool</a></li>
                                    <!--<li><a href="#">Dashboard</a></li>-->
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
<?php } else if($_SESSION["userid"] == '3')
{
?>
<div class="left side-menu" style="padding-top: 70px;color: white">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title"></li>
                            <li>
                                <a href="index.php" class="waves-effect">
                                    <i class="mdi mdi-home"></i><span class="badge badge-primary float-right"></span> <span> Dashboard </span>
                                </a>
                            </li>

<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-email"></i><span> Email <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span></a>
                                <ul class="submenu">
                                    <li><a href="email-inbox.html">Inbox</a></li>
                                    <li><a href="email-read.html">Email Read</a></li>
                                    <li><a href="email-compose.html">Email Compose</a></li>
                                </ul>
                            </li>-->
<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-black-mesa"></i> <span> CMS <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="organization_mang.php">Organization</a></li>
                                    <li><a href="manage_location.php">Manage Location</a></li>                                    
                                    <li><a href="manufacturer_mang.php">Manufacturer</a></li>
                                    <li><a href="supplier_mang.php">Supplier</a></li>
                                    <li><a href="category_mang.php">Category</a></li>
                                    <li><a href="asset_and_specs.php">Asset & Specs</a></li>
                                    <li><a href="status_mang.php">Status</a></li>
                                    <li><a href="purchase_type_mang.php">Purchase Type</a></li>
                                    <li><a href="funding_source_mang.php">Funding Source</a></li>
                                </ul>
                            </li>-->
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Enter Assets Data<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">                                    
                                    <li><a href="asset_form.php">Create Asset</a></li>
                                    <!--<li><a href="update_asset.php">Search & Update Asset</a></li>-->
<!--                                    <li><a href="asset_accessories_manag.php">Accessories</a></li>
                                    <li><a href="asset_repair_mang.php">Repair</a></li>-->
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Reports<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="detail_report.php">Detail Report</a></li>
                                    <li><a href="summary_detail.php">Summary at Glance</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Analytics<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="bitool.php">BI Tool</a></li>
                                    <!--<li><a href="#">Dashboard</a></li>-->
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
<?php } else if($_SESSION["userid"] == '4')
{
?>
<div class="left side-menu" style="padding-top: 70px;color: white">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title"></li>
                            <li>
                                <a href="index.php" class="waves-effect">
                                    <i class="mdi mdi-home"></i><span class="badge badge-primary float-right"></span> <span> Dashboard </span>
                                </a>
                            </li>

<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-email"></i><span> Email <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span></a>
                                <ul class="submenu">
                                    <li><a href="email-inbox.html">Inbox</a></li>
                                    <li><a href="email-read.html">Email Read</a></li>
                                    <li><a href="email-compose.html">Email Compose</a></li>
                                </ul>
                            </li>-->
<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-black-mesa"></i> <span> CMS <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="organization_mang.php">Organization</a></li>
                                    <li><a href="manufacturer_mang.php">Manufacturer</a></li>
                                    <li><a href="supplier_mang.php">Supplier</a></li>
                                    <li><a href="category_mang.php">Category</a></li>
                                    <li><a href="asset_and_specs.php">Asset & Specs</a></li>
                                    <li><a href="status_mang.php">Status</a></li>
                                    <li><a href="purchase_type_mang.php">Purchase Type</a></li>
                                    <li><a href="funding_source_mang.php">Funding Source</a></li>
                                </ul>
                            </li>-->
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Enter Assets Data<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">                                    
                                    <!--<li><a href="asset_form.php">Create Asset</a></li>-->
                                    <li><a href="update_asset.php">Search & Update Asset</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Reports<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="detail_report.php">Detail Report</a></li>
                                    <li><a href="summary_detail.php">Summary at Glance</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Analytics<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="bitool.php">BI Tool</a></li>
                                    <!--<li><a href="#">Dashboard</a></li>-->
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
<?php } else if($_SESSION["userid"] == '5')
{
?>
<div class="left side-menu" style="padding-top: 70px;color: white">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title"></li>
                            <li>
                                <a href="index.php" class="waves-effect">
                                    <i class="mdi mdi-home"></i><span class="badge badge-primary float-right"></span> <span> Dashboard </span>
                                </a>
                            </li>

<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-email"></i><span> Email <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span></a>
                                <ul class="submenu">
                                    <li><a href="email-inbox.html">Inbox</a></li>
                                    <li><a href="email-read.html">Email Read</a></li>
                                    <li><a href="email-compose.html">Email Compose</a></li>
                                </ul>
                            </li>-->
<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-black-mesa"></i> <span> CMS <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="organization_mang.php">Organization</a></li>
                                    <li><a href="manage_location.php">Manage Location</a></li>                                    
                                    <li><a href="manufacturer_mang.php">Manufacturer</a></li>
                                    <li><a href="supplier_mang.php">Supplier</a></li>
                                    <li><a href="category_mang.php">Category</a></li>
                                    <li><a href="asset_and_specs.php">Asset & Specs</a></li>
                                    <li><a href="status_mang.php">Status</a></li>
                                    <li><a href="purchase_type_mang.php">Purchase Type</a></li>
                                    <li><a href="funding_source_mang.php">Funding Source</a></li>
                                </ul>
                            </li>-->
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Enter Assets Data<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">                                    
                                    <li><a href="asset_form.php">Create Asset</a></li>
                                    <li><a href="update_asset.php">View Asset</a></li>
<!--                                    <li><a href="asset_accessories_manag.php">Accessories</a></li>
                                    <li><a href="asset_repair_mang.php">Repair</a></li>-->
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Reports<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="detail_report.php">Detail Report</a></li>
                                    <li><a href="summary_detail.php">Summary at Glance</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Analytics<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="bitool.php">BI Tool</a></li>
                                    <!--<li><a href="#">Dashboard</a></li>-->
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
<?php } else if($_SESSION["userid"] == '6')
{
?>
<div class="left side-menu" style="padding-top: 70px;color: white">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title"></li>
                            <li>
                                <a href="index.php" class="waves-effect">
                                    <i class="mdi mdi-home"></i><span class="badge badge-primary float-right"></span> <span> Dashboard </span>
                                </a>
                            </li>

<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-email"></i><span> Email <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span></a>
                                <ul class="submenu">
                                    <li><a href="email-inbox.html">Inbox</a></li>
                                    <li><a href="email-read.html">Email Read</a></li>
                                    <li><a href="email-compose.html">Email Compose</a></li>
                                </ul>
                            </li>-->
<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-black-mesa"></i> <span> CMS <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="organization_mang.php">Organization</a></li>
                                    <li><a href="manage_location.php">Manage Location</a></li>                                    
                                    <li><a href="manufacturer_mang.php">Manufacturer</a></li>
                                    <li><a href="supplier_mang.php">Supplier</a></li>
                                    <li><a href="category_mang.php">Category</a></li>
                                    <li><a href="asset_and_specs.php">Asset & Specs</a></li>
                                    <li><a href="status_mang.php">Status</a></li>
                                    <li><a href="purchase_type_mang.php">Purchase Type</a></li>
                                    <li><a href="funding_source_mang.php">Funding Source</a></li>
                                </ul>
                            </li>-->
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Enter Assets Data<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">                                    
                                    <!--<li><a href="asset_form.php">Create Asset</a></li>-->
                                    <li><a href="update_asset.php">Search and Update Asset</a></li>
<!--                                    <li><a href="asset_accessories_manag.php">Accessories</a></li>
                                    <li><a href="asset_repair_mang.php">Repair</a></li>-->
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Reports<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="detail_report.php">Detail Report</a></li>
                                    <li><a href="summary_detail.php">Summary at Glance</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Analytics<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="bitool.php">BI Tool</a></li>
                                    <!--<li><a href="#">Dashboard</a></li>-->
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
<?php } else if($_SESSION["userid"] == '7')
{
?>
<div class="left side-menu" style="padding-top: 70px;color: white">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title"></li>
                            <li>
                                <a href="index.php" class="waves-effect">
                                    <i class="mdi mdi-home"></i><span class="badge badge-primary float-right"></span> <span> Dashboard </span>
                                </a>
                            </li>

<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-email"></i><span> Email <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span></a>
                                <ul class="submenu">
                                    <li><a href="email-inbox.html">Inbox</a></li>
                                    <li><a href="email-read.html">Email Read</a></li>
                                    <li><a href="email-compose.html">Email Compose</a></li>
                                </ul>
                            </li>-->
<!--                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-black-mesa"></i> <span> CMS <span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="organization_mang.php">Organization</a></li>
                                    <li><a href="manage_location.php">Manage Location</a></li>                                    
                                    <li><a href="manufacturer_mang.php">Manufacturer</a></li>
                                    <li><a href="supplier_mang.php">Supplier</a></li>
                                    <li><a href="category_mang.php">Category</a></li>
                                    <li><a href="asset_and_specs.php">Asset & Specs</a></li>
                                    <li><a href="status_mang.php">Status</a></li>
                                    <li><a href="purchase_type_mang.php">Purchase Type</a></li>
                                    <li><a href="funding_source_mang.php">Funding Source</a></li>
                                </ul>
                            </li>-->
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Enter Assets Data<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">                                    
                                    <li><a href="asset_form.php">Create Asset</a></li>
                                    <li><a href="update_asset.php">Search & Update Asset</a></li>
<!--                                    <li><a href="asset_accessories_manag.php">Accessories</a></li>
                                    <li><a href="asset_repair_mang.php">Repair</a></li>-->
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Reports<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="detail_report.php">Detail Report</a></li>
                                    <li><a href="summary_detail.php">Summary at Glance</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-buffer"></i> <span>Analytics<span class="float-right menu-arrow"><i class="mdi mdi-chevron-down"></i></span> </span> </a>
                                <ul class="submenu">
                                    <li><a href="bitool.php">BI Tool</a></li>
                                    <!--<li><a href="#">Dashboard</a></li>-->
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
<?php }
?>