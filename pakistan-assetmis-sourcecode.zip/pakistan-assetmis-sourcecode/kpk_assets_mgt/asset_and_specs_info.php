<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php
    include 'classes/config.php';
//    $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
//                        $last_id = $row['MAX(id)'];
//                    }
     if(isset($_REQUEST['id']) && $_REQUEST['id'] != '' && isset($_REQUEST['asset_name']) && !empty($_REQUEST['asset_name']))
    {
         
         
    //get the name and comment entered by user 
    $categoryname = $_REQUEST['category_name'];
    $name = $_REQUEST['asset_name'];
//    $specification = $_REQUEST['specification'];
    $year = $_REQUEST['year'];
    
    //connect to the database
//    $dbc = mysqli_connect('host', 'username', 'password', 'dbname') or die('Error connecting to MySQL server');
    $query = "select * from asset_and_specs WHERE
                            asset_and_specs.`name` = '$name'
                    AND asset_and_specs.category_id = '$categoryname'
                    AND asset_and_specs.specs_year = '$year' AND user_id = '".$_SESSION['uid']."' AND id NOT IN ('".$_REQUEST['id']."')";
//    echo $query;
//    exit;
    $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);
    
   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   } 
   else {  
    
    
                    $id=$_REQUEST['id'];
//    if($_REQUEST['id'] != '')
//    {         
                
		$category_name = $_REQUEST['category_name'];
                
                if(empty($_REQUEST['asset_name']) || $_REQUEST['asset_name']=='' || !isset($_REQUEST['asset_name'])){
                    $asset_name='NULL';
                }
                else{
                    $asset_name = $_REQUEST['asset_name'];
                }
                if(empty($_REQUEST['specification']) || $_REQUEST['specification']=='' || !isset($_REQUEST['specification'])){
                    $specification='NULL';
                }
                else{
                    $specification = $_REQUEST['specification'];
                }
                if(empty($_REQUEST['year']) || $_REQUEST['year']=='' || !isset($_REQUEST['year'])){
                    $year = 'NULL';
                }
                else{
                    $year = $_REQUEST['year'];
                }
                
                $category = $_REQUEST['category_name'];
//                $asset_name = $_REQUEST['asset_name'];
//                $specification = $_REQUEST['specification'];
//                $year = $_REQUEST['year'];
                date_default_timezone_set('Asia/Karachi');
                $updatedtime = date('Y-m-d H:i:s'); 
                $updatedby = $_SESSION['username'];
//		$id = $_REQUEST['id'];
		$query = "UPDATE asset_and_specs SET category_id='$category',name='$asset_name',specification='$specification',specs_year='$year',updated_by = '$updatedby',updated_date = '$updatedtime' WHERE id=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            $response   =   array("chkid"=>"1");
       echo json_encode($response);
    }
}
else if($_SESSION['userid'] != '4' && $_SESSION['userid'] != '6' && isset($_REQUEST['category_name']) && !empty($_REQUEST['category_name'])){
    
    $name = $_REQUEST['asset_name'];
    $categoryname = $_REQUEST['category_name'];
//    $specification = $_REQUEST['specification'];
    $year = $_REQUEST['year'];
    //connect to the database
//    $dbc = mysqli_connect('host', 'username', 'password', 'dbname') or die('Error connecting to MySQL server');
    $query = "select * from asset_and_specs where asset_and_specs.`name` = '$name'
                    AND asset_and_specs.category_id = '$categoryname'
                    AND asset_and_specs.specs_year = '$year' AND user_id = '".$_SESSION['uid']."'";
//    echo $query;
//    exit;
    $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"1");
       echo json_encode($response);
   } 
   else {  
                
                if(empty($_REQUEST['asset_name']) || $_REQUEST['asset_name']=='' || !isset($_REQUEST['asset_name'])){
                    $asset_name='NULL';
                }
                else{
                    $asset_name = $_REQUEST['asset_name'];
                }
                if(empty($_REQUEST['specification']) || $_REQUEST['specification']=='' || !isset($_REQUEST['specification'])){
                    $specification='NULL';
                }
                else{
                    $specification = $_REQUEST['specification'];
                }
                if(empty($_REQUEST['year']) || $_REQUEST['year']=='' || !isset($_REQUEST['year'])){
                    $year = 'NULL';
                }
                else{
                    $year = $_REQUEST['year'];
                }
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
		$category = $_REQUEST['category_name'];
//		$query = "INSERT INTO patient_table (registration_date,name,cnic,gender,age,contact,email,lab,nationality,address,from_c,to_c,arrive,p_id) VALUES ('$registration_date','$name' ,'$cnic','$gender','$age','$contact','$email','$lab','$nationality','$address','$from','$to','$arrive','$p_id')";
                $uid = $_SESSION['uid'];
                $query = "INSERT INTO asset_and_specs (category_id,name,specification,specs_year,status,user_id,inserted_by,inserted_date,updated_by,updated_date)
                VALUES ('$category','$asset_name','$specification','$year','1','$uid','$insertedby','$insertedtime','$insertedby','$insertedtime')";
                
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
        $response   =   array("chkid"=>"0");
       echo json_encode($response);
     }
}
     else if($_SESSION['userid'] == '4' || $_SESSION['userid'] == '6' && isset($_REQUEST['category_name'])){
         $response   =   array("match"=>"2");
            echo json_encode($response);
     }
     
//   }
//     
//}
                    
?>

<?php
if(isset($_POST['operation']))
{ ?>
  <table id="example" class="stripe row-border order-column" style="width:100%;">
        <thead style="color: white;background: #33B23F;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Category</th>
                                                        <th>Asset Name</th>
                                                        <th>Specification</th>
                                                        <th>Specs Year</th>
                                                        <th>Created By</th>
                                                        <th>Created Date</th>
                                                        <th>Modified By</th>
                                                        <th>Modified Date</th>
            <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
                                                        <th>Action</th>
                                                        <th>Status</th>
            <?php }
            ?>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                            asset_and_specs.id,
                                                            asset_and_specs.category_id,
                                                            asset_and_specs.`name`,
                                                            asset_and_specs.specification,
                                                            asset_and_specs.specs_year,
                                                            asset_and_specs.inserted_by,
                                                            asset_and_specs.inserted_date,
                                                            asset_and_specs.updated_by,
                                                            asset_and_specs.updated_date,
                                                            asset_and_specs.user_id,
                                                            asset_and_specs.`status`,
                                                            category.`name` AS category
                                                            FROM
                                                            asset_and_specs
                                                            INNER JOIN category ON asset_and_specs.category_id = category.id
                                                                WHERE asset_and_specs.user_id = '".$_SESSION['uid']."' Order by asset_and_specs.id";
//echo $query;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['specification']; ?></td>
            <td><?php echo $row['specs_year']; ?></td>
            <td><?php echo $row['inserted_by']; ?></td>
            <td><?php echo $row['inserted_date']; ?></td>
            <td><?php echo $row['updated_by']; ?></td>
            <td><?php echo $row['updated_date']; ?></td>
            <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
            <td>
                    <button id="<?php echo $row["id"]; ?>" onclick="update_asset_info(this.id)" class="btn btn-success">Update</button>
            </td>
            <td>
                <?php if($row['status'] == 1)
               {?>
                <button onclick="activeassetsinfo(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactiveassetinfo(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>
            <?php }
            ?>
    		</tr>
<?php
$number++;
        }
    }else {
        
    }
?>

        </tbody>
             </table>
<script>
    $(document).ready(function() {
    $('#example').DataTable({
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        fixedColumns:   {
            leftColumns:2,
            rightColumns: 2
        },
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
} );
    </script>

<?php
}    
?>
