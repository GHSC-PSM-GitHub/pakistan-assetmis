<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php
    include 'classes/config.php';
//    $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
//                        $last_id = $row['MAX(id)'];
//                    }
    if(isset($_POST['fund_sorc_name'])) {

    //get the name and comment entered by user
    $fund_sorc_name = $_REQUEST['fund_sorc_name'];

    //connect to the database
//    $dbc = mysqli_connect('host', 'username', 'password', 'dbname') or die('Error connecting to MySQL server');
    $check=mysqli_query($conn,"select * from funding_source where name='$fund_sorc_name' && user_id = '".$_SESSION['uid']."'");
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   } 
   else {  
     $id=$_REQUEST['id'];
        if($_REQUEST['id'] != '')
    {
                date_default_timezone_set('Asia/Karachi');
                $updatedtime = date('Y-m-d H:i:s'); 
                $updatedby = $_SESSION['username'];
		$fund_sorc_name = $_REQUEST['fund_sorc_name'];
//		$id = $_REQUEST['id'];
		$query = "UPDATE funding_source SET name='$fund_sorc_name',updated_by = '$updatedby',updated_date = '$updatedtime' WHERE id=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
        $response   =   array("chkid"=>"1");
       echo json_encode($response);
	}
else if($_SESSION['userid'] != '4' && $_SESSION['userid'] != '6' ){
                $fund_sorc_name = $_REQUEST['fund_sorc_name'];
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
                $uid = $_SESSION['uid'];
                        
                $query = "INSERT INTO funding_source (name,status,user_id,inserted_by,inserted_date,updated_by,updated_date)
                VALUES ('$fund_sorc_name','1','$uid','$insertedby','$insertedtime','$insertedby','$insertedtime')";
                
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            $response   =   array("chkid"=>"0");
       echo json_encode($response);
 }
 else if($_SESSION['userid'] == '4' || $_SESSION['userid'] == '6' && isset($_REQUEST['fund_sorc_name'])){
         $response   =   array("match"=>"2");
            echo json_encode($response);
     }
    }
}
?>

<?php
if(isset($_POST['operation']))
{ ?>
        <table id="example" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Name</th>
                                                        <th>Created By</th>
                                                        <th>Created Date</th>
                                                        <th>Modified By</th>
                                                        <th>Modified Date</th>
            <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
                                                        <th>Action</th>
                                                        <th>Status</th>
            <?php }
            ?>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                funding_source.id,
                                                                funding_source.`name`,
                                                                funding_source.`status`,
                                                                funding_source.inserted_by,
                                                                funding_source.updated_by,
                                                                funding_source.inserted_date,
                                                                funding_source.updated_date
                                                                FROM
                                                                funding_source
                                                                WHERE user_id = '".$_SESSION['uid']."' Order by funding_source.id";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['inserted_by']; ?></td>
            <td><?php echo $row['inserted_date']; ?></td>
            <td><?php echo $row['updated_by']; ?></td>
            <td><?php echo $row['updated_date']; ?></td>
             <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
            <td>
                     <button id="<?php echo $row["id"]; ?>" onclick="edit_funding_detail(this.id)" class="btn btn-success">Update</button>
            </td>
            <td>
                <?php if($row['status'] == 1)
               {?>
                <button onclick="activefundingsource(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactivefundingsource(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>
            <?php }
            ?>
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
<script>
    $(document).ready(function() {
    $('#example').DataTable({
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
} );
    </script>

<?php
}    
?>
