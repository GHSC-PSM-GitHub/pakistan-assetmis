<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php
    include 'classes/config.php';
//    $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
//                        $last_id = $row['MAX(id)'];
//                    }
    
            
    if(isset($_REQUEST['id']) && $_REQUEST['id'] != '')
    {
        $name = $_POST['manufacturer_name'];
        $query = "select * from manufacturer where name='$name' AND user_id = '".$_SESSION['uid']."' AND id NOT IN ('".$_REQUEST['id']."') ";
//        echo $query;
//        exit;
        $check=mysqli_query($conn,$query);
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   }
   else 
   {
                $id=$_REQUEST['id'];
                date_default_timezone_set('Asia/Karachi');
                $updatedtime = date('Y-m-d H:i:s'); 
                $updatedby = $_SESSION['username'];
                $manufacturer_name = $_REQUEST['manufacturer_name'];
//		$id = $_REQUEST['id'];
		$query = "UPDATE manufacturer SET name='$manufacturer_name',updated_by = '$updatedby',updated_date = '$updatedtime' WHERE id=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            $response   =   array("chkid"=>"1");
       echo json_encode($response);
   }
	}
 else if($_SESSION['userid'] != '4' && $_SESSION['userid'] != '6' && isset($_REQUEST['manufacturer_name'])){
     
     $name = $_POST['manufacturer_name'];
        $check=mysqli_query($conn,"select * from manufacturer where name='$name' AND user_id = '".$_SESSION['uid']."'");
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"1");
       echo json_encode($response);
   }
   else 
   {
       
//       $check=mysqli_query($conn,"SELECT MAX(manufacturer.`code`) AS code FROM manufacturer");
////    $checkrows=mysqli_num_rows($check);
//    while($row = mysqli_fetch_assoc($check))
//    	{
//        $manufacturer_code = 10000 + $row['code'];
//    }
    
		$manufacturer_code =  mt_rand(1000, 9999);
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
                $manufacturer_name = $_REQUEST['manufacturer_name'];
//		$query = "INSERT INTO patient_table (registration_date,name,cnic,gender,age,contact,email,lab,nationality,address,from_c,to_c,arrive,p_id) VALUES ('$registration_date','$name' ,'$cnic','$gender','$age','$contact','$email','$lab','$nationality','$address','$from','$to','$arrive','$p_id')";
                $uid = $_SESSION['uid'];
                $query = "INSERT INTO manufacturer (code,name,status,user_id,inserted_by,inserted_date,updated_by,updated_date)
                VALUES ('$manufacturer_code', '$manufacturer_name','1','$uid','$insertedby','$insertedtime','$insertedby','$insertedtime')";
                
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            $response   =   array("chkid"=>"0");
       echo json_encode($response);
   }
 } else if($_SESSION['userid'] == '4' || $_SESSION['userid'] == '6' && isset($_REQUEST['manufacturer_name'])){
            $response   =   array("match"=>"2");
            echo json_encode($response);
     }

    

    
if(isset($_POST['operation']))
{ ?>
    <table id="example" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <!--<th>Code</th>-->
                                                        <th>Name</th>
                                                        <th>Created By</th>
                                                        <th>Created Date</th>
                                                        <th>Modified By</th>
                                                        <th>Modified Date</th>
             <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
                                                        <th>Action</th>
                                                        <th>Status</th>
            <?php }
            ?>
						</tr>
             </thead>
        <tbody id="table_data">                                    
                                                <?php
                                                $query = "SELECT
                                                            manufacturer.id,
                                                            manufacturer.`code`,
                                                            manufacturer.`name`,
                                                            manufacturer.`status`,
                                                            manufacturer.user_id,
                                                            manufacturer.inserted_by,
                                                            manufacturer.updated_by,
                                                            manufacturer.inserted_date,
                                                            manufacturer.updated_date
                                                            FROM
                                                            manufacturer 
                                                            WHERE user_id = '".$_SESSION['uid']."' Order by manufacturer.id";
//echo $query;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <!--<td><?php // echo $row['code']; ?></td>-->
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['inserted_by']; ?></td>
            <td><?php echo $row['inserted_date']; ?></td>
            <td><?php echo $row['updated_by']; ?></td>
            <td><?php echo $row['updated_date']; ?></td>
            <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
            <td>
                    <button id="<?php echo $row["id"]; ?>" onclick="edit_manufacture_detail(this.id)" class="btn btn-success">Update</button>
            </td>
            <td><?php if($row['status'] == 1)
               {?>
                <button onclick="activemanufacture(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactivemanufacture(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>
                <?php }
                ?>
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
<script>
    $(document).ready(function() {
    $('#example').DataTable({
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
} );
    </script>
<?php
}    
?>

