<?php include 'classes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.JPG">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
        <!-- Bootstrap CSS File  -->
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
             <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.php" class="logo">
                        <span>
                            <img src="assets/images/logo.jpeg" alt="" >
                        </span>
                        <i>
                            <img src="assets/images/logo-sm.jpg" alt="" height="22">
                        </i>
                    </a>
                </div>

                <nav class="navbar-custom">
                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>                        
                        <li class="d-none d-sm-block">
                            <div class="dropdown pt-3 d-inline-block">
                                <a class="waves-effect waves-light" href="#"  aria-haspopup="true" aria-expanded="false">
                                    <h4 style="color: white;">Data Management System</h4>
                                </a>
                                
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </li>
                    </ul>

                </nav>

            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'left_menu.php';?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Assets Repair Management</h4>
<!--                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Agroxa</a></li>
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Forms</a></li>
                                        <li class="breadcrumb-item active">Form Validation</li>
                                    </ol>-->
            
<!--                                    <div class="state-information d-none d-sm-block">
                                        <div class="state-graph">
                                            <div id="header-chart-1"></div>
                                            <div class="info">Balance $ 2,317</div>
                                        </div>
                                        <div class="state-graph">
                                            <div id="header-chart-2"></div>
                                            <div class="info">Item Sold 1230</div>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="page-content-wrapper">
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
            
                                            <!--<h4 class="mt-0 header-title">Range validation</h4>-->
   <form method="POST" action="asset_repair_info.php" id="form_id" autocomplete="off">
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">PO#/Letter#/Ref#</label>
      <input type="text" name="repair_ref_no" placeholder="" class="form-control" id="repair_ref_no" required>
    </div>
     <div class="col-md-2 mb-3">
      <label for="validationDefault03">Date</label>
      <input type="date" name="date" min='2020-01-01' value ="<?php echo date('Y-m-d') ?>" class="form-control" id="date">
    </div>
  </div>
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Description / Details</label>
    <textarea class="form-control" name="repair_detail" id="repair_detail" rows="2"></textarea>
  </div>
        <br>
        <div class="form-row"> 
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Repaired by</label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="repair_by" id="repair_by">
        <option value='Local' selected='selected'>Local</option>
          <?php
   $sel_query1 = "Select gender FROM gender_table";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['gender'].'">'.$row['gender'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault03">Repair Warranty</label>
      <div class="input-group mb-3">
      <input type="text" name="repair_warranty"  minlength = "0" maxlength = "2" class="form-control" id="repair_warranty" value="12">
        <div class="input-group-append">
            <span class="input-group-text" style="background: #60A8F2;color: white;" id="basic-addon2">Months</span>
        </div> 
    </div>
    </div>
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Repair Amount</label>
      <input type="text" name="repair_amount" placeholder="" class="form-control" id="repair_amount" required>
    </div>
            
  </div>
        
         <div class="form-row">
    <label for="exampleFormControlTextarea1">Comments / Remarks</label>
    <textarea class="form-control" name="r_comment" id="r_comment" rows="3"></textarea>
  </div>
            <!--<input type="hidden" id="id" name="id" value="3487">-->
          <div class="modal-footer">
            <button type="submit" href="#lab_history" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Insert</button>
            <a href="asset_form.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
                                            <h3>Records:</h3>
            <div class="check">
             <table id="example" class="display" style="width:100%;background: #2DA467;">
        <thead style="color: white;">
                                                <tr>
							<!--<th>No.</th>-->
                                                        <th>System ID (Auto)</th>
                                                        <th>PO#/ Letter#/ Ref#</th>
                                                        <th>Repair Description</th>
                                                        <th>Repair Date</th>
							<th>Repair By</th>
                                                        <th>Warranty of Repair , if any</th>
                                                        <th>Comments</th>
<!--                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>-->
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                asset_repair_info.id,
                                                                asset_repair_info.repair_po_no,
                                                                asset_repair_info.date,
                                                                asset_repair_info.description,
                                                                asset_repair_info.repaired_by_id,
                                                                asset_repair_info.repair_warrenty,
                                                                asset_repair_info.repair_amount,
                                                                asset_repair_info.`comment`
                                                                FROM
                                                                asset_repair_info
                                                                Order by asset_repair_info.id
                                                    ";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <!--<td><?php echo $number; ?></td>-->
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['repair_po_no']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['repaired_by_id']; ?></td>
            <td><?php echo $row['repair_warrenty']; ?></td>
            <td><?php echo $row['comment']; ?></td>
<!--            <td>
                    <button onclick="GetUserDetails(<?php echo $row['id']; ?>)" class="btn btn-warning">Update</button>
            </td>
            <td>
                    <button onclick="DeleteUser(<?php echo $row['id']; ?>)" class="btn btn-danger">Delete</button>
               <?php if($row['ref_no'] == 1)
               {?>
                <button onclick="active(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>-->
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
            
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->  
                        </div>
                        <!-- end page content-->

                    </div> <!-- container-fluid -->

                </div> <!-- content -->

                <footer class="footer">
                    © 2018 Agroxa <span class="d-none d-sm-inline-block">- Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand.</span>
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- Parsley js -->
        <script src="../plugins/parsleyjs/parsley.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
        <script>
            $(document).ready(function() {
                $('form').parsley();
            });
            
            $(document).ready(function() {
    $('#example').DataTable( {
        initComplete: function () {
            this.api().columns([0,1,2,3,4]).every( function () {
                var column = this;
                var select = $('<select><option value=""></option></select>')
//                    .appendTo( $(column.footer()).empty() )
            .appendTo( $(column.header()) )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
//                    select.append( '<option value="'+d+'">'+d+'</option>' )
select.append('<option value="' + d + '">' + d.substr(0,10) + '</option>')

                } );
            } );
        }
    } );
//        table.column(4).visible(false);
//    table.column(5).visible(false);
//    table.column(6).visible(false);
//    table.column(18).visible(false);
    
} );
            
            
        </script>
    
    </body>

</html>

