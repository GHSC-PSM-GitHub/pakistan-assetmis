<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); 
}
include 'classes/config.php';
$tnumass = "0";
$tassamount = "0";
$purcwarrexp = "0";
$assexp = "0";
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">

        <link rel="stylesheet" href="../plugins/morris/morris.css">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.php" class="logo">
                        <span>
                            <img src="assets/images/logo.png" alt="" >
                        </span>
                        <i>
                            <img src="assets/images/logo-sm.png" alt="" height="22">
                        </i>
                    </a>
                </div>

                <nav class="navbar-custom">

                    <ul class="navbar-right d-flex list-inline float-right mb-0">

                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="index.php" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="noti-icon"> <?php echo $_SESSION['username']; ?></i>
                            </a>
                        </li>
                        <li class="dropdown notification-list">
                            <div class="dropdown notification-list nav-pro-img">
                                <a class="dropdown-toggle nav-link arrow-none waves-effect nav-user waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                    <a class="dropdown-item" href="changepassword.php"><i style="font-size: 15px;" class="mdi mdi-account-circle m-r-5">Change Password</i> <?php // echo $_SESSION['username']; ?></a>
<!--                                    <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5"></i> My Wallet</a>
                                    <a class="dropdown-item d-block" href="#"><span class="badge badge-success float-right">11</span><i class="mdi mdi-settings m-r-5"></i> Settings</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-lock-open-outline m-r-5"></i> Lock screen</a>-->
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php"><i class="mdi mdi-power text-danger"></i> Logout</a>
                                </div>                                                                    
                            </div>
                        </li>

                    </ul>

                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>                       
                    </ul>

                </nav>

            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
                <?php include 'left_menu.php';?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Dashboard</h4>
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item active">Welcome  <?php echo $_SESSION['username']; ?></li>
                                    </ol>
            
<!--                                    <div class="state-information d-none d-sm-block">
                                        <div class="state-graph">
                                            <div id="header-chart-1"></div>
                                            <div class="info">Balance $ 2,317</div>
                                        </div>
                                        <div class="state-graph">
                                            <div id="header-chart-2"></div>
                                            <div class="info">Item Sold 1230</div>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
<?php 
//        $query = "SELECT
//	* from asset_info
//";
////        echo $query;
// $result = mysqli_query($conn,$query) or die(mysql_error());
//// $rows = mysqli_num_rows($result);
////        if($rows==1){
//            if(mysqli_num_rows($result) > 0)
//    {
//    	$tnumass = 1;
//        $tassamount = 0;
//        while($row = mysqli_fetch_assoc($result))
//    {
//            $tassamount += $row['purchase_price'];
//        $tnumass++;
//    }
//    $tnumass;
//}
if($_SESSION['uid'] == '7')
{
$query = "SELECT
	* from asset_info";
}
else if(isset($_SESSION['userid']) && $_SESSION['userid'] == '2' && (empty($_SESSION['did']) || $_SESSION['did'] == 'NULL'))
{
$query = "SELECT
	* from asset_info";
}
else{
    $query = "SELECT
	* from asset_info WHERE user_id = ". $_SESSION['uid']."
";
}
//        echo $query;
 $result = mysqli_query($conn,$query) or die(mysql_error());
// $rows = mysqli_num_rows($result);
//        if($rows==1){
            if(mysqli_num_rows($result) > 0)
    {
    	$tnumass = 0;
        $tassamount = 0;
        while($row = mysqli_fetch_assoc($result))
    {
            $tassamount += $row['purchase_price'];
        $tnumass++;
    }
    $tnumass;
}

if($_SESSION['uid'] == '7')
{
$query = "SELECT
	* from asset_info
WHERE
	 purchase_warranty <=3";
}
else if(isset($_SESSION['userid']) && $_SESSION['userid'] == '2' && (empty($_SESSION['did']) || $_SESSION['did'] == 'NULL'))
{
    $query = "SELECT
	* from asset_info
WHERE
	 purchase_warranty <=3";
}
else{
    $query = "SELECT
	* from asset_info
WHERE
	 purchase_warranty <=3 AND user_id = ".$_SESSION['uid']."";
}
//        echo $query;
 $result = mysqli_query($conn,$query) or die(mysql_error());
// $rows = mysqli_num_rows($result);
//        if($rows==1){
            if(mysqli_num_rows($result) > 0)
    {
    	$purcwarrexp = 0;
        while($row = mysqli_fetch_assoc($result))
    {
//            $purcwarrexp += $row['purchase_warranty'];
            $purcwarrexp++;
    }
    $purcwarrexp;
}

if($_SESSION['uid'] == '7')
{
$query = "SELECT
	*
FROM
	asset_info
WHERE
	purchase_expiry >= NOW() - INTERVAL 3 MONTH
	";
}
else if(isset($_SESSION['userid']) && $_SESSION['userid'] == '2' && (empty($_SESSION['did']) || $_SESSION['did'] == 'NULL'))
{
    $query = "SELECT
	*
FROM
	asset_info
WHERE
	purchase_expiry >= NOW() - INTERVAL 3 MONTH
	";
}
else{
    $query = "SELECT
	*
FROM
	asset_info
WHERE
	purchase_expiry >= NOW() - INTERVAL 3 MONTH
	 AND user_id = ".$_SESSION['uid']."";
}
//        echo $query;
 $result = mysqli_query($conn,$query) or die(mysql_error());
// $rows = mysqli_num_rows($result);
//        if($rows==1){
            if(mysqli_num_rows($result) > 0)
    {
    	$assexp = 0;
        while($row = mysqli_fetch_assoc($result))
    {
//            $purcwarrexp += $row['purchase_warranty'];
            $assexp++;
    }
    $assexp;
}
?>
                        <div class="page-content-wrapper">
                            <div class="row">
                                <div class="col-xl-3 col-md-6">
                                    <div class="card bg-primary mini-stat position-relative">
                                        <div class="card-body">
                                            <div class="mini-stat-desc">
                                                <!--<h6 class="text-uppercase verti-label text-white-50">Total Number of Assets</h6>-->
                                                <div class="text-white">
                                                    <h6 class="text-uppercase mt-0 text-white">Total Number <br> of Assets</h6>
                                                    <center><h3 class="mb-3 mt-0"><?php echo $tnumass; ?></h3></center>
<!--                                                    <div class="">
                                                        <span class="badge badge-light text-info"> +11% </span> <span class="ml-2">From previous period</span>
                                                    </div>-->
                                                </div>
                                                <div class="mini-stat-icon">
                                                    <i class="mdi mdi-table-column-plus-after display-2"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-6">
                                    <div class="card bg-primary mini-stat position-relative">
                                        <div class="card-body">
                                            <div class="mini-stat-desc">
                                                <!--<h6 class="text-uppercase verti-label text-white-50">Total Amount of Assets</h6>-->
                                                <div class="text-white">
                                                    <h6 class="text-uppercase mt-0 text-white">Total Amount <br> of Assets</h6>
                                                    <center><h3 class="mb-3 mt-0"><?php echo number_format($tassamount); ?></h3></center>
<!--                                                    <div class="">
                                                        <span class="badge badge-light text-danger"> -29% </span> <span class="ml-2">From previous period</span>
                                                    </div>-->
                                                </div>
                                                <div class="mini-stat-icon">
                                                    <i class="mdi mdi-clipboard-plus display-2"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-6">
                                    <div class="card bg-primary mini-stat position-relative">
                                        <div class="card-body">
                                            <div class="mini-stat-desc">
                                                <!--<h6 class="text-uppercase verti-label text-white-50">Av. Price</h6>-->
                                                <div class="text-white">
                                                    <h6 class="text-uppercase mt-0 text-white">Repair Warranty <br>Expiring in 3 months</h6>
                                                    <center><h3 class="mb-3 mt-0"><?php echo $purcwarrexp; ?></h3></center>
<!--                                                    <div class="">
                                                        <span class="badge badge-light text-primary"> 0% </span> <span class="ml-2">From previous period</span>
                                                    </div>-->
                                                </div>
                                                <div class="mini-stat-icon">
                                                    <i class="mdi mdi-clock-alert display-2"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-6">
                                    <div class="card bg-primary mini-stat position-relative">
                                        <div class="card-body">
                                            <div class="mini-stat-desc">
                                                <!--<h6 class="text-uppercase verti-label text-white-50">Pr. Sold</h6>-->
                                                <div class="text-white">
                                                    <h6 class="text-uppercase mt-0 text-white">Assets Warranty <br>Expiring in 3 months</h6>
                                                    <center><h3 class="mb-3 mt-0"><?php echo $assexp; ?></h3></center>
<!--                                                    <div class="">
                                                        <span class="badge badge-light text-info"> +89% </span> <span class="ml-2">From previous period</span>
                                                    </div>-->
                                                </div>
                                                <div class="mini-stat-icon">
                                                    <i class="mdi mdi-clock-alert display-2"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->
                            
                            

        
                        </div>
                        <!-- end page content-->

                    </div> <!-- container-fluid -->

                </div> <!-- content -->

                <footer class="footer">
                    <!--© 2018 Agroxa <span class="d-none d-sm-inline-block">- Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand.</span>-->
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- Peity JS -->
        <script src="../plugins/peity/jquery.peity.min.js"></script>

        <script src="../plugins/morris/morris.min.js"></script>
        <script src="../plugins/raphael/raphael-min.js"></script>

        <script src="assets/pages/dashboard.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>

    </body>

</html>