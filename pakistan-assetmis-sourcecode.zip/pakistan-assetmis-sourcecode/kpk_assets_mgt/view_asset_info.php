<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php include 'classes/config.php';

$currently_selected = date('Y'); 
  // Year to start available options at
  $earliest_year = 1990; 
  // Set your latest year you want in the range, in this case we use PHP to just set it to the current year.
  $latest_year = date('Y'); 
  $whType = '';
  $fromdate = date('Y-m-d');
  $todate = date('Y-m-d');
  if(isset($_REQUEST['reg_start_date']))
  {
  $whType =  $_REQUEST['wh_type'];
  $fromdate = $_REQUEST['reg_start_date'];
  $todate = $_REQUEST['reg_end_date'];
  $type = $_REQUEST['wh_type'];
  }
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
        
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
        <!-- Bootstrap CSS File  -->
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

        
        <style>
            .content {display:none;}
.preload { width:100px;
    height: 100px;
    position: fixed;
    top: 50%;
    left: 50%;}
        </style>
    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.php" class="logo">
                        <span>
                            <img src="assets/images/logo.png" alt="" >
                        </span>
                        <i>
                            <img src="assets/images/logo-sm.png" alt="" height="22">
                        </i>
                    </a>
                </div>

                <nav class="navbar-custom">
                    <ul class="navbar-right d-flex list-inline float-right mb-0">

                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="index.php" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="noti-icon"> <?php echo $_SESSION['username']; ?></i>
                                <!--<span class="badge badge-pill badge-info noti-icon-badge">3</span>-->
                            </a>
                        </li>
                        <li class="dropdown notification-list">
                            <div class="dropdown notification-list nav-pro-img">
                                <a class="dropdown-toggle nav-link arrow-none waves-effect nav-user waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-account-circle m-r-5"></i> <?php echo $_SESSION['username']; ?></a>
<!--                                    <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5"></i> My Wallet</a>
                                    <a class="dropdown-item d-block" href="#"><span class="badge badge-success float-right">11</span><i class="mdi mdi-settings m-r-5"></i> Settings</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-lock-open-outline m-r-5"></i> Lock screen</a>-->
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php"><i class="mdi mdi-power text-danger"></i> Logout</a>
                                </div>                                                                    
                            </div>
                        </li>

                    </ul>
                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>                        
                        <li class="d-none d-sm-block">
                            <div class="dropdown pt-3 d-inline-block">
                                <a class="waves-effect waves-light" href="#"  aria-haspopup="true" aria-expanded="false">
                                    <h4 style="color: white;">Configuration Management System</h4>
                                </a>
                                
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </li>
                    </ul>

                </nav>

            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'left_menu.php';?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Detail Report</h4>
<!--                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Agroxa</a></li>
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Forms</a></li>
                                        <li class="breadcrumb-item active">Form Validation</li>
                                    </ol>-->
            
<!--                                    <div class="state-information d-none d-sm-block">
                                        <div class="state-graph">
                                            <div id="header-chart-1"></div>
                                            <div class="info">Balance $ 2,317</div>
                                        </div>
                                        <div class="state-graph">
                                            <div id="header-chart-2"></div>
                                            <div class="info">Item Sold 1230</div>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="page-content-wrapper">
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
            
<?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '3' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '5' || $_SESSION["userid"] == '6')
                {
            ?>
 <form method="POST" action="detail_report.php" id="form_id" autocomplete="off">
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="validationDefault03">From Date </label>
      <input type="text" name="reg_start_date" class="datepicker first form-control" value ="<?php echo $fromdate; ?>"  id="reg_start_date">
    </div>
      <div class="col-md-3 mb-3">
      <label for="validationDefault03">To Date </label>
      <input type="text" name="reg_end_date" class="datepicker second form-control" value ="<?php echo $todate; ?>" id="reg_end_date">
    </div>
      <div class="col-md-3 mb-3">
        <div class="control-group">
            <label>What you Want to look?</label>
            <div class="controls">
                <select name="wh_type" id="wh_type" class="form-control input-sm" required>
                    <!--<option value="">Select</option>-->
                    <option value="1" <?php echo ($whType == 1) ? 'selected="selected"' : ''; ?>>Asset Warranty Expire During Selected Months</option>
                    <option value="2" <?php echo ($whType == 2) ? 'selected="selected"' : ''; ?>>Repair Warranty Expire During Selected Months</option>
                </select>
            </div>
        </div>
     </div>
  </div>
    <input type="hidden" id="id" name="id" value="">
            <!--<input type="hidden" id="id" name="id" value="3487">-->
          <div class="modal-footer">
            <button type="submit" href="#lab_history" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Search</button>
            <a href="detail_report.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
<?php }
?>
                                            <!--<h3>Records:</h3>-->
                                             
            <div class="check">
                <div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
            </div>
            <div class="content" id="all_data">
             
                
               <?php if(isset($_POST['reg_start_date']) && isset($_POST['wh_type']) && $_POST['wh_type'] == '1')
               {                
                   ?>
                <br>
          <i id="btnExport" onclick="fnExcelReport();" class="fa fa-file-excel-o" style="font-size:32px;color:#33B23F;float: right;"></i>
          <br>
          <br>
                <table id="example" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Asset Name</th>
                                                        <th>Serial no</th>
                                                        <th>Asset Location</th>
							<th>Stock Register</th>
                                                        <th>Assigned To</th>
                                                        <th>Depreciation</th>
                                                        <th>Asset Status</th>
                                                        <th>GI Code</th>
                                                        <th>Specification</th>
                                                        <th>Operational Instructions</th>
                                                        <th>Detail Description</th>
                                                        <th>Purchase Year</th>
                                                        <th>Purchase Expiry</th>
                                                        <th>Purchase Warranty</th>
                                                        <th>Purchase Document No</th>
                                                        <th>Purchase Price</th>
                                                        <th>Purchase Type</th>
                                                        <th>Category</th>
                                                        <th>Funding Source</th>
                                                        <th>Manufacturer</th>
                                                        <th>Supplier</th>
                                                        <th>Model</th>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                asset_info.id,
                                                                asset_info.asset_id,
                                                                asset_info.asset_name,
                                                                asset_info.serial_no,
                                                                asset_info.asset_location,
                                                                asset_info.stock_register,
                                                                asset_info.assigned_to,
                                                                asset_info.depreciation,
                                                                asset_info.asset_status,
                                                                asset_info.gl_code,
                                                                asset_info.specification,
                                                                asset_info.oper_inst,
                                                                asset_info.detail_desc,
                                                                asset_info.purchase_year,
                                                                asset_info.purchase_expiry,
                                                                asset_info.purchase_warranty,
                                                                asset_info.purchase_document_no,
                                                                asset_info.purchase_price,
                                                                asset_info.purchase_type_id,
                                                                asset_info.category_id,
                                                                asset_info.funding_source_id,
                                                                asset_info.manufacturer_id,
                                                                asset_info.supplier_id,
                                                                asset_info.model,
                                                                asset_info.`status`,
                                                                warehouses.warehouse_name AS location,
                                                                `status`.`name` AS assetstatus,
                                                                purchase_type.`name` AS purchasetype,
                                                                category.`name` AS category,
                                                                funding_source.`name` AS fundingsource,
                                                                manufacturer.`name` AS manufacturer,
                                                                supplier.`name` AS supplier
                                                        FROM
                                                                asset_info
                                                        INNER JOIN warehouses ON asset_info.asset_location = warehouses.pk_id
                                                        INNER JOIN `status` ON asset_info.asset_status = `status`.id
                                                        INNER JOIN purchase_type ON asset_info.purchase_type_id = purchase_type.id
                                                        INNER JOIN category ON asset_info.category_id = category.id
                                                        INNER JOIN funding_source ON asset_info.funding_source_id = funding_source.id
                                                        INNER JOIN manufacturer ON asset_info.manufacturer_id = manufacturer.id
                                                        INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                        WHERE
                                                                asset_info.purchase_expiry BETWEEN  '$fromdate' AND '$todate' 
                                                                AND asset_info.user_id = '".$_SESSION['uid']."' Order by asset_name";
//                                                echo $query;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo $row['asset_name']; ?></td>
            <td><?php echo $row['serial_no']; ?></td>
            <td><?php echo $row['location']; ?></td>
            <td><?php echo $row['stock_register']; ?></td>
            <td><?php echo $row['assigned_to']; ?></td>
            <td><?php echo $row['depreciation']; ?></td>
            <td><?php echo $row['assetstatus']; ?></td>
            <td><?php echo $row['gl_code']; ?></td>
            <td><?php echo $row['specification']; ?></td>
            <td><?php echo $row['oper_inst']; ?></td>
            <td><?php echo $row['detail_desc']; ?></td>
            <td><?php echo $row['purchase_year']; ?></td>
            <td><?php echo $row['purchase_expiry']; ?></td>
            <td><?php echo $row['purchase_warranty']; ?></td>
            <td><?php echo $row['purchase_document_no']; ?></td>
            <td><?php echo $row['purchase_price']; ?></td>
            <td><?php echo $row['purchasetype']; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['fundingsource']; ?></td>
            <td><?php echo $row['manufacturer']; ?></td>
            <td><?php echo $row['supplier']; ?></td>
            <td><?php echo $row['model']; ?></td>
    	</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
                
               <?php } else if(isset($_POST['reg_start_date']) && isset($_POST['wh_type']) && $_POST['wh_type'] == '2')
               { 
                    $date1 = new DateTime("$fromdate");
                    $date2 = new DateTime("$todate");
                    $interval = $date1->diff($date2);
//                    echo "difference " . $interval->y . " years, " . $interval->m." months, ".$interval->d." days "; 
?>
                   
                <br>
          <i id="btnExport" onclick="fnExcelReport();" class="fa fa-file-excel-o" style="font-size:32px;color:#33B23F;float: right;"></i>
          <br>
          <br>
                <table id="example2" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>PO#/ Letter#/ Ref#</th>
                                                        <th>Repair Description</th>
                                                        <th>Repair Date</th>
                                                        <th>Status</th>
                                                        <th>Quantity</th>
                                                        <th>Warranty of Repair , if any</th>
                                                        <th>Vendor / Supplier</th>
                                                        <th>Comments</th>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                            asset_repair_info.id,
                                                                            asset_repair_info.repair_po_no,
                                                                            asset_repair_info.date,
                                                                            asset_repair_info.description,
                                                                            asset_repair_info.repaired_by_id,
                                                                            asset_repair_info.repair_warrenty,
                                                                            asset_repair_info.repair_amount,
                                                                            asset_repair_info.`comment`,
                                                                            `status`.`name`,
                                                                            asset_repair_info.`quantity`,
                                                                            asset_info.asset_id,
                                                                            supplier.`name` AS supliername
                                                                    FROM
                                                                            asset_repair_info
                                                                    INNER JOIN `status` ON asset_repair_info.`status` = `status`.id
                                                                    INNER JOIN asset_info ON asset_repair_info.asset_no = asset_info.asset_id
                                                                    INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                                    WHERE
                                                                        asset_repair_info.repair_warrenty <= ". $interval->m."
                                                                        AND date BETWEEN '$fromdate' AND '$todate'
                                                            AND asset_info.user_id = '".$_SESSION['uid']."'";
//                                                echo $query;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo $row['repair_po_no']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td><?php echo $row['repair_warrenty']; ?></td>
            <td><?php echo $row['supliername']; ?></td>
            <td><?php echo $row['comment']; ?></td>
    	</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
                
               <?php } 
               ?>
            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->  
                        </div>
                        <!-- end page content-->

                    </div> <!-- container-fluid -->

                </div> <!-- content -->

                <footer class="footer">
<!--                    © 2018 Agroxa <span class="d-none d-sm-inline-block">- Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand.</span>-->
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- Parsley js -->
        <script src="../plugins/parsleyjs/parsley.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script src="js/script.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>-->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script>
            $(document).ready(function() {
$('.second').datepicker({
    dateFormat: "yy-mm-dd" 
});

$(".first").datepicker({
  dateFormat: "yy-mm-dd",
  onSelect: function(date) {
    var date1 = $('.first').datepicker('getDate');
    var date = new Date(Date.parse(date1));
    date.setDate(date.getDate() + 1);
    var newDate = date.toDateString();
    newDate = new Date(Date.parse(newDate));
    $('.second').datepicker("option", "minDate", newDate);
  }
});
    });        
             $(document).ready(function() {
    $(".preload").fadeOut(1000, function() {
        $(".content").fadeIn(500);        
    });
    });
            $(document).ready(function() {
                $('form').parsley();
            });
            
    $(document).ready(function() {
    $('#example').DataTable({
        "scrollY": 300,
        "scrollX": true
    });
} );

$(document).ready(function() {
    $('#example2').DataTable();
} );
// $(document).ready(function(){
//   
// $('#form_id').on('submit', function(event){
////     var id = $('#id').val();
//  event.preventDefault();
//  $.ajax({
//   url:"ajax/detail_report.php",
//   method:"POST",
//   data:$(this).serialize(),
//   success:function(data){
//       fetch_data();
////       alert(id);
//var user = JSON.parse(data);
////alert(user.match);
//        if(user.match == '1' || user.match == '0')
//       {
//            $("#error").show();
//             setTimeout(function() { $("#error").hide(); }, 3000);
//       }else 
//           if(user.match == '2')
//       {
//            $("#restrict").show();
//             setTimeout(function() { $("#restrict").hide(); }, 3000);
//        }
//       else 
//           if(user.chkid == 0)
//       {
//            $("#insert").show();
//             setTimeout(function() { $("#insert").hide(); }, 3000);
//        }
//        else
//        {
//            $("#update").show();
//            setTimeout(function() { $("#update").hide(); }, 3000);
//        }
//    },
//   Error:function(data){
//       alert("Failed to Insert the data");
//   }
//  });
// });
//});
  
//  function fetch_data(){
//    var operations = "fetching_the_data";
//    $.ajax({
//       type:"POST",
//       url:"status_info.php",
//       data:{operation:operations},
//       success:function(data)
//       {
//           $("#all_data").html(data);
//       },
//       Error:function(data)
//       {
//           alert("Failed to retrieve");
//       }
//    });
//}

  
function fnExcelReport()
{
    var tab_text="<table border='2px'><tr bgcolor='#33B23F'>";
    var textRange; var j=0;
    tab = document.getElementById('example'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}
            
        </script>
    
    </body>

</html>




