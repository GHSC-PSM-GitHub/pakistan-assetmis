<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    </head>

    <body>

        <!-- Background -->
        <div class="login-page"></div>

        <!-- Begin page -->
        <div class="wrapper-page">

            <div class="card">
                <div class="card-body">

                    <h3 class="text-center m-0">
                        <a href="index.php" class="logo logo-admin"><img src="assets/images/logo.png" alt="logo"></a>
                    </h3>

                    <div class="p-3">
                        <h4 class="text-muted font-18 mb-3 text-center">Reset Password</h4>
                        <div class="alert alert-info" role="alert">
                            Enter your <b>Email</b> and <b>Password</b> will be sent to you!
                        </div>

                        <form class="form-horizontal m-t-30" method="POST" action="ajax/mail.php">

                            <div class="form-group">
                                <label for="useremail">Email <span style="color:red;">*</span></label>
                                <input type="email" class="form-control" name="useremail" id="useremail" placeholder="Enter email" required>
                            </div>
<!--                             <div class="form-row">
                                <label for="exampleFormControlTextarea1">Detail Description <span style="color:red;">*</span></label>
                                <textarea class="form-control" name="d_description" placeholder="Enter your login details" id="d_description" rows="3" required></textarea>
                              </div>-->

                            <div class="form-group row m-t-20">
                                <div class="col-12 text-right">
                                    <button class="btn btn-primary w-md waves-effect waves-light" type="submit">Reset</button>
                                    <!--<p class="text-muted">Remember It ? <a href="pages-login.html"> Sign In Here </a> </p>-->
                                </div>
                            </div>
                            <div class="m-t-40 text-center">
                                <p class="text-muted">Remember It ? <a href="pages-login.php" style="color: #23A9C6;"> <b>Sign In Here</b> </a> </p>
                                <!--<p class="text-muted">© 2018 Agroxa. Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</p>-->
                            </div>

                        </form>
                    </div>

                </div>
            </div>

<!--            <div class="m-t-40 text-center">
                <p class="text-muted">Remember It ? <a href="pages-login.html" class="text-white"> Sign In Here </a> </p>
                <p class="text-muted">© 2018 Agroxa. Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</p>
            </div>-->

        </div>

        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>

    </body>

</html>