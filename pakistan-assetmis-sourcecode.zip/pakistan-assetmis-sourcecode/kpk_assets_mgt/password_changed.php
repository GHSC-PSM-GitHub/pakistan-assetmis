<?php
include 'classes/config.php';

session_start();
    $id = $_SESSION["uid"];/* userid of the user */
//    $con = mysqli_connect('127.0.0.1:3306','root','','admin') or die('Unable To connect');
    if(count($_POST)>0) {
    $result = mysqli_query($conn,"SELECT * from user WHERE id='" . $id . "'");
    $row=mysqli_fetch_array($result);
    if(md5($_POST["currentPassword"]) == $row["password"] && md5($_POST["newPassword"]) == md5($_POST["confirmPassword"]) ) {
    mysqli_query($conn,"UPDATE user set password='" . md5($_POST["newPassword"]) . "' WHERE id='" . $id . "'");
    ?>
            <script>
                alert("Password Changed Sucessfully");
                window.location.href = "pages-login.php";
            </script>
            <?php
    } else {
//            echo "Message could not be sent...";
            ?>
            <script>
                alert("Password is not correct");
                window.location.href = "changepassword.php";
            </script>
            <?php
         }
    
    }
?>