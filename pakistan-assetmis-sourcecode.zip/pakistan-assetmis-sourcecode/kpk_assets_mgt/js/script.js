function UpdateRole(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_role.php", {
            id : id,
        },
        function (data) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            $("#id").val(user.id);
            $("#role_id").val(user.role_id);
            $("#role_name").val(user.role_name);
            $("#wh_type").val(user.role_level_id);
            $("#access").val(user.access_id);
            $("#add").text('Update');
            $("#role_name" ).focus();
            var dist = new Array(user.district);
            var tehsil = new Array(user.tehsil);
            var uc = new Array(user.uc);
            var hf = new Array(user.hf);
//            alert(dist);
//            dist = user.district;
            showProvUpdate(user.role_level_id,dist);
            showwhTypeUpdate();
//            showDistrictsUpdate(user.province_id);
            showTehsilUpdate(user.province,dist,tehsil);
            showUCUpdate(user.province,dist,tehsil,uc);
            showHFUpdate(user.province,dist,uc,hf);
            if(user.role_level_id != '2' && user.role_level_id != '3' && user.role_level_id != '4' && user.role_level_id != '5' && user.role_level_id != '6' && user.role_level_id != '7')
            {
                $('#province_combo').fadeOut();
                    $('#province').empty();
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
            }
            if(user.role_level_id == '2')
            {
//                $('#province_combo').fadeOut();
//                    $('#province').empty();
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
            }
            if(user.role_level_id == '3')
            {
//                $('#province_combo').fadeOut();
//                    $('#province').empty();
//                    $('#district_combo').fadeOut();
//                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
            }
            if(user.role_level_id == '4')
            {
//                    $('#tehsil_combo').fadeOut();
//                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $('#hf_combo').fadeOut();
                    $('#hf').empty();
            }
            if(user.role_level_id == '5')
            {
                $('#hf_combo').fadeOut();
                    $('#hf').empty();
//                    $('#uc_combo').fadeOut();
//                    $('#uc').empty();
            }
            if(user.role_level_id == '6')
            {
//                    $('#uc_combo').fadeOut();
//                    $('#uc').empty();
            }
        });
}
function UpdateUser(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_user.php", {
            id : id,
        },
        function (data) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            $("#id").val(user.id);
            $("#user_name").val(user.username);
            $("#password").val(user.password);
            $("#cpassword").val(user.password);
            $("#email").val(user.email);
            $("#phone").val(user.phone);
            $("#address").val(user.address);
            $("#login_id").val(user.login_id);
            $("#role_level").val(user.user_role_id);
            $("#submit").text('Update');
            $( "#login_id" ).focus();
        });
}
function activefundingsource(id) {
    var conf = confirm("Are you sure, do you want to inactive?");
    if (conf == true) {
        $.post("ajax/active_funding_source.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "funding_source_mang.php";
            }
        );
    }
}
function inactivefundingsource(id) {
    var conf = confirm("Are you sure, do you want to active?");
    if (conf == true) {
        $.post("ajax/inactive_funding_source.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "funding_source_mang.php";
            }
        );
    }
}
function activepurchase(id) {
    var conf = confirm("Are you sure, do you want to inactive?");
    if (conf == true) {
        $.post("ajax/active_purchase_type.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "purchase_type_mang.php";
            }
        );
    }
}
function inactivepurchase(id) {
    var conf = confirm("Are you sure, do you want to active?");
    if (conf == true) {
        $.post("ajax/inactive_purchase_type.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "purchase_type_mang.php";
            }
        );
    }
}
function activestatus(id) {
    var conf = confirm("Are you sure, do you want to inactive?");
    if (conf == true) {
        $.post("ajax/active_status.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "status_mang.php";
            }
        );
    }
}
function inactivestatus(id) {
    var conf = confirm("Are you sure, do you want to active?");
    if (conf == true) {
        $.post("ajax/inactive_status.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "status_mang.php";
            }
        );
    }
}


function activecategory(id) {
    var conf = confirm("Are you sure, do you want to inactive?");
    if (conf == true) {
        $.post("ajax/active_category.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "category_mang.php";
            }
        );
    }
}
function inactivecategory(id) {
    var conf = confirm("Are you sure, do you want to active?");
    if (conf == true) {
        $.post("ajax/inactive_category.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "category_mang.php";
            }
        );
    }
}


function activeassetsinfo(id) {
    var conf = confirm("Are you sure, do you want to inactive?");
    if (conf == true) {
        $.post("ajax/active_assetinfo.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "asset_and_specs.php";
            }
        );
    }
}

function inactiveassetinfo(id) {
    var conf = confirm("Are you sure, do you want to active?");
    if (conf == true) {
        $.post("ajax/inactive_assetinfo.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "asset_and_specs.php";
            }
        );
    }
}

function activemanufacture(id) {
    var conf = confirm("Are you sure, do you want to inactive?");
    if (conf == true) {
        $.post("ajax/active_manufacture.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "manufacturer_mang.php";
            }
        );
    }
}
function inactivemanufacture(id) {
    var conf = confirm("Are you sure, do you want to active?");
    if (conf == true) {
        $.post("ajax/inactive_manufacture.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "manufacturer_mang.php";
            }
        );
    }
}

function activesup(id) {
    var conf = confirm("Are you sure, do you want to inactive this User?");
    if (conf == true) {
        $.post("ajax/deleteUser.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "supplier_mang.php";
            }
        );
    }
}
function activesup(id) {
    var conf = confirm("Are you sure, do you want to inactive this User?");
    if (conf == true) {
        $.post("ajax/deleteUser.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "supplier_mang.php";
            }
        );
    }
}
function inactivesup(id) {
    var conf = confirm("Are you sure, do you want to active this User?");
    if (conf == true) {
        $.post("ajax/inactiveuser.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "supplier_mang.php";
            }
        );
    }
}

function activeorganization(id) {
    var conf = confirm("Are you sure, do you want to inactive?");
    if (conf == true) {
        $.post("ajax/active_organization.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "organization_mang.php";
            }
        );
    }
}
function inactiveorganization(id) {
    var conf = confirm("Are you sure, do you want to active?");
    if (conf == true) {
        $.post("ajax/inactive_organization.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "organization_mang.php";
            }
        );
    }
}
function activeorganizationwh(id) {
    var conf = confirm("Are you sure, do you want to inactive?");
    if (conf == true) {
        $.post("ajax/active_organization_wh.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "organization_mang.php";
            }
        );
    }
}
function inactiveorganizationwh(id) {
    var conf = confirm("Are you sure, do you want to active?");
    if (conf == true) {
        $.post("ajax/inactive_organization_wh.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                window.location.href= "organization_mang.php";
            }
        );
    }
}

// Add Record
 function addRecordnewlab() {
    var name2 = $("#name2").val();
    $("#lab").append("<option>" + name2 + "</option>");
    $.post("ajax/add_new_lab1.php", {
        name: name2
    }, function (data, status) {
//        alert(data);
//        $("#name2").val(data);
        $("#add_data_Modal2").modal("hide");
//        window.location.href= "../index.php";
//header("location: ../index.php");
    });
    $("#name2").val("");
};
function addRecord() {
    // get values
//    if(document.getElementById('add_new_record_modal').style.display=='block') { 
//            $("#add_new_record_modal").modal("hide");
////            $("#" + add_new_record_modal).off('hidden.bs.modal');
//        } 
    var warehouse_name = $("#warehouse_name").val();
    var province_id= $("#province").val();
    var district_id= $("#districts").val();
    var stak_off_name = $("#stak_off_name").val();
    var stakeholder= $("#stakeholder").val();
    var ware_typ_name= $("#ware_typ_name").val();
    var location= $("#location").val();
//    var last_name = $("#last_name").val();
//    var email = $("#email").val();

    // Add record
    $.post("ajax/addRecord.php", {
        warehouse_name: warehouse_name,
        province_id : province_id,
        district_id : district_id,
        stak_off_name : stak_off_name,
        stakeholder : stakeholder,
        ware_typ_name : ware_typ_name,
        location : location
//        last_name: last_name,
//        email: email
    }, function (data, status) {
        // close the popup
        $("#add_new_record_modal").modal("hide");
//
//        // read records again
        readRecords();
//        // clear fields from the popup
//        $("#warehouse_name").val("");
//        $("#last_name").val("");
//        $("#email").val("");
    });
}

// READ records
function readRecords() {
//    $.get("./manage_warehouse.php", {}, function (data) {
////        reloadTable();
//    $('#example').html(data);
//    //    $('#example').show();
////    location.reload(true);
//
//    });
//   setInterval(function(){
//      $("#header").load('page.php #content_div');
//   }, 10000);
//    var warehouse_name = $("#update_warehouse_name").val();
//    var province_id= $("#province1").val();
//    var district_id= $("#districts1").val();
//    var stak_off_name = $("#stak_off_name1").val();
//    var stakeholder= $("#stakeholder1").val();
//    var ware_typ_name= $("#ware_typ_name1").val();
//    var location= $("#location1").val();
//        var id = $("#hidden_user_id").val();
//
////            var wh_id;
////            var current_year = moment().format('YYYY');
//        //var form = $("#validateSubmitForm").serialize();
//            $.ajax({
//                url: "./manage_warehouse.php",
//                method: "POST",
//                data: {
//                    id: id,
//            warehouse_name: warehouse_name,
//            province_id : province_id,
//            district_id : district_id,
//            stak_off_name : stak_off_name,
//            stakeholder : stakeholder,
//            ware_typ_name : ware_typ_name,
//            location : location
//        },
//                success: function (data) {
////                    id = $(this).data("pk_id");
////                    Id = $('#warehouse_name').val();
//                                               $('.check').html(data);
////                    $('#ddo_data_html').html(data);
////                    contents();
////                    wh_id = $(this).attr('wh_id');
//                }
//            });
//        });
window.location.href= "manage_warehouse.php";
}


function DeleteUser(id) {
    var conf = confirm("Are you sure, do you really want to delete User?");
    if (conf == true) {
        $.post("ajax/deleteUser.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                readRecords();
            }
        );
    }
}
function edit_lab(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_user_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
//            alert(user.contact_name2);
            // Assing existing values to the modal popup fields
            $("#sup_code").val(user.code);
            $("#sup_name").val(user.name);
            $("#sup_con_name").val(user.contact_name);
            $("#sup_con_phone").val(user.contact_phone);
            $("#sup_con_email").val(user.contact_email);
            $("#sup_address").val(user.address);
            $("#sup_con_name2").val(user.contact_name2);
            
            $("#sup_con_phone2").val(user.contact_phone2);
            $("#sup_con_email2").val(user.contact_email2);
            $("#main_address").val(user.address2);
            $("#sup_ntn").val(user.ntn);
            $("#sup_gstn").val(user.gstn);
            $("#id").val(user.id);
            $("#add").text('Update');
            $("#sup_name" ).focus();
            
        });
    // Open modal popup
}
function edit_organization_detail_hf(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_organization_detail_hf.php", {
            id : id,
        },
        function (data) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            id = user.stakeholder_office_id-1;
            if(user.stakeholder_office_id == '6')
            {
                $("#wh_type").val(user.stakeholder_office_id);
                $("#org_name").val(user.warehouse_name);
            
            $("#province").val(user.province_id);
            $("#district").val(user.district_id);
            $("#whid").val(user.pk_id);
            $("#add").text('Update');
            $("#org_name").focus();
            showProvUpdate(user.id_for_update,user.district_id);
//            showDistrictsUpdate(user.province_id);
            showTehsilUpdate(user.province_id,user.district_id,user.parent_id);
            showUCUpdate(user.province_id,user.district_id,user.parent_id,user.location_id);
            }
            
            if(id == '3' && (user.warehouse_type_id == '3' || user.warehouse_type_id == '4'))
            {
                
                $("#wh_type").val(id);
//                $('#province_combo').fadeOut();
//                    $('#province').empty();
//                    $('#district_combo').fadeOut();
//                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $("#org_name").val(user.warehouse_name);
            
            $("#province").val(user.province_id);
            $("#district").val(user.district_id);
            $("#warehouse_type").val(user.warehouse_type_id);
            $("#whid").val(user.pk_id);
            $("#add").text('Update');
            $("#org_name").focus();
            showProvUpdate(user.id_for_update,user.district_id,user.warehouse_type_id);
            showwhTypeUpdate(user.warehouse_type_id);
//            showDistrictsUpdate(user.province_id);
//            showTehsilUpdate(user.province_id,user.district_id,user.parent_id);
//            showUCUpdate(user.province_id,user.district_id,user.parent_id,user.location_id);
            }
            if(id == '4')
            {
                $("#wh_type").val(id);
//                    $('#tehsil_combo').fadeOut();
//                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
                    $("#org_name").val(user.warehouse_name);
            
            $("#province").val(user.province_id);
            $("#district").val(user.district_id);
            $("#whid").val(user.pk_id);
            $("#add").text('Update');
            $("#org_name").focus();
            showProvUpdate(user.id_for_update,user.district_id);
//            showDistrictsUpdate(user.province_id);
            showTehsilUpdate(user.province_id,user.district_id,user.location_id);
//            showUCUpdate(user.province_id,user.district_id,user.parent_id,user.location_id);
            }
            
        });
}
function edit_organization_detail(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_organization_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            
            $("#org_name").val(user.location_name);
            $("#wh_type").val(user.id_for_update);
            $("#province").val(user.province_id);
            $("#district").val(user.district_id);
            $("#tehsil").val(user.parent_id);
            $("#add").text('Update');
            $("#org_name" ).focus();
//            $("#uc").val(user.level);
            $("#id").val(user.pk_id);
//                updateofficeType(whType);
//            alert(user.district_id);
            showProvUpdate(user.id_for_update,user.district_id);
//            showDistrictsUpdate(user.province_id,user.district_id);
            showTehsilUpdate(user.province_id,user.district_id,user.parent_id);
            if(user.id_for_update == '2')
            {
                $('#province_combo').fadeOut();
                    $('#province').empty();
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
            }
            if(user.id_for_update == '3')
            {
//                $('#province_combo').fadeOut();
//                    $('#province').empty();
                    $('#district_combo').fadeOut();
                    $('#district').empty();
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
            }
            if(user.id_for_update == '4')
            {
                    $('#tehsil_combo').fadeOut();
                    $('#tehsil').empty();
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
            }
            if(user.id_for_update == '5')
            {
                    $('#uc_combo').fadeOut();
                    $('#uc').empty();
            }
           
        });
       // Open modal popup
}
function edit_manufacture_detail(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_manufacture_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#manufacturer_code").val(user.code);
            $("#manufacturer_name").val(user.name);
            $("#id").val(user.id);
            $("#add").text('Update');
            $( "#manufacturer_name" ).focus();
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function update_asset_info(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_asset_specs_info.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
//            alert(user.category_id);
            
            // Assing existing values to the modal popup fields
            $("#category_name").val(user.category_id);
            $("#id").val(user.id);
            $("#asset_name").val(user.name);
            $("#specification").val(user.specification);
            $("#year").val(user.specs_year);
            $("#add").text('Update');
            $("#asset_name").focus();
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function edit_category_detail(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_category_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#category_name").val(user.name);
            $("#id").val(user.id);
            $("#asset_name").val(user.asset_name);
            $("#specification").val(user.specification);
            $("#year").val(user.year);
            $("#add").text('Update');
            $("#category_name").focus();
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function info_using_category(){
//    document.body.scrollTop = 90;
//  document.documentElement.scrollTop = 90;
    var id = $('#category').val();
    $.post("ajax/info_using_category.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
//            var user = JSON.parse(data);
//            alert(user.name);
            // Assing existing values to the modal popup fields
            $("#asset_name").html(data);
//            $("#specification").val(user.specification);
//            $("#p_year").val(user.year);
        });
    // Open modal popup
}
function info_using_assetname(){
//            alert('hi');
//    document.body.scrollTop = 90;
//  document.documentElement.scrollTop = 90;
    var id = $('#asset_name').val();
    $.post("ajax/info_using_assetname.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
//            alert(user.specification);
            // Assing existing values to the modal popup fields
//            $("#asset_name").val(user.name);
            $("#specification").val(user.specification);
            $("#specs_year").val(user.specs_year);
            $("#category").val(user.category_name);
            $("#category_id").val(user.category_id);
        });
    // Open modal popup
}
function edit_status_detail(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_status_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#status_name").val(user.name);
            $("#status_code").val(user.code);
            $("#id").val(user.id);
            $("#add").text('Update');
            $("#status_name").focus();
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function edit_purchase_detail(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_purchase_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#pur_type_name").val(user.name);
            $("#id").val(user.id);
            $("#add").text('Update');
            $("#pur_type_name").focus();
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function AddRepairDetail(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/add_repair_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#id").val(user.id);
//            $("#repair_ref_no").val(user.repair_po_no);
//            $("#date").val(user.date);
//            $("#repair_detail").val(user.description);
//            $("#repair_by").val(user.repaired_by_id);
//            $("#repair_warranty").val(user.repair_warrenty);
//            $("#repair_amount").val(user.repair_amount);
//            $("#r_comment").val(user.comment);
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function AddAccessoriesDetail(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/add_accessories_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#id").val(user.id);
            $("#repair_ref_no").val(user.repair_po_no);
            $("#date").val(user.date);
            $("#repair_detail").val(user.description);
            $("#repair_by").val(user.repaired_by_id);
            $("#repair_warranty").val(user.repair_warrenty);
            $("#repair_amount").val(user.repair_amount);
            $("#r_comment").val(user.comment);
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function edit_funding_detail(id){
    document.body.scrollTop = 90;
  document.documentElement.scrollTop = 90;
    $.post("ajax/edit_funding_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#fund_sorc_name").val(user.name);
            $("#id").val(user.id);
            $("#add").text('Update');
            $("#fund_sorc_name").focus();
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function update_repairs(id){
    document.body.scrollTop = 800;
  document.documentElement.scrollTop = 800;
    $.post("ajax/edit_asset_repair.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#id").val(user.id);
            $("#repair_ref_no").val(user.repair_po_no);
            $("#date").val(user.date);
            $("#rstatus").val(user.status);
            $("#repair_detail").val(user.description);
            $("#repair_by").val(user.repaired_by_id);
            $("#repair_warranty").val(user.repair_warrenty);
            $("#repair_amount").val(user.repair_amount);
            $("#rquantity").val(user.quantity);
            $("#r_comment").val(user.comment);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function GetAssetDetails(id){
    $.post("ajax/get_asset_detail.php", {
            id : id,
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
//            alert(user.file);
            if(user.accprice == '' || user.accprice == 'null')
            {
                var accpri = 0;
            }
            else
            {
                var accpri = user.accprice;
            }
            if(user.repamount == '' || user.repamount == 'null')
            {
                var repamount = 0;
            }
            else
            {
                var repamount = user.repamount;
            }
            
            var tcost = Number(user.purchase_price) + Number(accpri) + Number(repamount);
            // Assing existing values to the modal popup fields
//            alert(user.specs_year);
            $("#id").val(user.id);
            $("#specs_year").val(user.specs_year);
            $("#asset_id").val(user.asset_id);
            $("#asset_id1").val(user.asset_id);
//            $("#asset_name").val(user.asset_name);
            $('#asset_name').find('option').remove().end().append($('<option>', {
                value: user.assetid,
                text: user.asset_name
            }));
            $("#category").val(user.category_id);
            $("#manufacturer").val(user.manufacturer_id);
            $("#model").val(user.model);
            $("#supplier").val(user.supplier_id);
            $("#serial_no").val(user.serial_no);
            $("#funding_source").val(user.funding_source_id);
            $("#p_year").val(user.purchase_year);
            $("#expiry").val(user.expire_years);
            $("#warranty").val(user.purchase_warranty);
            $("#purchase_type").val(user.purchase_type_id);
            $("#po_no").val(user.purchase_document_no);
            $("#p_price").val(user.purchase_price);
            $("#loc_of_asset").val(user.asset_location);
            $("#stock_reg").val(user.stock_register);
            $("#ass_to").val(user.assigned_to);
            $("#depreciation").val(user.depreciation);
            $("#asset_status").val(user.asset_status);
            $("#gl_code").val(user.gl_code);
            $("#specification").val(user.specification);
            $("#instructions").val(user.oper_inst);
            $("#d_description").val(user.detail_desc);
            $("#filePHOTO").val(user.file);
            $("#accscost").val(user.accprice);
            $("#rcost").val(user.repamount);
            $("#tprice").val(tcost);
            
            
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function submit_by_id() {
var p_id = document.getElementById("p_id").value;
var cnic = document.getElementById("cnic").value;
var contact = document.getElementById("contact").value;
//document.getElementById("form_id").submit(); //form submission
//alert(" Name : " + name + " n Email : " + email + " n Form Submitted Successfully......");
    // Add User ID to the hidden field for furture usage
//    $("#hidden_user_id").val(id);
    $.post("ajax/readUserDetails.php", {
            p_id : p_id,
            cnic : cnic,
            contact : contact
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#name").val(user.name);
            $("#age").val(user.age);
            $("#email").val(user.email);
            $("#lab").val(user.lab);
            $("#nationality").val(user.nationality);
            $("#address").val(user.address);
            $("#from").val(user.from_c);
            $("#to").val(user.to_c);
            $("#arrive").val(user.arrive);
            $("#patient_id").val(user.patient_id);
//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
}
function GetUserDetails() {
    // Add User ID to the hidden field for furture usage
    $("#hidden_user_id").val(id);
    $.post("ajax/readUserDetails.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            
            // Assing existing values to the modal popup fields
            $("#update_warehouse_name").val(user.warehouse_name);
            $("#province1").val(user.province_id);
            $("#districts1").val(user.district_id);
            $("#stak_off_name1").val(user.stakeholder_office_id);
            $("#stakeholder1").val(user.stakeholder_id);
            $("#ware_typ_name1").val(user.warehouse_type_id);
            $("#location1").val(user.location_id);
//            $("#province_id").val(user.province_name);

//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
    $("#update_user_modal").modal("show");
}

function UpdateUserDetails() {
    // get values
    var warehouse_name = $("#update_warehouse_name").val();
    var province_id= $("#province1").val();
    var district_id= $("#districts1").val();
    var stak_off_name = $("#stak_off_name1").val();
    var stakeholder= $("#stakeholder1").val();
    var ware_typ_name= $("#ware_typ_name1").val();
    var location= $("#location1").val();
//    var last_name = $("#update_last_name").val();
//    var email = $("#update_email").val();

    // get hidden field value
    var id = $("#hidden_user_id").val();

    // Update the details by requesting to the server using ajax
    $.post("ajax/updateUserDetails.php", {
            id: id,
            warehouse_name: warehouse_name,
            province_id : province_id,
            district_id : district_id,
            stak_off_name : stak_off_name,
            stakeholder : stakeholder,
            ware_typ_name : ware_typ_name,
            location : location
//            last_name: last_name,
//            email: email
        },
        function (data, status) {
            // hide modal popup
            $("#update_user_modal").modal("hide");
            // reload Users by using readRecords();
            readRecords();
        }
    );
}

//$(document).ready(function () {
//    // READ recods on page load
//    readRecords(); // calling function
//});


