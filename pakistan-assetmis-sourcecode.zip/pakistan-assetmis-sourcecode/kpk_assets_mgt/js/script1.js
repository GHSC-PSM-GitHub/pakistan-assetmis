// Add Record
function addRecord() {
    // get values
//    if(document.getElementById('add_new_record_modal').style.display=='block') { 
//            $("#add_new_record_modal").modal("hide");
////            $("#" + add_new_record_modal).off('hidden.bs.modal');
//        } 
//    var location_name = $("#warehouse_name").val();
    var province_id= $("#province").val();
    var district_id= $("#districts").val();
    var geo_lvl_name = $("#geo_lvl_name").val();
    var parent_name = $("#parent_name").val();
    var loc_typ_name= $("#loc_typ_name").val();
    var location_name = $("#location_name").val();
//    var last_name = $("#last_name").val();
//    var email = $("#email").val();
    // Add record
    $.post("ajax/addRecord_location.php", {
        location_name: location_name,
        province_id : province_id,
        district_id : district_id,
        geo_lvl_name : geo_lvl_name,
        parent_name : parent_name,
        loc_typ_name : loc_typ_name,
//        location : location
//        last_name: last_name,
//        email: email
    }, function (data, status) {
        // close the popup
        $("#add_new_record_modal").modal("hide");
//
//        // read records again
        readRecords();
//        // clear fields from the popup
//        $("#warehouse_name").val("");
//        $("#last_name").val("");
//        $("#email").val("");
    });
}

// READ records
function readRecords() {
//    $.get("./manage_warehouse.php", {}, function (data) {
////        reloadTable();
//    $('#example').html(data);
//    //    $('#example').show();
////    location.reload(true);
//
//    });
//   setInterval(function(){
//      $("#header").load('page.php #content_div');
//   }, 10000);
//    var warehouse_name = $("#update_warehouse_name").val();
//    var province_id= $("#province1").val();
//    var district_id= $("#districts1").val();
//    var stak_off_name = $("#stak_off_name1").val();
//    var stakeholder= $("#stakeholder1").val();
//    var ware_typ_name= $("#ware_typ_name1").val();
//    var location= $("#location1").val();
//        var id = $("#hidden_user_id").val();
//
////            var wh_id;
////            var current_year = moment().format('YYYY');
//        //var form = $("#validateSubmitForm").serialize();
//            $.ajax({
//                url: "./manage_location.php",
//                method: "POST",
//                data: {
//                    id: id,
//            warehouse_name: warehouse_name,
//            province_id : province_id,
//            district_id : district_id,
//            stak_off_name : stak_off_name,
//            stakeholder : stakeholder,
//            ware_typ_name : ware_typ_name,
//            location : location
//        },
//                success: function (data) {
////                    id = $(this).data("pk_id");
////                    Id = $('#warehouse_name').val();
//                                               $('.check').html(data);
//                    $('#ddo_data_html').html(data);
//                    contents();
//                    wh_id = $(this).attr('wh_id');
//                }
//            });
//        });
window.location.href= "manage_location.php";
}


function active1(id) {
    var conf = confirm("Are you sure, do you really want to inactive this User?");
    if (conf == true) {
        $.post("ajax/deleteUser_location.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                readRecords();
            }
        );
    }
}
function inactive1(id) {
    var conf = confirm("Are you sure, do you want to active this User?");
    if (conf == true) {
        $.post("ajax/inactiveuser_location.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                readRecords();
            }
        );
    }
}
function GetUserDetails(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_user_id").val(id);
    $.post("ajax/readUserDetails_location.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
//            alert(data);
            var user = JSON.parse(data);
            $.ajax({
               
                url: "ajax/getlocation.php",
                method: "POST",
                data: {id: user.district_id},
                success: function (data1) {
//                    id = $(this).data("pk_id");
//                    Id = $('#warehouse_name').val();

                                               $('#parent_name1').html(data1);
//                                               alert(user.location_id);
                                                        $("#parent_name1").val(user.parent_id);
//                    $('#ddo_data_html').html(data);
                    
//                    contents();
//                    wh_id = $(this).attr('wh_id');
                }
            });
            if(user.geo_level_id=='1' || user.geo_level_id=='2')
    {
        $("#districts22").hide();
        $("#parent_name22").hide();
        $("#province22").hide();
    }
    if(user.geo_level_id=='3' || user.geo_level_id=='4')
    {
        $("#districts22").hide();
        $("#parent_name22").hide();
        $("#province22").show();
    }
    if(user.geo_level_id=='5')
    {
        $("#parent_name22").hide();
        $("#province22").show();
        $("#districts22").show();
    }
    if(user.geo_level_id=='6')
    {
        $("#province22").show();
        $("#districts22").show();
        $("#parent_name22").show();
    }
            
            // Assing existing values to the modal popup fields
            $("#update_location_name").val(user.location_name);
            $("#province1").val(user.province_id);
            $("#districts1").val(user.district_id);
            $("#geo_lvl_name1").val(user.geo_level_id);
            $("#parent_name1").val(user.parent_id);
            $("#loc_typ_name1").val(user.location_type_id);
//            $("#province_id").val(user.province_name);

//            $("#update_last_name").val(user.last_name);
//            $("#update_email").val(user.email);
        });
    // Open modal popup
    $("#update_user_modal").modal("show");
}

function UpdateUserDetails() {
    // get values
    var location_name = $("#update_location_name").val();
    var province_id= $("#province1").val();
    var district_id= $("#districts1").val();
    var geo_lvl_name = $("#geo_lvl_name1").val();
    var parent_name= $("#parent_name1").val();
    var loc_typ_name= $("#loc_typ_name1").val();
//    var location= $("#location1").val();
//    var last_name = $("#update_last_name").val();
//    var email = $("#update_email").val();

    // get hidden field value
    var id = $("#hidden_user_id").val();

    // Update the details by requesting to the server using ajax
    $.post("ajax/updateUserDetails_location.php", {
            id: id,
            location_name: location_name,
            province_id : province_id,
            district_id : district_id,
            geo_lvl_name : geo_lvl_name,
            parent_name : parent_name,
            loc_typ_name : loc_typ_name
//            location : location
//            last_name: last_name,
//            email: email
        },
        function (data, status) {
            // hide modal popup
            $("#update_user_modal").modal("hide");
            // reload Users by using readRecords();
            readRecords();
        }
    );
}

//$(document).ready(function () {
//    // READ recods on page load
//    readRecords(); // calling function
//});


