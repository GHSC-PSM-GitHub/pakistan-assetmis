<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php include 'classes/config.php';
$manufacturerid = '';
$statusid = '';
$fundingsourceid = '';
$supplierid = '';
$categoryid = '';
$purchtypeid = '';
if(isset($_REQUEST['wh_type']) && $_REQUEST['wh_type'] == '3')
{
    $manufacturerid = 'GROUP BY asset_info.manufacturer_id';
}
if(isset($_REQUEST['wh_type']) && $_REQUEST['wh_type'] == '4')
{
    $statusid = 'GROUP BY asset_info.asset_status';
}
if(isset($_REQUEST['wh_type']) && $_REQUEST['wh_type'] == '5')
{
    $fundingsourceid = 'GROUP BY asset_info.funding_source_id';
}
if(isset($_REQUEST['wh_type']) && $_REQUEST['wh_type'] == '6')
{
    $supplierid = 'GROUP BY asset_info.supplier_id';
}
if(isset($_REQUEST['wh_type']) && $_REQUEST['wh_type'] == '7')
{
    $categoryid = 'GROUP BY asset_info.category_id';
}
if(isset($_REQUEST['wh_type']) && $_REQUEST['wh_type'] == '8')
{
    $purchtypeid = 'GROUP BY asset_info.purchase_type_id';
}
$res3="SELECT
        manufacturer.id,
        manufacturer.`code`,
        manufacturer.`name`,
        manufacturer.`status`,
        manufacturer.user_id
        FROM
        manufacturer
        WHERE user_id = '".$_SESSION['uid']."'";

$result5 = mysqli_query($conn, $res3);
$res1="SELECT
        `status`.id,
        `status`.`code`,
        `status`.`name`,
        `status`.`status`,
        `status`.user_id
        FROM
        `status`
        WHERE user_id = '".$_SESSION['uid']."'";

$result1 = mysqli_query($conn, $res1);
$res2="SELECT
            funding_source.id,
            funding_source.`name`,
            funding_source.`status`,
            funding_source.user_id
    FROM
            funding_source
        WHERE user_id = '".$_SESSION['uid']."'";

$res7="SELECT
	category.id,
	category.`name`,
	category.`status`,
	category.user_id
FROM
	category
        WHERE user_id = '".$_SESSION['uid']."'";

$result7 = mysqli_query($conn, $res7);


$result2 = mysqli_query($conn, $res2);


$currently_selected = date('Y'); 
  // Year to start available options at
  $earliest_year = 1990; 
  // Set your latest year you want in the range, in this case we use PHP to just set it to the current year.
  $latest_year = date('Y'); 
  $whType = '';
  $fromdate = date('Y-m-d');
  $todate = date('Y-m-d');
  if(isset($_REQUEST['reg_start_date']))
  {
  $whType =  $_REQUEST['wh_type'];
  $fromdate = $_REQUEST['reg_start_date'];
  $todate = $_REQUEST['reg_end_date'];
  $type = $_REQUEST['wh_type'];
  }
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
        
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
        <!-- Bootstrap CSS File  -->
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        
        <link rel="stylesheet" href="assets/js/jquery-ui.css">
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<!--<script src="assets/js/jquery-ui.js"></script>-->
        
        <style>
            a.menu_links { cursor: pointer; }
            .content {display:none;}
.preload { width:100px;
    height: 100px;
    position: fixed;
    top: 50%;
    left: 50%;}
        </style>
    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.php" class="logo">
                        <span>
                            <img src="assets/images/logo.png" alt="" >
                        </span>
                        <i>
                            <img src="assets/images/logo-sm.png" alt="" height="22">
                        </i>
                    </a>
                </div>

                <nav class="navbar-custom">
                    <ul class="navbar-right d-flex list-inline float-right mb-0">

                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="index.php" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="noti-icon"> <?php echo $_SESSION['username']; ?></i>
                                <!--<span class="badge badge-pill badge-info noti-icon-badge">3</span>-->
                            </a>
                        </li>
                        <li class="dropdown notification-list">
                            <div class="dropdown notification-list nav-pro-img">
                                <a class="dropdown-toggle nav-link arrow-none waves-effect nav-user waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                   <a class="dropdown-item" href="changepassword.php"><i style="font-size: 15px;" class="mdi mdi-account-circle m-r-5">Change Password</i> <?php // echo $_SESSION['username']; ?></a>
<!--                                    <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5"></i> My Wallet</a>
                                    <a class="dropdown-item d-block" href="#"><span class="badge badge-success float-right">11</span><i class="mdi mdi-settings m-r-5"></i> Settings</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-lock-open-outline m-r-5"></i> Lock screen</a>-->
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php"><i class="mdi mdi-power text-danger"></i> Logout</a>
                                </div>                                                                    
                            </div>
                        </li>

                    </ul>
                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>                        
                        <li class="d-none d-sm-block">
                            <div class="dropdown pt-3 d-inline-block">
                                <a class="waves-effect waves-light" href="#"  aria-haspopup="true" aria-expanded="false">
                                    <h4 style="color: white;">Reports</h4>
                                </a>
                                
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </li>
                    </ul>

                </nav>

            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'left_menu.php';?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Summary at Glance</h4>
<!--                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Agroxa</a></li>
                                        <li class="breadcrumb-item"><a href="javascript:void(0);">Forms</a></li>
                                        <li class="breadcrumb-item active">Form Validation</li>
                                    </ol>-->
            
<!--                                    <div class="state-information d-none d-sm-block">
                                        <div class="state-graph">
                                            <div id="header-chart-1"></div>
                                            <div class="info">Balance $ 2,317</div>
                                        </div>
                                        <div class="state-graph">
                                            <div id="header-chart-2"></div>
                                            <div class="info">Item Sold 1230</div>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="page-content-wrapper">
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
            
<?php // if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '3' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '5' || $_SESSION["userid"] == '6')
//                {
            ?>
<form method="POST" action="summary_detail.php" id="form_id" autocomplete="off">
  <div class="form-row">
    <div class="col-md-3 mb-3">
      <label for="validationDefault03">From Date </label>
      <input type="text" name="reg_start_date" class="datepicker first form-control" value ="<?php echo $fromdate; ?>"  id="reg_start_date">
    </div>
      <div class="col-md-3 mb-3">
      <label for="validationDefault03">To Date </label>
      <input type="text" name="reg_end_date" class="datepicker second form-control" value ="<?php echo $todate; ?>" id="reg_end_date">
    </div>
      <div class="col-md-3 mb-3">
        <div class="control-group">
            <label>Search for</label>
            <div class="controls">
                <select name="wh_type" id="wh_type" class="form-control" required>
                    <!--<option value="">Select</option>-->
                    <option value="1" <?php echo ($whType == 1) ? 'selected="selected"' : ''; ?>>Asset</option>
                    <option value="7" <?php echo ($whType == 7) ? 'selected="selected"' : ''; ?>>Category</option>
                    <option value="5" <?php echo ($whType == 5) ? 'selected="selected"' : ''; ?>>Funding Source</option>
                    <option value="3" <?php echo ($whType == 3) ? 'selected="selected"' : ''; ?>>Manufacturer</option>
                    <option value="8" <?php echo ($whType == 8) ? 'selected="selected"' : ''; ?>>Purchase Type</option>
                    <option value="2" <?php echo ($whType == 2) ? 'selected="selected"' : ''; ?>>Repair</option>
                    <option value="4" <?php echo ($whType == 4) ? 'selected="selected"' : ''; ?>>Status</option>
                    <option value="6" <?php echo ($whType == 6) ? 'selected="selected"' : ''; ?>>Supplier</option>
                </select>
            </div>
        </div>
     </div>
<!--      <div class="col-md-3 mb-3" id="manufacturer_combo" style="display:none;">
    <div class="control-group">
        <label>Manufacturer</label>
        <div class="controls">
            <select name="manufacturer" id="manufacturer" class="form-control">
                <option value="">Select</option>
                     <?php  
                        while($row=mysqli_fetch_array($result5))
            {
            ?>
            <option value="<?php echo $row['id'];?>"<?php echo (isset($_REQUEST['manufacturer']) && $_REQUEST['manufacturer'] == $row['id']) ? 'selected="selected"' : ''; ?>><?php echo $row['name']; ?></option>
            <?php
            }
            ?>   
            </select>
        </div>
    </div>
    </div>
      <div class="col-md-3 mb-3" id="status_combo" style="display:none;">
    <div class="control-group">
        <label>Status</label>
        <div class="controls">
            <select name="status" id="status" class="form-control">
                   <option value="">Select</option>
                     <?php  
                        while($row=mysqli_fetch_array($result1))
            {
            ?>
            <option value="<?php echo $row['id'];?>"<?php echo (isset($_REQUEST['status']) && $_REQUEST['status'] == $row['id']) ? 'selected="selected"' : ''; ?>><?php echo $row['name']; ?></option>
            <?php
            }
            ?>   
            </select>
        </div>
    </div>
    </div>
      <div class="col-md-3 mb-3" id="fundsorc_combo" style="display:none;">
    <div class="control-group">
        <label>Funding Source</label>
        <div class="controls">
            <select name="fundsorc" id="fundsorc" class="form-control">
                  <option value="">Select</option>
                     <?php  
                        while($row=mysqli_fetch_array($result2))
            {
            ?>
            <option value="<?php echo $row['id'];?>"<?php echo (isset($_REQUEST['fundsorc']) && $_REQUEST['fundsorc'] == $row['id']) ? 'selected="selected"' : ''; ?>><?php echo $row['name']; ?></option>
            <?php
            }
            ?>   
            </select>
        </div>
    </div>
    </div>
      <div class="col-md-3 mb-3" id="category_combo" style="display:none;">
    <div class="control-group">
        <label>Category</label>
        <div class="controls">
            <select name="category" id="category" class="form-control">
                  <option value="">Select</option>
                     <?php  
                        while($row=mysqli_fetch_array($result7))
            {
            ?>
            <option value="<?php echo $row['id'];?>"<?php echo (isset($_REQUEST['category']) && $_REQUEST['category'] == $row['id']) ? 'selected="selected"' : ''; ?>><?php echo $row['name']; ?></option>
            <?php
            }
            ?>   
            </select>
        </div>
    </div>
    </div>-->
  </div>
    <input type="hidden" id="id" name="id" value="">
            <!--<input type="hidden" id="id" name="id" value="3487">-->
          <div class="modal-footer">
            <button type="submit" href="#lab_history" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Search</button>
            <a href="summary_detail.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
<?php // }
?>
                                            <!--<h3>Records:</h3>-->
                                             
            <div class="check">
                <div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
            </div>
            <div class="content" id="all_data">
             
                
               <?php
               
               $placesinfo = "";
                if($_SESSION["userid"] == '2' && ($_SESSION['district'] == '' || $_SESSION['district'] == 'NULL'))
                {
                    $placesinfo = "";
                }
                else{
                    $placesinfo = "AND role.district IN ('" .$_SESSION['district'] . "')
                        AND role.hf IN ('" . $_SESSION['hf'] . "')
                        AND role.tehsil IN ('" . $_SESSION['tehsil'] . "')
                        AND role.uc IN ('" . $_SESSION['uc'] . "')";
                }
               
               if(isset($_POST['reg_start_date']) && isset($_POST['wh_type']) && $_POST['wh_type'] == '1')
               {                
                   ?>
                <br>
          <i id="btnExport" onclick="fnExcelReport();" class="fa fa-file-excel-o" style="font-size:32px;color:#33B23F;float: right;"></i>
          <br>
          <br>
                <table id="example" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Name</th>
                                                        <th>Total Assets</th>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
          if($_SESSION["userid"] == '2')
           {
                                                $query = "SELECT
                                                                count(asset_info.id) totalasset,
                                                                asset_info.asset_id,
                                                                asset_info.asset_name,
                                                                asset_info.serial_no,
                                                                asset_info.asset_location,
                                                                asset_info.stock_register,
                                                                asset_info.assigned_to,
                                                                asset_info.depreciation,
                                                                asset_info.asset_status,
                                                                asset_info.gl_code,
                                                                asset_info.specification,
                                                                asset_info.oper_inst,
                                                                asset_info.detail_desc,
                                                                asset_info.purchase_year,
                                                                asset_info.purchase_expiry,
                                                                asset_info.purchase_warranty,
                                                                asset_info.purchase_document_no,
                                                                asset_info.purchase_price,
                                                                asset_info.purchase_type_id,
                                                                asset_info.category_id,
                                                                asset_info.funding_source_id,
                                                                asset_info.manufacturer_id,
                                                                asset_info.supplier_id,
                                                                asset_info.model,
                                                                asset_info.`status`,
                                                                warehouses.warehouse_name AS location,
                                                                `status`.`name` AS assetstatus,
                                                                purchase_type.`name` AS purchasetype,
                                                                category.`name` AS category,
                                                                funding_source.`name` AS fundingsource,
                                                                manufacturer.`name` AS manufacturer,
                                                                supplier.`name` AS supplier
                                                        FROM
                                                                asset_info
                                                        INNER JOIN warehouses ON asset_info.asset_location = warehouses.pk_id
                                                        INNER JOIN `status` ON asset_info.asset_status = `status`.id
                                                        INNER JOIN purchase_type ON asset_info.purchase_type_id = purchase_type.id
                                                        INNER JOIN category ON asset_info.category_id = category.id
                                                        INNER JOIN funding_source ON asset_info.funding_source_id = funding_source.id
                                                        INNER JOIN manufacturer ON asset_info.manufacturer_id = manufacturer.id
                                                        INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                        INNER JOIN `user` ON asset_info.user_id = `user`.id
                                                        INNER JOIN role ON `user`.user_role_id = role.id
                                                        WHERE
                                                                asset_info.inserted_date >= '$fromdate' AND asset_info.inserted_date <='$todate 23:59:59.999' 
                                                                $placesinfo 
                                                                Order by asset_name";
           }
            else if($_SESSION["userid"] == ''){
                $query = "SELECT
                                                                count(asset_info.id) totalasset,
                                                                asset_info.asset_id,
                                                                asset_info.asset_name,
                                                                asset_info.serial_no,
                                                                asset_info.asset_location,
                                                                asset_info.stock_register,
                                                                asset_info.assigned_to,
                                                                asset_info.depreciation,
                                                                asset_info.asset_status,
                                                                asset_info.gl_code,
                                                                asset_info.specification,
                                                                asset_info.oper_inst,
                                                                asset_info.detail_desc,
                                                                asset_info.purchase_year,
                                                                asset_info.purchase_expiry,
                                                                asset_info.purchase_warranty,
                                                                asset_info.purchase_document_no,
                                                                asset_info.purchase_price,
                                                                asset_info.purchase_type_id,
                                                                asset_info.category_id,
                                                                asset_info.funding_source_id,
                                                                asset_info.manufacturer_id,
                                                                asset_info.supplier_id,
                                                                asset_info.model,
                                                                asset_info.`status`,
                                                                warehouses.warehouse_name AS location,
                                                                `status`.`name` AS assetstatus,
                                                                purchase_type.`name` AS purchasetype,
                                                                category.`name` AS category,
                                                                funding_source.`name` AS fundingsource,
                                                                manufacturer.`name` AS manufacturer,
                                                                supplier.`name` AS supplier
                                                        FROM
                                                                asset_info
                                                        INNER JOIN warehouses ON asset_info.asset_location = warehouses.pk_id
                                                        INNER JOIN `status` ON asset_info.asset_status = `status`.id
                                                        INNER JOIN purchase_type ON asset_info.purchase_type_id = purchase_type.id
                                                        INNER JOIN category ON asset_info.category_id = category.id
                                                        INNER JOIN funding_source ON asset_info.funding_source_id = funding_source.id
                                                        INNER JOIN manufacturer ON asset_info.manufacturer_id = manufacturer.id
                                                        INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                        WHERE
                                                                asset_info.inserted_date >= '$fromdate' AND asset_info.inserted_date <='$todate 23:59:59.999' 
                                                                Order by asset_name";
            }
           else{
                 $query = "SELECT
                                                                count(asset_info.id) totalasset,
                                                                asset_info.asset_id,
                                                                asset_info.asset_name,
                                                                asset_info.serial_no,
                                                                asset_info.asset_location,
                                                                asset_info.stock_register,
                                                                asset_info.assigned_to,
                                                                asset_info.depreciation,
                                                                asset_info.asset_status,
                                                                asset_info.gl_code,
                                                                asset_info.specification,
                                                                asset_info.oper_inst,
                                                                asset_info.detail_desc,
                                                                asset_info.purchase_year,
                                                                asset_info.purchase_expiry,
                                                                asset_info.purchase_warranty,
                                                                asset_info.purchase_document_no,
                                                                asset_info.purchase_price,
                                                                asset_info.purchase_type_id,
                                                                asset_info.category_id,
                                                                asset_info.funding_source_id,
                                                                asset_info.manufacturer_id,
                                                                asset_info.supplier_id,
                                                                asset_info.model,
                                                                asset_info.`status`,
                                                                warehouses.warehouse_name AS location,
                                                                `status`.`name` AS assetstatus,
                                                                purchase_type.`name` AS purchasetype,
                                                                category.`name` AS category,
                                                                funding_source.`name` AS fundingsource,
                                                                manufacturer.`name` AS manufacturer,
                                                                supplier.`name` AS supplier
                                                        FROM
                                                                asset_info
                                                        INNER JOIN warehouses ON asset_info.asset_location = warehouses.pk_id
                                                        INNER JOIN `status` ON asset_info.asset_status = `status`.id
                                                        INNER JOIN purchase_type ON asset_info.purchase_type_id = purchase_type.id
                                                        INNER JOIN category ON asset_info.category_id = category.id
                                                        INNER JOIN funding_source ON asset_info.funding_source_id = funding_source.id
                                                        INNER JOIN manufacturer ON asset_info.manufacturer_id = manufacturer.id
                                                        INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                        WHERE
                                                                asset_info.inserted_date >= '$fromdate' AND asset_info.inserted_date <='$todate 23:59:59.999' 
                                                                AND asset_info.user_id = '".$_SESSION['uid']."' Order by asset_name";
           }
//                                                echo $query;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo 'Assets'; ?></td>
            <td style="text-decoration: underline;"><a class="menu_links" onclick="window.open('<?php echo 'asset_detail.php?date1='.$fromdate.'&date2='.$todate ?>','Asset Detail','height=500,width=700,left=10,top=10,,scrollbars=yes,menubar=no'); return false;"><?php echo $row['totalasset']; ?></a></td>
    	</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
                
               <?php } else if(isset($_POST['reg_start_date']) && isset($_POST['wh_type']) && $_POST['wh_type'] == '2')
               { 
                    $date1 = new DateTime("$fromdate");
                    $date2 = new DateTime("$todate");
                    $interval = $date1->diff($date2);
//                    echo "difference " . $interval->y . " years, " . $interval->m." months, ".$interval->d." days "; 
?>
                   
                <br>
          <i id="btnExport" onclick="fnExcelReport();" class="fa fa-file-excel-o" style="font-size:32px;color:#33B23F;float: right;"></i>
          <br>
          <br>
                <table id="example2" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Name</th>
                                                        <th>Total Repair</th>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
           if($_SESSION["userid"] == '2')
           {
                                                $query = "SELECT
                                                                            COUNT(asset_repair_info.id) totalrepair,
                                                                            asset_repair_info.repair_po_no,
                                                                            asset_repair_info.date,
                                                                            asset_repair_info.description,
                                                                            asset_repair_info.repaired_by_id,
                                                                            asset_repair_info.repair_warrenty,
                                                                            asset_repair_info.repair_amount,
                                                                            asset_repair_info.`comment`,
                                                                            `status`.`name`,
                                                                            asset_repair_info.`quantity`,
                                                                            asset_info.asset_id,
                                                                            supplier.`name` AS supliername
                                                                    FROM
                                                                            asset_repair_info
                                                                    INNER JOIN `status` ON asset_repair_info.`status` = `status`.id
                                                                    INNER JOIN asset_info ON asset_repair_info.asset_no = asset_info.asset_id
                                                                    INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                                    INNER JOIN `user` ON asset_info.user_id = `user`.id
                                                                    INNER JOIN role ON `user`.user_role_id = role.id
                                                                    WHERE
                                                                        date BETWEEN '$fromdate' AND '$todate'
                                                                        $placesinfo";
           }
           else if($_SESSION["userid"] == ''){
               $query = "SELECT
                                                                            COUNT(asset_repair_info.id) totalrepair,
                                                                            asset_repair_info.repair_po_no,
                                                                            asset_repair_info.date,
                                                                            asset_repair_info.description,
                                                                            asset_repair_info.repaired_by_id,
                                                                            asset_repair_info.repair_warrenty,
                                                                            asset_repair_info.repair_amount,
                                                                            asset_repair_info.`comment`,
                                                                            `status`.`name`,
                                                                            asset_repair_info.`quantity`,
                                                                            asset_info.asset_id,
                                                                            supplier.`name` AS supliername
                                                                    FROM
                                                                            asset_repair_info
                                                                    INNER JOIN `status` ON asset_repair_info.`status` = `status`.id
                                                                    INNER JOIN asset_info ON asset_repair_info.asset_no = asset_info.asset_id
                                                                    INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                                    WHERE
                                                                        date BETWEEN '$fromdate' AND '$todate'
                                                                        ";
           }
           else{
               $query = "SELECT
                                                                            COUNT(asset_repair_info.id) totalrepair,
                                                                            asset_repair_info.repair_po_no,
                                                                            asset_repair_info.date,
                                                                            asset_repair_info.description,
                                                                            asset_repair_info.repaired_by_id,
                                                                            asset_repair_info.repair_warrenty,
                                                                            asset_repair_info.repair_amount,
                                                                            asset_repair_info.`comment`,
                                                                            `status`.`name`,
                                                                            asset_repair_info.`quantity`,
                                                                            asset_info.asset_id,
                                                                            supplier.`name` AS supliername
                                                                    FROM
                                                                            asset_repair_info
                                                                    INNER JOIN `status` ON asset_repair_info.`status` = `status`.id
                                                                    INNER JOIN asset_info ON asset_repair_info.asset_no = asset_info.asset_id
                                                                    INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                                    WHERE
                                                                        date BETWEEN '$fromdate' AND '$todate'
                                                            AND asset_info.user_id = '".$_SESSION['uid']."'";
           }
//                                                echo $query;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo 'Repair'; ?></td>
            <td style="text-decoration: underline;"><a class="menu_links" onclick="window.open('<?php echo 'repair_detail.php?date1='.$fromdate.'&date2='.$todate ?>','Repair Detail','height=500,width=700,left=10,top=10,,scrollbars=yes,menubar=no'); return false;"><?php echo $row['totalrepair']; ?></a></td>
    	</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
                
               <?php }  else if(isset($_POST['reg_start_date']) && isset($_POST['wh_type']) && ($_POST['wh_type'] == '3' || $_POST['wh_type'] == '4' || $_POST['wh_type'] == '5' || $_POST['wh_type'] == '6' || $_POST['wh_type'] == '7' || $_POST['wh_type'] == '8'))
               { 
                    $date1 = new DateTime("$fromdate");
                    $date2 = new DateTime("$todate");
                    $interval = $date1->diff($date2);
//                    echo "difference " . $interval->y . " years, " . $interval->m." months, ".$interval->d." days "; 
?>
                   
                <br>
          <i id="btnExport" onclick="fnExcelReport();" class="fa fa-file-excel-o" style="font-size:32px;color:#33B23F;float: right;"></i>
          <br>
          <br>
                <table id="example3" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Name</th>
                                                        <th>Total</th>
						</tr>
             </thead>
        <tbody>                                   
                                                 <?php
         if($_SESSION["userid"] == '2')
           {
                                                $query = "SELECT
                                                                 count(asset_info.id) totalasset,
                                                                asset_info.asset_id,
                                                                asset_info.asset_name,
                                                                asset_info.serial_no,
                                                                asset_info.asset_location,
                                                                asset_info.stock_register,
                                                                asset_info.assigned_to,
                                                                asset_info.depreciation,
                                                                asset_info.asset_status,
                                                                asset_info.gl_code,
                                                                asset_info.specification,
                                                                asset_info.oper_inst,
                                                                asset_info.detail_desc,
                                                                asset_info.purchase_year,
                                                                asset_info.purchase_expiry,
                                                                asset_info.purchase_warranty,
                                                                asset_info.purchase_document_no,
                                                                asset_info.purchase_price,
                                                                asset_info.purchase_type_id,
                                                                asset_info.category_id,
                                                                asset_info.funding_source_id,
                                                                asset_info.manufacturer_id,
                                                                asset_info.supplier_id,
                                                                asset_info.model,
                                                                asset_info.`status`,
                                                                warehouses.warehouse_name AS location,
                                                                `status`.`name` AS assetstatus,
                                                                purchase_type.`name` AS purchasetype,
                                                                category.`name` AS category,
                                                                funding_source.`name` AS fundingsource,
                                                                manufacturer.`name` AS manufacturer,
                                                                supplier.`name` AS supplier
                                                        FROM
                                                                asset_info
                                                        INNER JOIN warehouses ON asset_info.asset_location = warehouses.pk_id
                                                        INNER JOIN `status` ON asset_info.asset_status = `status`.id
                                                        INNER JOIN purchase_type ON asset_info.purchase_type_id = purchase_type.id
                                                        INNER JOIN category ON asset_info.category_id = category.id
                                                        INNER JOIN funding_source ON asset_info.funding_source_id = funding_source.id
                                                        INNER JOIN manufacturer ON asset_info.manufacturer_id = manufacturer.id
                                                        INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                        INNER JOIN `user` ON asset_info.user_id = `user`.id
                                                        INNER JOIN role ON `user`.user_role_id = role.id
                                                        WHERE
                                                                asset_info.inserted_date >= '$fromdate' AND asset_info.inserted_date <='$todate 23:59:59.999'
                                                                            $placesinfo
                                                                            $manufacturerid
                                                                            $statusid
                                                                            $fundingsourceid
                                                                            $supplierid
                                                                            $categoryid
                                                                            $purchtypeid";
           }
           else if($_SESSION["userid"] == ''){
               $query = "SELECT
                                                                 count(asset_info.id) totalasset,
                                                                asset_info.asset_id,
                                                                asset_info.asset_name,
                                                                asset_info.serial_no,
                                                                asset_info.asset_location,
                                                                asset_info.stock_register,
                                                                asset_info.assigned_to,
                                                                asset_info.depreciation,
                                                                asset_info.asset_status,
                                                                asset_info.gl_code,
                                                                asset_info.specification,
                                                                asset_info.oper_inst,
                                                                asset_info.detail_desc,
                                                                asset_info.purchase_year,
                                                                asset_info.purchase_expiry,
                                                                asset_info.purchase_warranty,
                                                                asset_info.purchase_document_no,
                                                                asset_info.purchase_price,
                                                                asset_info.purchase_type_id,
                                                                asset_info.category_id,
                                                                asset_info.funding_source_id,
                                                                asset_info.manufacturer_id,
                                                                asset_info.supplier_id,
                                                                asset_info.model,
                                                                asset_info.`status`,
                                                                warehouses.warehouse_name AS location,
                                                                `status`.`name` AS assetstatus,
                                                                purchase_type.`name` AS purchasetype,
                                                                category.`name` AS category,
                                                                funding_source.`name` AS fundingsource,
                                                                manufacturer.`name` AS manufacturer,
                                                                supplier.`name` AS supplier
                                                        FROM
                                                                asset_info
                                                        INNER JOIN warehouses ON asset_info.asset_location = warehouses.pk_id
                                                        INNER JOIN `status` ON asset_info.asset_status = `status`.id
                                                        INNER JOIN purchase_type ON asset_info.purchase_type_id = purchase_type.id
                                                        INNER JOIN category ON asset_info.category_id = category.id
                                                        INNER JOIN funding_source ON asset_info.funding_source_id = funding_source.id
                                                        INNER JOIN manufacturer ON asset_info.manufacturer_id = manufacturer.id
                                                        INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                        WHERE
                                                                asset_info.inserted_date >= '$fromdate' AND asset_info.inserted_date <='$todate 23:59:59.999'
                                                                            $manufacturerid
                                                                            $statusid
                                                                            $fundingsourceid
                                                                            $supplierid
                                                                            $categoryid
                                                                            $purchtypeid";
           }
           else{
                   $query = "SELECT
                                                                 count(asset_info.id) totalasset,
                                                                asset_info.asset_id,
                                                                asset_info.asset_name,
                                                                asset_info.serial_no,
                                                                asset_info.asset_location,
                                                                asset_info.stock_register,
                                                                asset_info.assigned_to,
                                                                asset_info.depreciation,
                                                                asset_info.asset_status,
                                                                asset_info.gl_code,
                                                                asset_info.specification,
                                                                asset_info.oper_inst,
                                                                asset_info.detail_desc,
                                                                asset_info.purchase_year,
                                                                asset_info.purchase_expiry,
                                                                asset_info.purchase_warranty,
                                                                asset_info.purchase_document_no,
                                                                asset_info.purchase_price,
                                                                asset_info.purchase_type_id,
                                                                asset_info.category_id,
                                                                asset_info.funding_source_id,
                                                                asset_info.manufacturer_id,
                                                                asset_info.supplier_id,
                                                                asset_info.model,
                                                                asset_info.`status`,
                                                                warehouses.warehouse_name AS location,
                                                                `status`.`name` AS assetstatus,
                                                                purchase_type.`name` AS purchasetype,
                                                                category.`name` AS category,
                                                                funding_source.`name` AS fundingsource,
                                                                manufacturer.`name` AS manufacturer,
                                                                supplier.`name` AS supplier
                                                        FROM
                                                                asset_info
                                                        INNER JOIN warehouses ON asset_info.asset_location = warehouses.pk_id
                                                        INNER JOIN `status` ON asset_info.asset_status = `status`.id
                                                        INNER JOIN purchase_type ON asset_info.purchase_type_id = purchase_type.id
                                                        INNER JOIN category ON asset_info.category_id = category.id
                                                        INNER JOIN funding_source ON asset_info.funding_source_id = funding_source.id
                                                        INNER JOIN manufacturer ON asset_info.manufacturer_id = manufacturer.id
                                                        INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                        WHERE
                                                                asset_info.inserted_date >= '$fromdate' AND asset_info.inserted_date <='$todate 23:59:59.999'
                                                                AND asset_info.user_id = '".$_SESSION['uid']."'
                                                                            $manufacturerid
                                                                            $statusid
                                                                            $fundingsourceid
                                                                            $supplierid
                                                                            $categoryid
                                                                            $purchtypeid";
           }
//                                                echo $query;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
           <?php if($manufacturerid != '')
           { ?>
            <td><?php echo $row['manufacturer']; ?></td>
            <td style="text-decoration: underline;"><a class="menu_links" onclick="window.open('<?php echo 'asset_detail.php?date1='.$fromdate.'&date2='.$todate.'&manufacturerid='.$row['manufacturer_id'] ?>','Asset Detail','height=500,width=700,left=10,top=10,,scrollbars=yes,menubar=no'); return false;"><?php echo $row['totalasset']; ?></a></td>
           <?php } else if($statusid != '')
           { ?>
            <td><?php echo $row['assetstatus']; ?></td>
            <td style="text-decoration: underline;"><a class="menu_links" onclick="window.open('<?php echo 'asset_detail.php?date1='.$fromdate.'&date2='.$todate.'&statusid='.$row['asset_status'] ?>','Asset Detail','height=500,width=700,left=10,top=10,,scrollbars=yes,menubar=no'); return false;"><?php echo $row['totalasset']; ?></a></td>
           <?php } else if($fundingsourceid != '')
           { ?>
            <td><?php echo $row['fundingsource']; ?></td>
            <td style="text-decoration: underline;"><a class="menu_links" onclick="window.open('<?php echo 'asset_detail.php?date1='.$fromdate.'&date2='.$todate.'&fundsorcid='.$row['funding_source_id'] ?>','Asset Detail','height=500,width=700,left=10,top=10,,scrollbars=yes,menubar=no'); return false;"><?php echo $row['totalasset']; ?></a></td>
           <?php } else if($supplierid != '')
           { ?>
            <td><?php echo $row['supplier']; ?></td>
            <td style="text-decoration: underline;"><a class="menu_links" onclick="window.open('<?php echo 'asset_detail.php?date1='.$fromdate.'&date2='.$todate.'&supplierid='.$row['supplier_id'] ?>','Asset Detail','height=500,width=700,left=10,top=10,,scrollbars=yes,menubar=no'); return false;"><?php echo $row['totalasset']; ?></a></td>
           <?php } else if($categoryid != '')
           { ?>
            <td><?php echo $row['category']; ?></td>
            <td style="text-decoration: underline;"><a class="menu_links" onclick="window.open('<?php echo 'asset_detail.php?date1='.$fromdate.'&date2='.$todate.'&categoryid='.$row['category_id'] ?>','Asset Detail','height=500,width=700,left=10,top=10,,scrollbars=yes,menubar=no'); return false;"><?php echo $row['totalasset']; ?></a></td>
           <?php } else if($purchtypeid != '')
           { ?>
            <td><?php echo $row['purchasetype']; ?></td>
            <td style="text-decoration: underline;"><a class="menu_links" onclick="window.open('<?php echo 'asset_detail.php?date1='.$fromdate.'&date2='.$todate.'&purchtypeid='.$row['purchase_type_id'] ?>','Asset Detail','height=500,width=700,left=10,top=10,,scrollbars=yes,menubar=no'); return false;"><?php echo $row['totalasset']; ?></a></td>
           <?php }
           ?>
    	</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
                
               <?php }
               ?>
            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->  
                        </div>
                        <!-- end page content-->

                    </div> <!-- container-fluid -->

                </div> <!-- content -->

                <footer class="footer">
<!--                    © 2018 Agroxa <span class="d-none d-sm-inline-block">- Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand.</span>-->
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- Parsley js -->
        <script src="../plugins/parsleyjs/parsley.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script src="js/script.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>-->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script>
            
//             $(function() {
//            <?php if ((isset($_REQUEST['manufacturer']) && !empty($_REQUEST['manufacturer'])) || (isset($_REQUEST['status']) && !empty($_REQUEST['status'])) || (isset($_REQUEST['fundsorc']) && !empty($_REQUEST['fundsorc'])) || (isset($_REQUEST['supplier']) && !empty($_REQUEST['supplier'])) || (isset($_REQUEST['category']) && !empty($_REQUEST['category'])) || (isset($_REQUEST['purchtype']) && !empty($_REQUEST['purchtype']))) { ?>
//                officeType('<?php echo $whType; ?>');
//<?php } ?>
//            
//            $('#wh_type').change(function() {
//                var whType = $(this).val();
//                officeType(whType);
//            });
//  });           
//            function officeType(whType)
//        {
//            if (whType == 1 || whType == 2)
//                {
//                    $('#manufacturer_combo').fadeOut();
//                    $('#manufacturer').val('');
//                    $('#status_combo').fadeOut();
//                    $('#status').val('');
//                    $('#fundsorc_combo').fadeOut();
//                    $('#fundsorc').val('');
//                    $('#supplier_combo').fadeOut();
//                    $('#supplier').val('');
//                    $('#category_combo').fadeOut();
//                    $('#category').val('');
//                    $('#purchtype_combo').fadeOut();
//                    $('#purchtype').val('');
//                }
//                if (whType == 3)
//                {
//                    $('#fundsorc_combo').fadeOut();
//                    $('#fundsorc').val('');
//                    $('#status_combo').fadeOut();
//                    $('#status').val('');
//                    $('#supplier_combo').fadeOut();
//                    $('#supplier').val('');
//                    $('#category_combo').fadeOut();
//                    $('#category').val('');
//                    $('#purchtype_combo').fadeOut();
//                    $('#purchtype').val('');
//                    showManufacturer(whType);
//                }
////                alert($("#whid").val());
//                if (whType == 4)
//                {
//                    $('#manufacturer_combo').fadeOut();
//                    $('#manufacturer').val('');
//                    $('#fundsorc_combo').fadeOut();
//                    $('#fundsorc').val('');
//                    $('#supplier_combo').fadeOut();
//                    $('#supplier').val('');
//                    $('#category_combo').fadeOut();
//                    $('#category').val('');
//                    $('#purchtype_combo').fadeOut();
//                    $('#purchtype').val('');
//                    showStatus(whType);
//                }
//                else if (whType == 5)
//                {
//                    $('#manufacturer_combo').fadeOut();
//                    $('#manufacturer').val('');
//                    $('#status_combo').fadeOut();
//                    $('#status').val('');
//                    $('#supplier_combo').fadeOut();
//                    $('#supplier').val('');
//                    $('#category_combo').fadeOut();
//                    $('#category').val('');
//                    $('#purchtype_combo').fadeOut();
//                    $('#purchtype').val('');
//                    showFundsorc(whType);
//                }
//                else if (whType == 6)
//                {
//                    $('#manufacturer_combo').fadeOut();
//                    $('#manufacturer').val('');
//                    $('#status_combo').fadeOut();
//                    $('#status').val('');
//                    $('#fundsorc_combo').fadeOut();
//                    $('#fundsorc').val('');
//                    $('#category_combo').fadeOut();
//                    $('#category').val('');
//                    $('#purchtype_combo').fadeOut();
//                    $('#purchtype').val('');
//                    showSupplier(whType);
//                }
//                else if (whType == 7)
//                {
//                    $('#manufacturer_combo').fadeOut();
//                    $('#manufacturer').val('');
//                    $('#status_combo').fadeOut();
//                    $('#status').val('');
//                    $('#supplier_combo').fadeOut();
//                    $('#supplier').val('');
//                    $('#fundsorc_combo').fadeOut();
//                    $('#fundsorc').val('');
//                    $('#purchtype_combo').fadeOut();
//                    $('#purchtype').val('');
//                    showCategory(whType);
//                }
//                else if (whType == 8)
//                {
//                    $('#manufacturer_combo').fadeOut();
//                    $('#manufacturer').val('');
//                    $('#status_combo').fadeOut();
//                    $('#status').val('');
//                    $('#supplier_combo').fadeOut();
//                    $('#supplier').val('');
//                    $('#category_combo').fadeOut();
//                    $('#category').val('');
//                    $('#fundsorc_combo').fadeOut();
//                    $('#fundsorc').val('');
//                    showPurchtype(whType);
//                }
//        }
//       
//       
//       function showManufacturer(whType)
//        {
//            var whType = $('#wh_type').val();
////            alert($("#whid").val());
//            if (whType == 3)
//            {
//                $('#manufacturer_combo').fadeIn();
//            }
//        }
//        
//        function showStatus(whType)
//        {
//            var whType = $('#wh_type').val();
////            alert($("#whid").val());
//            if (whType == 4)
//            {
//                $('#status_combo').fadeIn();
//            }
//        }
//        
//        function showFundsorc(whType)
//        {
//            var whType = $('#wh_type').val();
////            alert($("#whid").val());
//            if (whType == 5)
//            {
//                $('#fundsorc_combo').fadeIn();
//            }
//        }
//        function showSupplier(whType)
//        {
//            var whType = $('#wh_type').val();
////            alert($("#whid").val());
//            if (whType == 6)
//            {
//                $('#supplier_combo').fadeIn();
//            }
//        }
//        function showCategory(whType)
//        {
//            var whType = $('#wh_type').val();
////            alert($("#whid").val());
//            if (whType == 7)
//            {
//                $('#category_combo').fadeIn();
//            }
//        }
//        function showPurchtype(whType)
//        {
//            var whType = $('#wh_type').val();
////            alert($("#whid").val());
//            if (whType == 8)
//            {
//                $('#purchtype_combo').fadeIn();
//            }
//        }
            
            $(document).ready(function() {
$('.second').datepicker({
    dateFormat: "yy-mm-dd" 
});
$(".first").datepicker({
   maxDate: "0",
  dateFormat: "yy-mm-dd",
  onSelect: function(date) {
    var date1 = $('.first').datepicker('getDate');
    var date = new Date(Date.parse(date1));
    date.setDate(date.getDate() + 1);
    var newDate = date.toDateString();
    newDate = new Date(Date.parse(newDate));
    $('.second').datepicker("option", "minDate", newDate);
  }
});
    });        
             $(document).ready(function() {
    $(".preload").fadeOut(1000, function() {
        $(".content").fadeIn(500);        
    });
    });
            $(document).ready(function() {
                $('form').parsley();
            });
            
    $(document).ready(function() {
    $('#example').DataTable();
} );

    $(document).ready(function() {
    $('#example3').DataTable({
    });
} );

$(document).ready(function() {
    $('#example2').DataTable();
} );
  
function fnExcelReport()
{
    var tab_text="<table border='2px'><tr bgcolor='#33B23F'>";
    var textRange; var j=0;
    tab = document.getElementById('example'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}
            
        </script>
    
    </body>

</html>




