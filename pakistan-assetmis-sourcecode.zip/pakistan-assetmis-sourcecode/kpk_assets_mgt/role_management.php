<?php
    include 'classes/config.php';
//    $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
//                        $last_id = $row['MAX(id)'];
//                    }
    if(isset($_REQUEST['role_name'])) {

    //get the name and comment entered by user
    $name = $_REQUEST['role_name'];
//    $province = $_REQUEST['province'];
//    $district = $_REQUEST['district'];
//    $tehsil = $_REQUEST['tehsil'];
//    $uc = $_REQUEST['uc'];
//    $hf = $_REQUEST['hf'];
    $wh_type = $_REQUEST['wh_type'];
    
    
                if(empty($_REQUEST['province']) || $_REQUEST['province']=='' || !isset($_REQUEST['province'])){
                    $province='NULL';
                }
                else{
                    $province = $_REQUEST['province'];
                }
                if(empty($_REQUEST['district']) || $_REQUEST['district']=='' || !isset($_REQUEST['district'])){
                    $district='NULL';
                }
                else{
                    $district = $_REQUEST['district'];
                }
                if(empty($_REQUEST['tehsil']) || $_REQUEST['tehsil']=='' || !isset($_REQUEST['tehsil'])){
                    $tehsil='NULL';
                }
                else{
                    $tehsil = $_REQUEST['tehsil'];
                }
                if(empty($_REQUEST['uc']) || $_REQUEST['uc']=='' || !isset($_REQUEST['uc'])){
                    $uc='NULL';
                }
                else{
                    $uc = $_REQUEST['uc'];
                }
                if(empty($_REQUEST['hf']) || $_REQUEST['hf']=='' || !isset($_REQUEST['hf'])){
                    $hf='NULL';
                }
                else{
                    $hf = $_REQUEST['hf'];
                }
                
//connect to the database
//    $dbc = mysqli_connect('host', 'username', 'password', 'dbname') or die('Error connecting to MySQL server');
    $query = "select * from role where role_name='$name' && province='$province' && district='" . implode(', ', (array)$district). "' && tehsil='" . implode(', ', (array)$tehsil). "' && uc='" . implode(', ', (array)$uc). "' && role_level_id='$wh_type' && hf='" . implode(', ', (array)$hf). "'";
//    echo $query;
//    exit;
    $check=mysqli_query($conn,$query);
//    echo $check;
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
       $response   =   array("match"=>"0");
       echo json_encode($response);
   } 
   else {  
        if(!empty($_REQUEST['id']))
    {
            $rid = $_REQUEST['id'];
                $name = $_REQUEST['role_name'];
                $rlevel = $_REQUEST['wh_type'];
                $access = $_REQUEST['access'];
                
                if(empty($_REQUEST['province']) || $_REQUEST['province']=='' || !isset($_REQUEST['province'])){
                    $province='NULL';
                }
                else{
                    $province = $_REQUEST['province'];
                }
                if(empty($_REQUEST['district']) || $_REQUEST['district']=='' || !isset($_REQUEST['district'])){
                    $district='NULL';
                }
                else{
                    $district = $_REQUEST['district'];
                }
                if(empty($_REQUEST['tehsil']) || $_REQUEST['tehsil']=='' || !isset($_REQUEST['tehsil'])){
                    $tehsil='NULL';
                }
                else{
                    $tehsil = $_REQUEST['tehsil'];
                }
                if(empty($_REQUEST['uc']) || $_REQUEST['uc']=='' || !isset($_REQUEST['uc'])){
                    $uc='NULL';
                }
                else{
                    $uc = $_REQUEST['uc'];
                }
                if(empty($_REQUEST['hf']) || $_REQUEST['hf']=='' || !isset($_REQUEST['hf'])){
                    $hf='NULL';
                }
                else{
                    $hf = $_REQUEST['hf'];
                }
                if(empty($_REQUEST['dhq']) || $_REQUEST['dhq']=='' || !isset($_REQUEST['dhq'])){
                    $dhq='NULL';
                }
                else{
                    $dhq = $_REQUEST['dhq'];
                }
                
                $query = "UPDATE role SET role_name='$name',role_level_id='$rlevel',province='$province',district='" . implode(', ', (array)$district). "',tehsil='" . implode(', ', (array)$tehsil). "',uc='" . implode(', ', (array)$uc). "',hf='" . implode(', ', (array)$hf). "',access_id='$access',dhq='" . implode(', ', (array)$dhq). "' WHERE id='$rid'";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
         $response   =   array("chkid"=>"1");
       echo json_encode($response);
    }   
    else{
    $rid =  mt_rand(10000000, 99999999);
//		$rid = $_REQUEST['role_id'];
                $rname = $_REQUEST['role_name'];
                $wh_type = $_REQUEST['wh_type'];
                $access = $_REQUEST['access'];
                
                if(empty($_REQUEST['province']) || $_REQUEST['province']=='' || !isset($_REQUEST['province'])){
                    $province='NULL';
                }
                else{
                    $province = $_REQUEST['province'];
                }
                if(empty($_REQUEST['district']) || $_REQUEST['district']=='' || !isset($_REQUEST['district'])){
                    $district='NULL';
                }
                else{
                    $district = $_REQUEST['district'];
                }
                if(empty($_REQUEST['tehsil']) || $_REQUEST['tehsil']=='' || !isset($_REQUEST['tehsil'])){
                    $tehsil='NULL';
                }
                else{
                    $tehsil = $_REQUEST['tehsil'];
                }
                if(empty($_REQUEST['uc']) || $_REQUEST['uc']=='' || !isset($_REQUEST['uc'])){
                    $uc='NULL';
                }
                else{
                    $uc = $_REQUEST['uc'];
                }
                if(empty($_REQUEST['hf']) || $_REQUEST['hf']=='' || !isset($_REQUEST['hf'])){
                    $hf='NULL';
                }
                else{
                    $hf = $_REQUEST['hf'];
                }
                if(empty($_REQUEST['dhq']) || $_REQUEST['dhq']=='' || !isset($_REQUEST['dhq'])){
                    $dhq='NULL';
                }
                else{
                    $dhq = $_REQUEST['dhq'];
                }
                
                
                $query = "INSERT INTO role (role_id,role_name, province,district,tehsil,uc,hf,role_level_id,access_id,dhq)
                VALUES ('$rid','$rname','$province','" . implode(', ', (array)$district). "','" . implode(', ', (array)$tehsil). "','" . implode(', ', (array)$uc). "','" . implode(', ', (array)$hf). "','$wh_type','$access','" . implode(', ', (array)$dhq). "')";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
        $response   =   array("chkid"=>"0");
       echo json_encode($response);
    }
    
    }
}

if(isset($_POST['operation']))
{ ?>
    <table id="example" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Name</th>
                                                        <th>Level</th>
                                                        <th>Action</th>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                role.id,
                                                                role.role_id,
                                                                role.role_name,
                                                                role.role_level_id,
                                                                role_level.role_level
                                                        FROM
                                                                role
                                                        INNER JOIN role_level ON role.role_level_id = role_level.id
                                                        Order by role.id";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo $row['role_name']; ?></td>
            <td><?php echo $row['role_level']; ?></td>
            <td>
                <button id="<?php echo $row["id"]; ?>" onclick="UpdateRole(this.id)" class="btn btn-success updatebtn">Update</button>
            </td>
    	</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
    </script>
<?php
}    
?>