<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php include 'classes/config.php'; 
$id = '';
$aid = '';
$rid = '';
if(isset($_REQUEST['id']) && $_REQUEST['id'] != '')
    {
        $id = $_REQUEST['id'];
    }
    if(isset($_REQUEST['aid']) && $_REQUEST['aid'] != '')
    {
        $aid = $_REQUEST['aid'];
    }
//    if(isset($_REQUEST['id']) && $_REQUEST['id'] != '')
//    {
//        $id = $_REQUEST['id'];
//    }
    
     $currently_selected = date('Y'); 
  // Year to start available options at
  $earliest_year = 1990; 
  // Set your latest year you want in the range, in this case we use PHP to just set it to the current year.
  $latest_year = date('Y'); 
  
$districid='';
if (isset($_SESSION['did']) && $_SESSION['did'] != '' && $_SESSION['did'] != 'NULL'){
    $districid=" AND warehouses.district_id IN (". implode(', ',(array)$_SESSION['did']).")";
}
$thid='';
if ($_SESSION['tid'] != ''  && $_SESSION['tid'] != 'NULL'){
    $thid =" AND warehouses.location_id IN (". implode(', ',(array)$_SESSION['tid']).")";
}
$ucid='';
if (isset($_SESSION['ucid']) && $_SESSION['ucid'] != ''  && $_SESSION['ucid'] != 'NULL'){
    $ucid =" AND warehouses.location_id IN (". implode(', ',(array)$_SESSION['ucid']) .")";
}
$hfid='';
if (isset($_SESSION['hfid']) && $_SESSION['hfid'] != ''  && $_SESSION['hfid'] != 'NULL'){
    $hfid =" AND warehouses.pk_id IN (". implode(', ',(array)$_SESSION['hfid']).")";
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">
        
        <link href="../plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">

        <link href="../plugins/bootstrap-md-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">

        <link href="../plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" >
        <link href="../plugins/bootstrap-touchspin/css/jquery.bootstrap-touchspin.min.css" rel="stylesheet" >
        
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
<!--        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  -->
        
        
<!--        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
     Bootstrap CSS File  
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        
        <script src="https://cdn.datatables.net/fixedcolumns/3.3.2/js/dataTables.fixedColumns.min.js"></script>-->
<!--<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/fixedcolumns/3.3.2/css/fixedColumns.dataTables.min.css">-->
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->

<!--<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.dataTables.min.css">
     Bootstrap CSS File  
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>-->


    

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-html5-1.6.1/b-print-1.6.1/fh-3.1.6/datatables.min.css"/>

<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>-->
<!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>-->
<!--<script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-html5-1.6.1/b-print-1.6.1/fh-3.1.6/datatables.min.js"></script>-->

        <style>
/*            .c8tableBody  {
    width:100%;
    overflow-x:scroll;
}*/
div#load_screen{
	background: white;
	opacity: 1;
	position: fixed;
    z-index:10;
	top: 0px;
	width: 100%;
	height: 1600px;
}
div#load_screen > div#loading{
	color:black;
	width:120px;
	height:24px;
	margin: 300px auto;
}
.navbar{
               background:  #6BA2D2;
               color: white;
            }
th, td { white-space: nowrap; }
/*.content {display:none;}
.preload { width:100px;
    height: 100px;
    position: fixed;
    top: 50%;
    left: 50%;}*/
            </style>
        <script>
window.addEventListener("load", function(){
	var load_screen = document.getElementById("load_screen");
	document.body.removeChild(load_screen);
});
</script>
    </head>

    <body>
        <div id="load_screen"><div id="loading"><img src="assets/images/scroll.gif" /></div></div>
        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
             <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.php" class="logo">
                        <span>
                            <img src="assets/images/logo.png" alt="" >
                        </span>
                        <i>
                            <img src="assets/images/logo-sm.png" alt="" height="22">
                        </i>
                    </a>
                </div>

                <nav class="navbar-custom">
                    <ul class="navbar-right d-flex list-inline float-right mb-0">

                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="index.php" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="noti-icon"> <?php echo $_SESSION['username']; ?></i>
                                <!--<span class="badge badge-pill badge-info noti-icon-badge">3</span>-->
                            </a>
                        </li>
                        <li class="dropdown notification-list">
                            <div class="dropdown notification-list nav-pro-img">
                                <a class="dropdown-toggle nav-link arrow-none waves-effect nav-user waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                    <a class="dropdown-item" href="changepassword.php"><i style="font-size: 15px;" class="mdi mdi-account-circle m-r-5">Change Password</i> <?php // echo $_SESSION['username']; ?></a>
<!--                                    <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5"></i> My Wallet</a>
                                    <a class="dropdown-item d-block" href="#"><span class="badge badge-success float-right">11</span><i class="mdi mdi-settings m-r-5"></i> Settings</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-lock-open-outline m-r-5"></i> Lock screen</a>-->
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php"><i class="mdi mdi-power text-danger"></i> Logout</a>
                                </div>                                                                    
                            </div>
                        </li>

                    </ul>
                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>                        
                        <li class="d-none d-sm-block">
                            <div class="dropdown pt-3 d-inline-block">
                                <a class="waves-effect waves-light" href="#"  aria-haspopup="true" aria-expanded="false">
                                    <h4 style="color: white;">Assets Data Management</h4>
                                </a>
                                
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </li>
                    </ul>

                </nav>

            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'left_menu.php';?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Update Asset</h4>
                                </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
<!--<div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
</div>-->
<!--<div class="content">-->
                        <div class="page-content-wrapper">
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
    <h3>Records:</h3>
    <i id="btnExport" onclick="fnExcelReport();" class="fa fa-file-excel-o" style="font-size:32px;color:#33B23F;float: right;"></i>
    <br>
    <div class="check">
<!--                <div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
</div>-->
<div class="content">
                <!--<div style="overflow-x:auto;">-->
             <table id="example" class="display nowrap" width="100%">
        <thead style="color: white;background: #33B23F;">
<!--                                                <tr>
							<th></th>
                                                        <th>Asset Name</th>
                                                        <th>Serial no</th>
                                                        <th>Asset Location</th>
							<th>Stock Register</th>
                                                        <th>Assigned To</th>
                                                        <th>Depreciation</th>
                                                        <th>Asset Status</th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>
                                                        <th></th>-->
						<?php // if($_SESSION["userid"] != '2' && $_SESSION["userid"] != '5')
//                                                    {
                                                ?>
                                                        <!--<th></th>-->
                                                <?php 
//                                                        }
                                                ?>
						<!--</tr>-->
                                                <tr>
							<!--<th>No.</th>-->
                                                        <th>System ID (Auto)</th>
                                                        <th>Asset Name</th>
                                                        <th>Serial no</th>
                                                        <th>Asset Location</th>
							<th>Stock Register</th>
                                                        <th>Assigned To</th>
                                                        <th>Depreciation</th>
                                                        <th>Asset Status</th>
                                                        <th>GI Code</th>
                                                        <th>Specification</th>
                                                        <th>Operational Instructions</th>
                                                        <th>Detail Description</th>
                                                        <th>More Info</th>
                                                        <th>Download</th>
                                                        <th>Purchase Year</th>
                                                        <th>Purchase Expiry</th>
                                                        <th>Purchase Warranty</th>
                                                        <th>Purchase Document No</th>
                                                        <th>Purchase Price</th>
                                                        <th>Purchase Type</th>
                                                        <th>Category</th>
                                                        <th>Funding Source</th>
                                                        <th>Manufacturer</th>
                                                        <th>Supplier</th>
                                                        <th>Model</th>
                                                        <th>Created By</th>
                                                        <th>Created Date</th>
                                                        <th>Modified By</th>
                                                        <th>Modified Date</th>
            <?php if($_SESSION["userid"] != '2' && $_SESSION["userid"] != '5')
                {
            ?>
                                                        <th class="text-center">Action</th>
            <?php 
                    }
            ?>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                  if($_SESSION["rid"] == '25')
                {
                                                $query = "SELECT
                                                            asset_info.id,
                                                            asset_info.asset_id,
                                                            asset_info.asset_name AS assetid,
                                                            asset_info.serial_no,
                                                            asset_info.asset_location,
                                                            asset_info.stock_register,
                                                            asset_info.assigned_to,
                                                            asset_info.depreciation,
                                                            asset_info.asset_status,
                                                            asset_info.gl_code,
                                                            asset_info.specification,
                                                            asset_info.oper_inst,
                                                            asset_info.detail_desc,
                                                            asset_info.purchase_year,
                                                            asset_info.expire_years,
                                                            asset_info.purchase_warranty,
                                                            asset_info.purchase_document_no,
                                                            asset_info.purchase_price,
                                                            asset_info.purchase_type_id,
                                                            asset_info.category_id,
                                                            asset_info.funding_source_id,
                                                            asset_info.manufacturer_id,
                                                            asset_info.supplier_id,
                                                            asset_info.model,
                                                            asset_info.`status`,
                                                            asset_info.`file`,
                                                            warehouses.warehouse_name AS location,
                                                            `status`.`name` AS assetstatus,
                                                            purchase_type.`name` AS purchasetype,
                                                            category.`name` AS category,
                                                            funding_source.`name` AS fundingsource,
                                                            manufacturer.`name` AS manufacturer,
                                                            supplier.`name` AS supplier,
                                                            asset_info.inserted_by,
                                                            asset_info.updated_by,
                                                            asset_info.inserted_date,
                                                            asset_info.updated_date,
                                                            asset_and_specs.`name` AS asset_name
                                                    FROM
                                                            asset_info
                                                    LEFT JOIN warehouses ON asset_info.asset_location = warehouses.pk_id
                                                    LEFT JOIN asset_and_specs ON asset_info.asset_name = asset_and_specs.id
                                                    LEFT JOIN `status` ON asset_info.asset_status = `status`.id
                                                    LEFT JOIN purchase_type ON asset_info.purchase_type_id = purchase_type.id
                                                    LEFT JOIN category ON asset_info.category_id = category.id
                                                    LEFT JOIN funding_source ON asset_info.funding_source_id = funding_source.id
                                                    LEFT JOIN manufacturer ON asset_info.manufacturer_id = manufacturer.id
                                                    LEFT JOIN supplier ON asset_info.supplier_id = supplier.id
                                                    ";
                } else{
                    $query = "SELECT
                                                            asset_info.id,
                                                            asset_info.asset_id,
                                                            asset_info.asset_name AS assetid,
                                                            asset_info.serial_no,
                                                            asset_info.asset_location,
                                                            asset_info.stock_register,
                                                            asset_info.assigned_to,
                                                            asset_info.depreciation,
                                                            asset_info.asset_status,
                                                            asset_info.gl_code,
                                                            asset_info.specification,
                                                            asset_info.oper_inst,
                                                            asset_info.detail_desc,
                                                            asset_info.purchase_year,
                                                            asset_info.expire_years,
                                                            asset_info.purchase_warranty,
                                                            asset_info.purchase_document_no,
                                                            asset_info.purchase_price,
                                                            asset_info.purchase_type_id,
                                                            asset_info.category_id,
                                                            asset_info.funding_source_id,
                                                            asset_info.manufacturer_id,
                                                            asset_info.supplier_id,
                                                            asset_info.model,
                                                            asset_info.`status`,
                                                            asset_info.`file`,
                                                            warehouses.warehouse_name AS location,
                                                            `status`.`name` AS assetstatus,
                                                            purchase_type.`name` AS purchasetype,
                                                            category.`name` AS category,
                                                            funding_source.`name` AS fundingsource,
                                                            manufacturer.`name` AS manufacturer,
                                                            supplier.`name` AS supplier,
                                                            asset_info.inserted_by,
                                                            asset_info.updated_by,
                                                            asset_info.inserted_date,
                                                            asset_info.updated_date,
                                                            asset_and_specs.`name` AS asset_name
                                                    FROM
                                                            asset_info
                                                    LEFT JOIN warehouses ON asset_info.asset_location = warehouses.pk_id
                                                    LEFT JOIN asset_and_specs ON asset_info.asset_name = asset_and_specs.id
                                                    LEFT JOIN `status` ON asset_info.asset_status = `status`.id
                                                    LEFT JOIN purchase_type ON asset_info.purchase_type_id = purchase_type.id
                                                    LEFT JOIN category ON asset_info.category_id = category.id
                                                    LEFT JOIN funding_source ON asset_info.funding_source_id = funding_source.id
                                                    LEFT JOIN manufacturer ON asset_info.manufacturer_id = manufacturer.id
                                                    LEFT JOIN supplier ON asset_info.supplier_id = supplier.id
                                                    WHERE
                                                            asset_info.user_id = '".$_SESSION['uid']."'";
                }

//                                                echo $query;
//                                                exit;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <!--<td><?php echo $number; ?></td>-->
            <td><?php echo $row['asset_id']; ?></td>
            <td><?php echo $row['asset_name']; ?></td>
            <td><?php echo $row['serial_no']; ?></td>
            <td><?php echo $row['location']; ?></td>
            <td><?php echo $row['stock_register']; ?></td>
            <td><?php echo $row['assigned_to']; ?></td>
            <td><?php echo $row['depreciation']; ?></td>
            <td><?php echo $row['assetstatus']; ?></td>
            <td><?php echo $row['gl_code']; ?></td>
            <td><?php echo $row['specification']; ?></td>
            <td><?php echo $row['oper_inst']; ?></td>
            <td><?php echo $row['detail_desc']; ?></td>
            <td style="text-decoration: underline;"><a href="./uploads/<?php echo $row['file']; ?>" target="_blank">View</a></td>
            <td style="text-decoration: underline;"><a href="./uploads/<?php echo $row['file']; ?>" download>Download</a></td>
            <td><?php echo $row['purchase_year']; ?></td>
            <td><?php echo $row['expire_years']; ?></td>
            <td><?php echo $row['purchase_warranty']; ?></td>
            <td><?php echo $row['purchase_document_no']; ?></td>
            <td><?php echo $row['purchase_price']; ?></td>
            <td><?php echo $row['purchasetype']; ?></td>
            <td><?php echo $row['category']; ?></td>
            <td><?php echo $row['fundingsource']; ?></td>
            <td><?php echo $row['manufacturer']; ?></td>
            <td><?php echo $row['supplier']; ?></td>
            <td><?php echo $row['model']; ?></td>
            <td><?php echo $row['inserted_by']; ?></td>
            <td><?php echo $row['inserted_date']; ?></td>
            <td><?php echo $row['updated_by']; ?></td>
            <td><?php echo $row['updated_date']; ?></td>
            <?php if($_SESSION["userid"] != '2' && $_SESSION["userid"] != '5')
                {
            ?>
            <td>
                    <button class="btn waves-effect waves-light" style="background: #33B23F; color: white;" data-toggle="modal" data-target=".bs-example-modal-lg"  onclick="GetAssetDetails(<?php echo $row['id']; ?>)">Update</button>
                    <button class="btn waves-effect waves-light" style="background: #33B23F; color: white;" data-toggle="modal" data-target="#myModal" onclick="GetAssetDetailsN(<?php echo $row['asset_id']; ?>)" >Repair</button>
                    <button class="btn waves-effect waves-light" style="background: #33B23F; color: white;" data-toggle="modal" data-target="#myModal1" onclick="GetAssetDetailsNA(<?php echo $row['asset_id']; ?>)" >Accessories</button>
            </td>
            <?php 
                    }
            ?>
<!--            <td>
                <?php if($row['status'] == 1)
               {?>
                <button onclick="active(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>-->
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
<!--</div>-->
                </div>
            
                                        <!--</div>-->
            
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->  
                        </div>
</div>
 <div id="catchme">                       <!-- end page content-->
     
     <a name="timeline" />
 <?php if(isset($aid) && $aid != '' )
{    
?>                            
                            <!--Accordion wrapper-->
<div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">

  <!-- Accordion card -->
  <div class="card">

    <!-- Card header -->
    <div class="card-header" role="tab" id="headingOne1" style="background: #6BA2D2">
      <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne1" aria-expanded="true"
        aria-controls="collapseOne1">
          <img src="assets/images/Accessories  Parts.png" width="35" height="35" class="pull-left mr-2" alt="">
        <h5 class="mb-0 text-white" >
          Accessories / Parts Management <i class="fas fa-angle-down rotate-icon "></i>
        </h5>
      </a>
    </div>

    <!-- Card body -->
    <div id="collapseOne1" class="collapse show" role="tabpanel" aria-labelledby="headingOne1"
      data-parent="#accordionEx">
      <div class="card-body">

                            
                            
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
                                            
                                            
                                            
                                            
<form method="POST" action="asset_accessories_mang_info.php" id="form_id_acc" autocomplete="off">
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Letter#/Ref# <span style="color:red;">*</span></label>
      <input type="text" name="acc_ref_id" placeholder="" class="form-control" id="acc_ref_id" required>
    </div>
     <div class="col-md-2 mb-3">
      <label for="validationDefault03">Date <span style="color:red;">*</span></label>
      <input type="date" name="acc_date" min='2020-01-01' value ="<?php echo date('Y-m-d') ?>" class="form-control" id="acc_date" required>
    </div>
  </div>
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Name / Description <span style="color:red;">*</span></label>
    <textarea class="form-control" name="acc_description" id="acc_description" rows="2" required></textarea>
  </div>
        <br>
        <div class="form-row">             
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Supplied By <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="acc_sup_by" id="acc_sup_by" required>
<!--        <option value='Local' selected='selected'>Local</option>
        <option value='Supplier/Vendor' selected='selected'>Supplier/Vendor</option>-->
          <?php
   $sel_query1 = "Select * FROM supplier WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
        <div class="col-md-2 mb-3">
      <label for="validationDefault03" class="required">Price <span style="color:red;">*</span></label>
      <input type="text" name="acc_price" class="form-control" id="acc_price" required>
    </div>
            <div class="col-md-2 mb-3">
      <label for="validationDefault03" class="required">Quantity <span style="color:red;">*</span></label>
      <input type="text" name="acc_quantity" class="form-control" id="acc_quantity" required>
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Status <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="acc_status" id="acc_status" required>
        <!--<option value='Spare' selected='selected'>Spare</option>-->
          <?php
   $sel_query1 = "Select * FROM status WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
  </div>
        <input type="hidden" id="asset_id1" name="asset_id1" value="<?php echo $aid; ?>">
        
   <div class="form-row">
    <label for="exampleFormControlTextarea1">Detail Description / Comments</label>
    <textarea class="form-control" name="acc_detail" id="acc_detail" rows="3"></textarea>
    <span style="color:red;">Note: You can enter maximum 300 character's.</span>
  </div>
        <br>
            <!--<input type="hidden" id="id" name="id" value="3487">-->
          <div class="modal-footer">
            <button type="submit" href="#lab_history" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Save</button>
            <a href="update_asset.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
        
                                            <h3>Records:</h3>
            <div class="check">
             <table id="example2" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<!--<th>No.</th>-->
                                                        <th>System ID (Auto)</th>
                                                        <th>Letter#/ Ref#</th>
                                                        <th>Description</th>
                                                        <th>Date</th>
							<th>Supplied By</th>
                                                        <th>Qty</th>
                                                        <th>Comments</th>
                                                        <th>Created By</th>
                                                        <th>Created Date</th>
                                                        <th>Modified By</th>
                                                        <th>Modified Date</th>
<!--                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>-->
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                asset_accessorie_mang_info.id,
                                                                asset_accessorie_mang_info.ref_no,
                                                                asset_accessorie_mang_info.date,
                                                                asset_accessorie_mang_info.description,
                                                                asset_accessorie_mang_info.supplied_by,
                                                                asset_accessorie_mang_info.price,
                                                                asset_accessorie_mang_info.quantity,
                                                                asset_accessorie_mang_info.`status`,
                                                                asset_accessorie_mang_info.`comment`,
                                                                supplier.`name`,
                                                                asset_accessorie_mang_info.inserted_by,
                                                                asset_accessorie_mang_info.updated_by,
                                                                asset_accessorie_mang_info.inserted_date,
                                                                asset_accessorie_mang_info.updated_date
                                                        FROM
                                                                asset_accessorie_mang_info
                                                        INNER JOIN supplier ON asset_accessorie_mang_info.supplied_by = supplier.id
                                                        WHERE
                                                                asset_accessorie_mang_info.asset_no =  $aid";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <!--<td><?php echo $number; ?></td>-->
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['ref_no']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td><?php echo $row['comment']; ?></td>
            <td><?php echo $row['inserted_by']; ?></td>
            <td><?php echo $row['inserted_date']; ?></td>
            <td><?php echo $row['updated_by']; ?></td>
            <td><?php echo $row['updated_date']; ?></td>
<!--            <td>
                    <button onclick="GetUserDetails(<?php echo $row['id']; ?>)" class="btn btn-warning">Update</button>
            </td>
            <td>
                    <button onclick="DeleteUser(<?php echo $row['id']; ?>)" class="btn btn-danger">Delete</button>
               <?php if($row['ref_no'] == 1)
               {?>
                <button onclick="active(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>-->
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
            <!--</div>-->
        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                                
</div>
                                
                                
 <?php
    } else if(isset($id) && $id != '' )
    {    
?>                             
                                
<div class="accordion md-accordion" id="accordionEx1" role="tablist" aria-multiselectable="true">

  <!-- Accordion card -->
  <div class="card">

    <!-- Card header -->
    <div class="card-header" role="tab" id="headingOne1" style="background: #6BA2D2">
      <a data-toggle="collapse" data-parent="#accordionEx1" href="#collapseOne2" aria-expanded="true"
        aria-controls="collapseOne2">
          <img src="assets/images/Repair  Maintenance.png" width="30" height="30" class="pull-left mr-2" alt="">
        <h5 class="mb-0 text-white" >
          Repair Management <i class="fas fa-angle-down rotate-icon "></i>
        </h5>
      </a>
    </div>

    <!-- Card body -->
    <div id="collapseOne2" class="collapse show" role="tabpanel" aria-labelledby="headingOne1"
      data-parent="#accordionEx1">
      <div class="card-body">

                            
                            
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
                                            
                                            
                                            
                                            
<form method="POST" action="asset_repair_info.php" id="form_id_rep" autocomplete="off">
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">PO#/Letter#/Ref# <span style="color:red;">*</span></label>
      <input type="text" name="repair_ref_no" placeholder="" class="form-control" id="repair_ref_no" required>
    </div>
     <div class="col-md-4 mb-3">
      <label for="validationDefault03">Date <span style="color:red;">*</span></label>
      <input type="date" name="date" min='2020-01-01' value ="<?php echo date('Y-m-d') ?>" class="form-control" id="date" required>
    </div>
      <div class="col-md-4 mb-3">
      <label for="validationDefault01">Status <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="rstatus" id="rstatus" required>
       <?php
   $sel_query1 = "Select * FROM status WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
  </div>
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Description / Details <span style="color:red;">*</span></label>
    <textarea class="form-control" name="repair_detail" id="repair_detail" rows="2" required></textarea>
  </div>
        <br>
        <div class="form-row"> 
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Repaired by <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="repair_by" id="repair_by" required>
<!--        <option value='Local' selected='selected'>Local</option>
        <option value='Supplier/Vendor' selected='selected'>Supplier/Vendor</option>-->
          <?php
   $sel_query1 = "Select * FROM supplier WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationDefault03">Repair Warranty <span style="color:red;">*</span></label>
      <div class="input-group mb-3">
          <input type="text" name="repair_warranty"  minlength = "0" maxlength = "2" class="form-control" id="repair_warranty" value="12" required>
        <div class="input-group-append">
            <span class="input-group-text" style="background: #60A8F2;color: white;" id="basic-addon2">Months</span>
        </div> 
    </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Repair Amount <span style="color:red;">*</span></label>
      <input type="text" name="repair_amount" placeholder="" class="form-control" id="repair_amount" required>
    </div>
            
  </div>
        <input type="hidden" id="asset_idr" name="asset_idr" value="<?php echo $id ?>">
         <input type="hidden" id="id" name="id" value="">
         <div class="form-row">
             <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Quantity <span style="color:red;">*</span></label>
      <input type="text" name="rquantity" placeholder="" class="form-control" id="rquantity" required>
    </div>
   <div class="col-md-8 mb-3">
    <label for="exampleFormControlTextarea1">Comments / Remarks</label>
    <textarea class="form-control" name="r_comment" id="r_comment" rows="3"></textarea>
    </div>
         </div>
            <!--<input type="hidden" id="id" name="id" value="3487">-->
          <div class="modal-footer">
            <button type="submit" href="#lab_history" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Save</button>
            <a href="update_asset.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
            <!--<div id="catchme">-->
                                            <h3>Records:</h3>
            <div class="check">
             <table id="example1" class="display" style="width:100%;">
        <thead style="color: white;background: #33B23F;">
                                                <tr>
							<!--<th>No.</th>-->
                                                        <th>System ID (Auto)</th>
                                                        <th>PO#/ Letter#/ Ref#</th>
                                                        <th>Repair Description</th>
                                                        <th>Repair Date</th>
							<th>Repair By</th>
                                                        <th>Status</th>
                                                        <th>Quantity</th>
                                                        <th>Warranty of Repair , if any</th>
                                                        <th>Vendor / Supplier</th>
                                                        <th>Comments</th>
                                                        <th>Created By</th>
                                                        <th>Created Date</th>
                                                        <th>Modified By</th>
                                                        <th>Modified Date</th>
                                                        <th>Action</th>
<!--                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>-->
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                    A.*, B.*
                                                            FROM
                                                                    (
                                                                            SELECT
                                                                                    asset_repair_info.id,
                                                                                    supplier.`name` AS repairby
                                                                            FROM
                                                                                    asset_repair_info
                                                                            INNER JOIN supplier ON asset_repair_info.repaired_by_id = supplier.id
                                                                            WHERE
                                                                            asset_repair_info.asset_no = $id
                                                                    ) A
                                                            LEFT JOIN (
                                                                    SELECT
                                                                            asset_repair_info.id,
                                                                            asset_repair_info.repair_po_no,
                                                                            asset_repair_info.date,
                                                                            asset_repair_info.description,
                                                                            asset_repair_info.repaired_by_id,
                                                                            asset_repair_info.repair_warrenty,
                                                                            asset_repair_info.repair_amount,
                                                                            asset_repair_info.`comment`,
                                                                            `status`.`name`,
                                                                            asset_repair_info.`quantity`,
                                                                            asset_info.asset_id,
                                                                            supplier.`name` AS supliername,
                                                                            asset_repair_info.inserted_by,
                                                                            asset_repair_info.updated_by,
                                                                            asset_repair_info.inserted_date,
                                                                            asset_repair_info.updated_date
                                                                    FROM
                                                                            asset_repair_info
                                                                    INNER JOIN `status` ON asset_repair_info.`status` = `status`.id
                                                                    INNER JOIN asset_info ON asset_repair_info.asset_no = asset_info.asset_id
                                                                    INNER JOIN supplier ON asset_info.supplier_id = supplier.id
                                                                    WHERE
                                                                            asset_repair_info.asset_no = $id
                                                            ) B ON A.id = B.id";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <!--<td><?php echo $number; ?></td>-->
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['repair_po_no']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['repairby']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td><?php echo $row['repair_warrenty']; ?></td>
            <td><?php echo $row['supliername']; ?></td>
            <td><?php echo $row['comment']; ?></td>
            <td><?php echo $row['inserted_by']; ?></td>
            <td><?php echo $row['inserted_date']; ?></td>
            <td><?php echo $row['updated_by']; ?></td>
            <td><?php echo $row['updated_date']; ?></td>
            <td>
                    <button class="btn waves-effect waves-light" style="background: #33B23F; color: white;"  onclick="update_repairs(<?php echo $row['id']; ?>)">Update</button>
            </td>
<!--            <td>
                    <button onclick="GetUserDetails(<?php echo $row['id']; ?>)" class="btn btn-warning">Update</button>
            </td>
            <td>
                    <button onclick="DeleteUser(<?php echo $row['id']; ?>)" class="btn btn-danger">Delete</button>
               <?php if($row['ref_no'] == 1)
               {?>
                <button onclick="active(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>-->
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
            <!--</div>-->
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
</div>
                                
<?php }
?>                       
 </div>               
                        
                        
                        
<div class="col-sm-6 col-md-3 m-t-30">
            
            
                                                    <!--  Modal content for the above example -->
                                                    <div class="modal fade bs-example-modal-lg" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title mt-0" id="myLargeModalLabel">Update Asset</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                </div>
                        <form method="POST" id="form_id" autocomplete="off">
                        <div class="modal-body">
       <nav class="navbar navbar-expand-sm navbar-dark text-white">
        <!--<a class="navbar-brand" href="#">-->
            <img src="assets/images/Basic Information.png" width="30" height="30" class="d-inline-block align-top" alt="">
            &nbsp;&nbsp;<h5>Asset Basic Information</h5>
        <!--</a>-->

      </nav>
                            <br>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault01">Sys Asset#</label>
      <!--<input type="number" step="0.01" name="live_birth_perc" min="0" placeholder="Patient Id" class="form-control" id="validationDefault01" placeholder="" required>-->
      <input type="text" class="form-control" placeholder="Auto GID" name="asset_id" id="asset_id" value="" readonly>
    </div>
      <div class="col-md-4 mb-3">
      <label for="validationDefault01">Category <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" onchange="info_using_category()" name="category" id="category" required>
        <!--<option value='Equipment' selected='selected'>Equipment</option>-->
          <?php
   $sel_query1 = "Select * FROM category WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Asset Name <span style="color:red;">*</span></label>
      <select class="form-control mr-2" onclick="info_using_assetname()" name="asset_name" id="asset_name" required>
          <!--<option value="">Select</option>-->
          <?php
//   $sel_query1 = "Select * FROM asset_and_specs WHERE status='1' AND user_id = '".$_SESSION['uid']."' GROUP BY asset_and_specs.category_id ";
//                    $result2 = mysqli_query($conn, $sel_query1);
//                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php //    echo '<option  value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
//                    }
      ?>
      </select>
      <span class="error"><p id="asset_name_error"></p></span>
    </div>
  </div>
    <div class="form-row"> 
           <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Specifications</label>
      <!--<div class="input-group mb-3">-->
      <input type="text" name="specification"  class="form-control" id="specification" readonly>
      <!--<div class="input-group-append">-->
        <!--<span class="input-group-addon" style="background: #60A8F2;color: white;" id="basic-addon2">Meter</span>-->
        <!--</div>-->
    <!--</div>-->
       </div>
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Specs Year</label>
      <input type="text" name="specs_year"  class="form-control" id="specs_year" readonly>
      <!--<span class="error"><p id="model_error"></p></span>-->
    </div>
        <div class="col-md-4 mb-3">
      <label for="validationDefault01">Asset Status </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="asset_status" id="asset_status">
        <!--<option value='Functional' selected='selected'>Functional</option>-->
          <?php
   $sel_query1 = "Select * FROM status WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
    </div>
       <div class="form-row"> 
           <div class="col-md-4 mb-3">
      <label for="validationDefault01">Make / Manufacturer </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="manufacturer" id="manufacturer" >
        <!--<option value='Male' selected='selected'>Siemens</option>-->
          <?php
   $sel_query1 = "Select * FROM manufacturer WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
           <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Model</label>
      <input type="text" name="model"  class="form-control" id="model" maxlength="25">
      <!--<span class="error"><p id="model_error"></p></span>-->
    </div>
          <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Serial Number / IMEI / Batch# </label>
      <input type="text" name="serial_no"  class="form-control" id="serial_no" maxlength="30">
      <!--<span class="error"><p id="serial_no_error"></p></span>-->
    </div>
       </div>
             
   <div class="form-row">
        <div class="col-md-4 mb-3">
                <label for="validationDefault03" >Expected Life / Expired Years</label>
      <input type="text" name="expiry" min="0" value ="5" maxlength="2"  class="form-control" id="expiry">
    </div>   
    <div class="col-md-4 mb-3">
      <label for="validationDefault03">Warranty</label>
     <div class="input-group mb-3">
      <input type="text" name="warranty" placeholder="12" minlength = "0" maxlength = "2" class="form-control" id="warranty">
        <div class="input-group-append">
            <span class="input-group-text" style="background: #60A8F2;color: white;" id="basic-addon2">Months</span>
        </div> 
    </div>
       <!--<span class="error"><p id="warranty_error"></p></span>-->
    </div>    
       </div>
             
   
        
    
    <nav class="navbar navbar-expand-sm navbar-dark text-white">
        <!--<a class="navbar-brand" href="#">-->
            <img src="assets/images/Purchasing Info.png" width="30" height="30" class="d-inline-block align-top" alt="">
            &nbsp;&nbsp;<h5>Purchasing Information</h5>
  <!--</a>-->

</nav>
                            <br>
        <div class="form-row"> 
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Purchase Type </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="purchase_type" id="purchase_type" >
        <!--<option value='Male' selected='selected'>Local</option>-->
          <?php
   $sel_query1 = "Select * FROM purchase_type WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">PO# / Document #</label>
      <input type="text" name="po_no"  class="form-control" id="po_no" maxlength="30">
      <!--<span class="error"><p id="po_no_error"></p></span>-->
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Purchase Year </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="p_year" id="p_year" >
        <!--<option value='1990' selected='selected'>1990</option>-->
          <?php
  // Loops over each int[year] from current year, back to the $earliest_year [1950]
  foreach ( range( $latest_year, $earliest_year ) as $i ) {
    // Prints the option with the next year in range.
    print '<option value="'.$i.'"'.($i === $currently_selected ? ' selected="selected"' : '').'>'.$i.'</option>';
  }
      ?>
        </select>
    </div>
  </div>
        
    <div class="form-row"> 
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Funding Source </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="funding_source" id="funding_source" >
        <!--<option value='KP DOH' selected='selected'>KP DOH</option>-->
          <?php
   $sel_query1 = "Select * FROM funding_source WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
             <div class="col-md-4 mb-3">
      <label for="validationDefault01">Supplier</label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="supplier" id="supplier">
        <!--<option value='ABC & CO' selected='selected'>ABC & CO</option>-->
          <?php
   $sel_query1 = "Select * FROM supplier WHERE status='1'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
        <div class="col-md-4 mb-3">
      <label for="validationDefault01">Scale </label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="scale_name" id="scale_name">
        <option value=''>Select</option>
        <option value='Billion'>Billion </option>
        <option value='Million'>Million</option>
      </select>
    </div> 
            <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Purchase Price </label>
      <input type="text" name="p_price" class="form-control" id="p_price" maxlength="10" >
      <!--<span class="error"><p id="p_price_error"></p></span>-->
      <span class=""><p id="scale_pkr"></p></span>
    </div>
       </div>
    
      
    <nav class="navbar navbar-expand-sm navbar-dark text-white">
        <!--<a class="navbar-brand" href="#">-->
            <img src="assets/images/Record.png" width="30" height="30" class="d-inline-block align-top" alt="">
            &nbsp;&nbsp;<h5>Record</h5>
  <!--</a>-->

</nav>
                            <br>
        <div class="form-row"> 
       <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Stock Register </label>
      <input type="text" name="stock_reg"  class="form-control" id="stock_reg" >
      <span class="error"><p id="stock_reg_error"></p></span>
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Location of Asset <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control select2" name="loc_of_asset" id="loc_of_asset" required>
        <!--<option value='DHQ Swat' selected='selected'>DHQ Swat</option>-->
       <?php 
       if($_SESSION['dhqid'] != '' && $_SESSION['dhqid'] != 'NULL')
       { ?>
                
          <?php
   $sel_query1 = "SELECT
                        warehouses.warehouse_name,
                        warehouses.pk_id,
                        warehouses.stakeholder_office_id,
                        warehouses.warehouse_type_id
                FROM
                        warehouses
                WHERE
                        warehouses.province_id = 3
                AND warehouses.stakeholder_office_id = 4
                AND warehouses.`status` = 1
                AND warehouses.warehouse_type_id = 4
                $districid
                ORDER BY
                        warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    
                    if ($result2->num_rows > 0) { ?>
                    <optgroup label="DHQ Hospital">
                  <?php  while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php
            }
       }
       else {
       if($_SESSION['did'] == '' || $_SESSION['did'] == 'NULL')
       { ?>
                
          <?php
   $sel_query1 = "SELECT
                    warehouses.warehouse_name,
                    warehouses.pk_id,
                    warehouses.stakeholder_office_id
                    FROM
                            warehouses
                    WHERE
                    warehouses.province_id = 3 AND
                    warehouses.stakeholder_office_id = 2
                    AND warehouses.status = 1
                    ORDER BY
                            warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    
                    if ($result2->num_rows > 0) { ?>
                    <optgroup label="Provincial Store">
                <?php    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                    </optgroup>
       <?php }
       }
                if($_SESSION['tid'] == '' || $_SESSION['tid'] == 'NULL')
       {
       ?>
                
          <?php
   $sel_query1 = "SELECT
                    warehouses.warehouse_name,
                    warehouses.pk_id,
                    warehouses.stakeholder_office_id
                    FROM
                            warehouses
                    WHERE
                    warehouses.province_id = 3 AND
                    warehouses.stakeholder_office_id = 4
                    AND warehouses.status = 1
                    $districid
                    AND warehouse_type_id NOT IN (4)
                    ORDER BY
                            warehouse_name
                    ";
//   echo $sel_query1;
                    $result2 = mysqli_query($conn, $sel_query1);
                    
                    if ($result2->num_rows > 0) { ?>
                    <optgroup label="Districts Store">
                <?php    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php }
       }    if($_SESSION['ucid'] == '' || $_SESSION['ucid'] == 'NULL')
       {
       ?>
                
          <?php
   $sel_query1 = "SELECT
                        warehouses.warehouse_name,
                        warehouses.pk_id,
                        warehouses.stakeholder_office_id
                        FROM
                                warehouses
                        WHERE
                        warehouses.province_id = 3 AND
                        warehouses.stakeholder_office_id IN (5)
                        AND warehouses.status = 1
                        $districid
                        $thid
                        ORDER BY
                                warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    
                    if ($result2->num_rows > 0) { ?>
                    <optgroup label="Tehsil Store">
                 <?php   while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php } 
       }
//       if($_SESSION['hfid'] == '' || $_SESSION['hfid'] == 'NULL')
//       {
       ?>
                <!--<optgroup label="UC Stores">-->
          <?php
//   $sel_query1 = "SELECT
//                        warehouses.warehouse_name,
//                        warehouses.pk_id,
//                        warehouses.stakeholder_office_id
//                        FROM
//                                warehouses
//                        WHERE
//                        warehouses.province_id = 3 AND
//                        warehouses.stakeholder_office_id IN (6)
//                        AND warehouses.status = 1
//                        $districid
//                        $ucid
//                        ORDER BY
//                                warehouse_name
//                    ";
//                    $result2 = mysqli_query($conn, $sel_query1);
//                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php //    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
//                    }
      ?>
                <!--</optgroup>-->
       <?php // } 
       if($_SESSION['hfid'] != '' || $_SESSION['hfid'] == 'NULL')
       {
       ?>
                <optgroup label="HF Stores">
          <?php
   $sel_query1 = "SELECT
                        warehouses.warehouse_name,
                        warehouses.pk_id,
                        warehouses.stakeholder_office_id
                        FROM
                                warehouses
                        WHERE
                        warehouses.province_id = 3 AND
                        warehouses.stakeholder_office_id IN (6)
                        AND warehouses.status = 1
                        $districid
                        $hfid
                        ORDER BY
                                warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    
                    if ($result2->num_rows > 0) { ?>
                    
                <?php    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php }  
          }
       }
       ?>
        </select>
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Assigned To </label>
      <input type="text" name="ass_to"  class="form-control" id="ass_to" >
      <span class="error"><p id="ass_to_error"></p></span>
    </div>
       </div>
        
        <div class="form-row"> 
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">GL Code</label>
      <input type="text" name="gl_code"  class="form-control" id="gl_code" maxlength="25">
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Depreciation</label>
      <div class="input-group mb-3">
      <input type="number" name="depreciation" placeholder="Depreciation" min="0" max="100" class="form-control" id="depreciation">
      <div class="input-group-append">
        <span class="input-group-text" style="background: #60A8F2;color: white;" id="basic-addon2">%</span>
        </div>
      </div>
      <!--<span class="error"><p id="depreciation_error"></p></span>-->
    </div>
          
       </div>
        
    <nav class="navbar navbar-expand-sm navbar-dark text-white">
        <!--<a class="navbar-brand" href="#">-->
            <img src="assets/images/Details.png" width="30" height="30" class="d-inline-block align-top" alt="">
            &nbsp;&nbsp;<h5>Details</h5>
  <!--</a>-->

</nav>
                            <br>
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Operation Instructions (if any)</label>
    <textarea class="form-control" name="instructions" id="instructions" rows="3"></textarea>
  </div>
        <br>
         <div class="form-row">
    <label for="exampleFormControlTextarea1">Detail Description / Comments</label>
    <textarea class="form-control" name="d_description" id="d_description" rows="3"></textarea>
  </div>
        <br>
        <div class="form-row">
          <div class="form-group">
            <label>Select file</label>
            <input type="file" id="filePHOTO" name="myfile" class="filestyle" data-buttonname="btn-secondary">
            <span id="file_error"></span>
        </div>
        </div>
        <br>
        
        <nav class="navbar navbar-expand-sm navbar-dark text-white">
        <!--<a class="navbar-brand" href="#">-->
            <!--<img src="assets/images/form.png" width="30" height="30" class="d-inline-block align-top" alt="">-->
            &nbsp;&nbsp;<h5>Total Cost</h5>
  <!--</a>-->

</nav>
        <br>
        
            <input type="hidden" id="id" name="id" value="">
            <div class="form-row">
            <div class="col-md-4 mb-3">
            <div class="form-group">
                <label for="rcost">Repair Cost </label>
            <input name="rcost" id="rcost" class="form-control" readonly/>
            </div>
            </div>
            
            <div class="col-md-4 mb-3">
            <div class="form-group">
                <label for="accscost">Accessories / Parts Cost </label>
            <input name="accscost" id="accscost" class="form-control" readonly/>
            </div>
            </div>
            
            <div class="col-md-4 mb-3">
            <div class="form-group">
                <label for="tprice">Total including initial Price </label>
            <input name="tprice" id="tprice" class="form-control" readonly/>
            </div>
            </div>
            </div>
                                                            </div>
                            <div id="error" style="color:red;text-align: right;"><h4>This Asset Already Exist!</h4></div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary waves-effect waves-light">Save changes</button>
                                                                </div>
                                                                </form>
                                                            </div><!-- /.modal-content -->
                                                        </div><!-- /.modal-dialog -->
                                                    </div><!-- /.modal -->
                                                </div>
                    </div> <!-- container-fluid -->

                </div> <!-- content -->

                <footer class="footer">
                    <!--© 2018 Agroxa <span class="d-none d-sm-inline-block">- Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand.</span>-->
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
        <script src="../plugins/bootstrap-md-datetimepicker/js/moment-with-locales.min.js"></script>
        <script src="../plugins/bootstrap-md-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

        <!-- Plugins js -->
        <script src="../plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>

        <script src="../plugins/select2/js/select2.min.js"></script>
        <script src="../plugins/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="../plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js"></script>
        <script src="../plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js"></script>
        
        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        
        <!-- Parsley js -->
        <script src="../plugins/parsleyjs/parsley.min.js"></script>
        <script src="assets/pages/form-advanced.js"></script>

        
        <!-- App js -->
        <script src="js/script.js"></script>
        <script src="assets/js/app.js"></script>
<!--        <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/fixedcolumns/3.3.2/js/dataTables.fixedColumns.min.js"></script>-->
        
<!--        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.print.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>-->
        
        
        <!--<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>-->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-html5-1.6.1/b-print-1.6.1/fh-3.1.6/datatables.min.js"></script>
        
        <script>
            
//              $(function() {
//    $(".preload").fadeOut(3000, function() {
//        $(".content").fadeIn(4000);        
//    });
//});
$("#error").hide();
$(document).ready(function() {
    $("#scale_name").change(function () {
//    alert($('#scale_name').val());
    $('#scale_pkr').html($('#scale_name').val());
});
    $(".preload").fadeOut(1000, function() {
        $(".content").fadeIn(500);        
    });
    });
            $(document).ready(function() {
                $('form').parsley();
            });
            
            
            
            $(document).ready(function() {
                
                // Setup - add a text input to each footer cell
    $('#example thead tr').clone(true).appendTo( '#example thead' );
    $('#example thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
 
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
 
    var table = $('#example').DataTable( {
      scrollY:        "300px",
        scrollX:        true,
      scrollCollapse: true,
        paging:         true,
        fixedColumns:   {
            leftColumns:1,
            rightColumns: 1
        },
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
      dom: 'Bfrtip',
        buttons: [
            'excel'
        ],
        orderCellsTop: true,
        fixedHeader: true
    } );
                
//    $('#example').DataTable( {
//        initComplete: function () {
//            this.api().columns([1]).every( function () {
//                var column = this;
//                var select = $('<select><option value=""></option></select>')
////                    .appendTo( $(column.footer()).empty() )
//            .appendTo( $("#example thead tr:eq(0) th").eq(column.index()).empty() )
//                    .on( 'change', function () {
//                        var val = $.fn.dataTable.util.escapeRegex(
//                            $(this).val()
//                        );
//                        column
//                            .search( val ? '^'+val+'$' : '', true, false )
//                            .draw();
//                    } );
// 
//                column.data().unique().sort().each( function ( d, j ) {
////                    select.append( '<option value="'+d+'">'+d+'</option>' )
//select.append('<option value="' + d + '">' + d.substr(0,10) + '</option>')
//
//                } );
//                
//            } );
//            
//        },
////'dom':'<"c8tableTools01"Bf><"c8tableBody"t><"c8tableTools02"lipr>',
////            'autoWidth':true,
//        scrollY:        "300px",
//        scrollX:        true,
//        scrollCollapse: true,
//        paging:         true,
//        fixedColumns:   {
//            leftColumns:1,
//            rightColumns: 1
//        },
//        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
//        dom: 'Bfrtip',
//        buttons: [
//            'excel'
//        ]
//
//    } );
    
} );

$(document).ready(function(){
    $("#filePHOTO").change(function(){
    
    var file = this.files[0];
    var fileType = file.type;
    var match = ['application/pdf', 'application/msword', 'application/vnd.ms-office', 'image/jpeg', 'image/png', 'image/jpg'];
    
    
    $("#file_error").html("");
    $(".filestyle").css("border-color","#F0F0F0");
    var file_size = $('#filePHOTO')[0].files[0].size;
    
    if(file_size > 1048576) {
        
    $("#file_error").html("<p style='color:#FF0000'>File size is greater than 1MB</p>");
    $(".filestyle").css("border-color","#FF0000");
    $("#filePHOTO").val('');
    return false;
    
    } 
    else if(!((fileType == match[0]) || (fileType == match[1]) || (fileType == match[2]) || (fileType == match[3]) || (fileType == match[4]) || (fileType == match[5]))){
       
//        alert('Sorry, only PDF, DOC, JPG, JPEG, & PNG files are allowed to upload.');
        $("#file_error").html("<p style='color:#FF0000'>Sorry, only PDF, DOC, JPG, JPEG, & PNG files are allowed to upload.</p>");
        $(".filestyle").css("border-color","#FF0000");
        $("#filePHOTO").val('');
        return false;
        
    }
//     else{
//            return true;
//    }
    });
});

$(document).ready(function() {
    $('#example1').DataTable({
                scrollX:        true,
                fixedColumns:   {
            leftColumns:2,
            rightColumns: 1
        }
            });
});
$(document).ready(function() {
    $('#example2').DataTable({
        scrollX:        true,
    });
});
    
        </script>
    <script type="text/javascript">
  function GetAssetDetailsN(id)
    {
//        alert(id);
        if(id != '')
        {
            location.href = "update_asset.php?id="+id+'#timeline';
        }
    }
    function GetAssetDetailsNA(id)
    {
//        alert(id);
        if(id != '')
        {
            location.href = "update_asset.php?aid="+id+'#timeline';
        }
    }
    
    
    function fnExcelReport()
{
    var tab_text="<table border='2px'><tr bgcolor='#33B23F'>";
    var textRange; var j=0;
    tab = document.getElementById('example'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}

$(document).ready(function(){
   
 $('#form_id').on('submit', function(event){
//     var id = $('#id').val();
  event.preventDefault();
  $.ajax({
   type:"POST",
   url:"asset_save_info.php",
   data: new FormData(this),
    contentType: false,
    cache: false,
    processData:false,
   success:function(data){
//       fetch_data();
//       alert(id);
    var user = JSON.parse(data);
//alert(user.match);
        if(user.match == '1' || user.match == '0')
       {
            $("#error").show();
             setTimeout(function() { $("#error").hide(); }, 3000);
       }
       
       else if(user.id != '')
       {
            location.href = "update_asset.php";
       }
//       else 
//           if(user.chkid == 0)
//       {
//            $("#insert").show();
//             setTimeout(function() { $("#insert").hide(); }, 3000);
//        }
//        else
//        {
//            $("#update").show();
//            setTimeout(function() { $("#update").hide(); }, 3000);
//        }
    },
   Error:function(data){
       alert("Failed to Insert the data");
   }
  });
 });
});
    </script>
    </body>

</html>

