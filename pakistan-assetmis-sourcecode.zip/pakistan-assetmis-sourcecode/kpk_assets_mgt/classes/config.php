<?php


$host = "localhost"; // MySQL host name eg. localhost
$user = ""; // MySQL user. eg. root ( if your on localserver)
$password = ""; // MySQL user password  (if password is not set for your root user then keep it empty )
$database = ""; // MySQL Database name
//$conn = mysqli_connect($hostname, $username, $password, $db);
////mysql_select_db($db, $conn);
//if (mysqli_connect_errno()) {
//    printf("Connect failed: %s\n", mysqli_connect_error());
//    exit();
//}

//$db = mysql_connect($host, $user, $password) or die("Could not connect to database");
//$conn = mysqli_connect($host, $user, $password, $database);
//// Select MySQL Database 
//mysql_select_db($database, $db);

$conn = new mysqli($host, $user, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>
