<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php include 'classes/config.php'; 
$id = '';
$aid = '';
if(isset($_REQUEST['id']) && $_REQUEST['id'] != '')
    {
        $id = $_REQUEST['id'];
    }
    if(isset($_REQUEST['aid']) && $_REQUEST['aid'] != '')
    {
        $aid = $_REQUEST['aid'];
    }
    
     $currently_selected = date('Y'); 
  // Year to start available options at
  $earliest_year = 1990; 
  // Set your latest year you want in the range, in this case we use PHP to just set it to the current year.
  $latest_year = date('Y'); 
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/fixedcolumns/3.3.2/css/fixedColumns.dataTables.min.css">
    <!-- Bootstrap CSS File  -->
    

<!--        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
        
        <script src="https://cdn.datatables.net/fixedcolumns/3.3.2/js/dataTables.fixedColumns.min.js"></script>-->

        <style>
/*            .c8tableBody  {
    width:100%;
    overflow-x:scroll;
}*/
th, td { white-space: nowrap; }
/*.content {display:none;}
.preload { width:100px;
    height: 100px;
    position: fixed;
    top: 50%;
    left: 50%;}*/
            </style>
        
    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
             <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.php" class="logo">
                        <span>
                            <img src="assets/images/logo.png" alt="" >
                        </span>
                        <i>
                            <img src="assets/images/logo-sm.png" alt="" height="22">
                        </i>
                    </a>
                </div>

                <nav class="navbar-custom">
                    <ul class="navbar-right d-flex list-inline float-right mb-0">

                        <li class="dropdown notification-list">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="index.php" role="button" aria-haspopup="false" aria-expanded="false">
                                <i class="noti-icon"> <?php echo $_SESSION['username']; ?></i>
                                <!--<span class="badge badge-pill badge-info noti-icon-badge">3</span>-->
                            </a>
                        </li>
                        <li class="dropdown notification-list">
                            <div class="dropdown notification-list nav-pro-img">
                                <a class="dropdown-toggle nav-link arrow-none waves-effect nav-user waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-account-circle m-r-5"></i> <?php echo $_SESSION['username']; ?></a>
<!--                                    <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5"></i> My Wallet</a>
                                    <a class="dropdown-item d-block" href="#"><span class="badge badge-success float-right">11</span><i class="mdi mdi-settings m-r-5"></i> Settings</a>
                                    <a class="dropdown-item" href="#"><i class="mdi mdi-lock-open-outline m-r-5"></i> Lock screen</a>-->
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php"><i class="mdi mdi-power text-danger"></i> Logout</a>
                                </div>                                                                    
                            </div>
                        </li>

                    </ul>
                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>                        
                        <li class="d-none d-sm-block">
                            <div class="dropdown pt-3 d-inline-block">
                                <a class="waves-effect waves-light" href="#"  aria-haspopup="true" aria-expanded="false">
                                    <h4 style="color: white;">Data Management System</h4>
                                </a>
                                
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </li>
                    </ul>

                </nav>

            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'left_menu.php';?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Update Asset</h4>
                                </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
<div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
</div>
<div class="content">
                        <div class="page-content-wrapper">
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
                                            <h3>Records:</h3>
            <div class="check">
                <div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
</div>
<div class="content">
                <!--<div style="overflow-x:auto;">-->
             <table id="example" class="stripe row-border order-column" style="width:100%;">
        <thead >
                                                <tr>
							<!--<th>No.</th>-->
                                                        <th>System ID (Auto)</th>
                                                        <th>Asset Name</th>
                                                        <th>Serial no</th>
                                                        <th>Asset Location</th>
							<th>Stock Register</th>
                                                        <th>Assigned To</th>
                                                        <th>Depreciation</th>
                                                        <th>Asset Status</th>
                                                        <th>GI Code</th>
                                                        <th>Specification</th>
                                                        <th>Operational Instructions</th>
                                                        <th>Detail Description</th>
                                                        <th>Purchase Year</th>
                                                        <th>Purchase Expiry</th>
                                                        <th>Purchase Warranty</th>
                                                        <th>Purchase Document No</th>
                                                        <th>Purchase Price</th>
                                                        <th>Purchase Type</th>
                                                        <th>Category</th>
                                                        <th>Funding Source</th>
                                                        <th>Manufacturer</th>
                                                        <th>Supplier</th>
                                                        <th>Model</th>
            <?php if($_SESSION["userid"] != '2' && $_SESSION["userid"] != '5')
                {
            ?>
                                                        <th class="text-center">Action</th>
            <?php 
                    }
            ?>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                asset_info.id,
                                                                asset_info.asset_id,
                                                                asset_info.asset_name,
                                                                asset_info.serial_no,
                                                                asset_info.asset_location,
                                                                asset_info.stock_register,
                                                                asset_info.assigned_to,
                                                                asset_info.depreciation,
                                                                asset_info.asset_status,
                                                                asset_info.gl_code,
                                                                asset_info.specification,
                                                                asset_info.oper_inst,
                                                                asset_info.detail_desc,
                                                                asset_info.purchase_year,
                                                                asset_info.purchase_expiry,
                                                                asset_info.purchase_warranty,
                                                                asset_info.purchase_document_no,
                                                                asset_info.purchase_price,
                                                                asset_info.purchase_type_id,
                                                                asset_info.category_id,
                                                                asset_info.funding_source_id,
                                                                asset_info.manufacturer_id,
                                                                asset_info.supplier_id,
                                                                asset_info.model,
                                                                asset_info.status
                                                        FROM
                                                                asset_info 
                                                                WHERE asset_info.user_id = '".$_SESSION['uid']."'";

//                                                echo $query;
//                                                exit;
//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <!--<td><?php echo $number; ?></td>-->
            <td><?php echo $row['asset_id']; ?></td>
            <td><?php echo $row['asset_name']; ?></td>
            <td><?php echo $row['serial_no']; ?></td>
            <td><?php echo $row['asset_location']; ?></td>
            <td><?php echo $row['stock_register']; ?></td>
            <td><?php echo $row['assigned_to']; ?></td>
            <td><?php echo $row['depreciation']; ?></td>
            <td><?php echo $row['asset_status']; ?></td>
            <td><?php echo $row['gl_code']; ?></td>
            <td><?php echo $row['specification']; ?></td>
            <td><?php echo $row['oper_inst']; ?></td>
            <td><?php echo $row['detail_desc']; ?></td>
            <td><?php echo $row['purchase_year']; ?></td>
            <td><?php echo $row['purchase_expiry']; ?></td>
            <td><?php echo $row['purchase_warranty']; ?></td>
            <td><?php echo $row['purchase_document_no']; ?></td>
            <td><?php echo $row['purchase_price']; ?></td>
            <td><?php echo $row['purchase_type_id']; ?></td>
            <td><?php echo $row['category_id']; ?></td>
            <td><?php echo $row['funding_source_id']; ?></td>
            <td><?php echo $row['manufacturer_id']; ?></td>
            <td><?php echo $row['supplier_id']; ?></td>
            <td><?php echo $row['model']; ?></td>
            <?php if($_SESSION["userid"] != '2' && $_SESSION["userid"] != '5')
                {
            ?>
            <td>
                    <button class="btn btn-success waves-effect waves-light" data-toggle="modal" data-target=".bs-example-modal-lg"  onclick="GetAssetDetails(<?php echo $row['id']; ?>)">Update</button>
                    <button class="btn btn-success waves-effect waves-light" data-toggle="modal" data-target="#myModal" onclick="GetAssetDetailsN(<?php echo $row['asset_id']; ?>)" >Repair</button>
                    <button class="btn btn-success waves-effect waves-light" data-toggle="modal" data-target="#myModal1" onclick="GetAssetDetailsNA(<?php echo $row['asset_id']; ?>)" >Accessories</button>
            </td>
            <?php 
                    }
            ?>
<!--            <td>
                <?php if($row['status'] == 1)
               {?>
                <button onclick="active(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>-->
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
</div>
                </div>
            
                                        <!--</div>-->
            
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->  
                        </div>
</div>
 <div id="catchme">                       <!-- end page content-->
 <?php if(isset($aid) && $aid != '' )
{    
?>                            
                            <!--Accordion wrapper-->
<div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">

  <!-- Accordion card -->
  <div class="card">

    <!-- Card header -->
    <div class="card-header bg-primary " role="tab" id="headingOne1">
      <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne1" aria-expanded="true"
        aria-controls="collapseOne1">
        <h5 class="mb-0 text-white" >
          Accessories Management <i class="fas fa-angle-down rotate-icon "></i>
        </h5>
      </a>
    </div>

    <!-- Card body -->
    <div id="collapseOne1" class="collapse show" role="tabpanel" aria-labelledby="headingOne1"
      data-parent="#accordionEx">
      <div class="card-body">

                            
                            
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
                                            
                                            
                                            
                                            
                                            <form method="POST" action="asset_accessories_mang_info.php" id="form_id" autocomplete="off">
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Letter#/Ref# <span style="color:red;">*</span></label>
      <input type="text" name="acc_ref_id" placeholder="" class="form-control" id="acc_ref_id" required>
    </div>
     <div class="col-md-2 mb-3">
      <label for="validationDefault03">Date <span style="color:red;">*</span></label>
      <input type="date" name="acc_date" min='2020-01-01' value ="<?php echo date('Y-m-d') ?>" class="form-control" id="acc_date" required>
    </div>
  </div>
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Name / Description <span style="color:red;">*</span></label>
    <textarea class="form-control" name="acc_description" id="acc_description" rows="2" required></textarea>
  </div>
        <br>
        <div class="form-row">             
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Supplied By <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="acc_sup_by" id="acc_sup_by" required>
        <option value='Local' selected='selected'>Local</option>
        <option value='Supplier/Vendor' selected='selected'>Supplier/Vendor</option>
          <?php
   $sel_query1 = "Select gender FROM gender_table";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['gender'].'">'.$row['gender'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
        <div class="col-md-2 mb-3">
      <label for="validationDefault03" class="required">Price <span style="color:red;">*</span></label>
      <input type="text" name="acc_price" placeholder="Price" class="form-control" id="acc_price" required>
    </div>
            <div class="col-md-2 mb-3">
      <label for="validationDefault03" class="required">Quantity <span style="color:red;">*</span></label>
      <input type="text" name="acc_quantity" placeholder="Quantity" class="form-control" id="acc_quantity" required>
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Status <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="acc_status" id="acc_status" required>
        <option value='Spare' selected='selected'>Spare</option>
          <?php
   $sel_query1 = "Select gender FROM gender_table";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['gender'].'">'.$row['gender'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
  </div>
        <input type="hidden" id="asset_id1" name="asset_id1" value="<?php echo $aid; ?>">
        
         <div class="form-row">
    <label for="exampleFormControlTextarea1">Detail Description / Comments</label>
    <textarea class="form-control" name="acc_detail" id="acc_detail" rows="3"></textarea>
  </div>
            <!--<input type="hidden" id="id" name="id" value="3487">-->
          <div class="modal-footer">
            <button type="submit" href="#lab_history" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Insert</button>
            <a href="update_asset.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
        
                                            <h3>Records:</h3>
            <div class="check">
             <table id="example2" class="display" style="width:100%;background: #2DA467;">
        <thead style="color: white;">
                                                <tr>
							<!--<th>No.</th>-->
                                                        <th>System ID (Auto)</th>
                                                        <th>Letter#/ Ref#</th>
                                                        <th>Description</th>
                                                        <th>Date</th>
							<th>Supplied By</th>
                                                        <th>Qty</th>
                                                        <th>Comments</th>
<!--                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>-->
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                            asset_accessorie_mang_info.id,
                                                            asset_accessorie_mang_info.ref_no,
                                                            asset_accessorie_mang_info.date,
                                                            asset_accessorie_mang_info.description,
                                                            asset_accessorie_mang_info.supplied_by,
                                                            asset_accessorie_mang_info.price,
                                                            asset_accessorie_mang_info.quantity,
                                                            asset_accessorie_mang_info.`status`,
                                                            asset_accessorie_mang_info.`comment`
                                                            FROM
                                                            asset_accessorie_mang_info
                                                            WHERE 
                                                            asset_accessorie_mang_info.asset_no = $aid
                                                    ";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <!--<td><?php echo $number; ?></td>-->
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['ref_no']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['supplied_by']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td><?php echo $row['comment']; ?></td>
<!--            <td>
                    <button onclick="GetUserDetails(<?php echo $row['id']; ?>)" class="btn btn-warning">Update</button>
            </td>
            <td>
                    <button onclick="DeleteUser(<?php echo $row['id']; ?>)" class="btn btn-danger">Delete</button>
               <?php if($row['ref_no'] == 1)
               {?>
                <button onclick="active(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>-->
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
            <!--</div>-->
        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                                
</div>
                                
                                
 <?php
} else if(isset($id) && $id != '' )
{    
?>                             
                                
<div class="accordion md-accordion" id="accordionEx1" role="tablist" aria-multiselectable="true">

  <!-- Accordion card -->
  <div class="card">

    <!-- Card header -->
    <div class="card-header bg-primary " role="tab" id="headingOne1">
      <a data-toggle="collapse" data-parent="#accordionEx1" href="#collapseOne2" aria-expanded="true"
        aria-controls="collapseOne2">
        <h5 class="mb-0 text-white" >
          Repair Management <i class="fas fa-angle-down rotate-icon "></i>
        </h5>
      </a>
    </div>

    <!-- Card body -->
    <div id="collapseOne2" class="collapse show" role="tabpanel" aria-labelledby="headingOne1"
      data-parent="#accordionEx1">
      <div class="card-body">

                            
                            
                            <div class="row">
            
                                <div class="col-lg-12">
                                    <div class="card m-b-20">
                                        <div class="card-body">
                                            
                                            
                                            
                                            
<form method="POST" action="asset_repair_info.php" id="form_id" autocomplete="off">
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">PO#/Letter#/Ref# <span style="color:red;">*</span></label>
      <input type="text" name="repair_ref_no" placeholder="" class="form-control" id="repair_ref_no" required>
    </div>
     <div class="col-md-2 mb-3">
      <label for="validationDefault03">Date <span style="color:red;">*</span></label>
      <input type="date" name="date" min='2020-01-01' value ="<?php echo date('Y-m-d') ?>" class="form-control" id="date" required>
    </div>
  </div>
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Description / Details <span style="color:red;">*</span></label>
    <textarea class="form-control" name="repair_detail" id="repair_detail" rows="2" required></textarea>
  </div>
        <br>
        <div class="form-row"> 
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Repaired by <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
      <select class="form-control mr-2" name="repair_by" id="repair_by" required>
        <option value='Local' selected='selected'>Local</option>
        <option value='Supplier/Vendor' selected='selected'>Supplier/Vendor</option>
          <?php
   $sel_query1 = "Select gender FROM gender_table";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['gender'].'">'.$row['gender'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault03">Repair Warranty <span style="color:red;">*</span></label>
      <div class="input-group mb-3">
          <input type="text" name="repair_warranty"  minlength = "0" maxlength = "2" class="form-control" id="repair_warranty" value="12" required>
        <div class="input-group-append">
            <span class="input-group-text" style="background: #60A8F2;color: white;" id="basic-addon2">Months</span>
        </div> 
    </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Repair Amount <span style="color:red;">*</span></label>
      <input type="text" name="repair_amount" placeholder="" class="form-control" id="repair_amount" required>
    </div>
            
  </div>
        <input type="hidden" id="asset_idr" name="asset_idr" value="<?php echo $id ?>">
         <div class="form-row">
    <label for="exampleFormControlTextarea1">Comments / Remarks</label>
    <textarea class="form-control" name="r_comment" id="r_comment" rows="3"></textarea>
  </div>
            <!--<input type="hidden" id="id" name="id" value="3487">-->
          <div class="modal-footer">
            <button type="submit" href="#lab_history" class="btn btn-icon btn-primary glyphicons circle_ok"><i></i>Insert</button>
            <a href="update_asset.php" id="cancel" name="cancel" class="btn default">Reset</a>
        </div>
            <?php 
//                    }
        ?>
</form>
            <!--<div id="catchme">-->
                                            <h3>Records:</h3>
            <div class="check">
             <table id="example1" class="display" style="width:100%;background: #2DA467;">
        <thead style="color: white;">
                                                <tr>
							<!--<th>No.</th>-->
                                                        <th>System ID (Auto)</th>
                                                        <th>PO#/ Letter#/ Ref#</th>
                                                        <th>Repair Description</th>
                                                        <th>Repair Date</th>
							<th>Repair By</th>
                                                        <th>Warranty of Repair , if any</th>
                                                        <th>Comments</th>
<!--                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>
                                                        <th>Action</th>-->
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                asset_repair_info.id,
                                                                asset_repair_info.repair_po_no,
                                                                asset_repair_info.date,
                                                                asset_repair_info.description,
                                                                asset_repair_info.repaired_by_id,
                                                                asset_repair_info.repair_warrenty,
                                                                asset_repair_info.repair_amount,
                                                                asset_repair_info.`comment`
                                                                FROM
                                                                asset_repair_info
                                                                WHERE asset_repair_info.asset_no = $id
                                                    ";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <!--<td><?php echo $number; ?></td>-->
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['repair_po_no']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['repaired_by_id']; ?></td>
            <td><?php echo $row['repair_warrenty']; ?></td>
            <td><?php echo $row['comment']; ?></td>
<!--            <td>
                    <button onclick="GetUserDetails(<?php echo $row['id']; ?>)" class="btn btn-warning">Update</button>
            </td>
            <td>
                    <button onclick="DeleteUser(<?php echo $row['id']; ?>)" class="btn btn-danger">Delete</button>
               <?php if($row['ref_no'] == 1)
               {?>
                <button onclick="active(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>-->
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
            <!--</div>-->
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                                        </div>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
</div>
                                
<?php }
?>                       
 </div>               
                        
                        
                        
<div class="col-sm-6 col-md-3 m-t-30">
            
            
                                                    <!--  Modal content for the above example -->
                                                    <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title mt-0" id="myLargeModalLabel">Update Asset</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                </div>
                        <form method="POST" action="asset_save_info.php" id="form_id" autocomplete="off">
                        <div class="modal-body">
                                                                    
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationDefault01">Sys Asset#</label>
      <!--<input type="number" step="0.01" name="live_birth_perc" min="0" placeholder="Patient Id" class="form-control" id="validationDefault01" placeholder="" required>-->
      <input type="text" class="form-control" placeholder="Auto GID" name="asset_id" id="asset_id"  readonly>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Asset Name <span style="color:red;">*</span></label>
      <input type="text" name="asset_name" placeholder="Name" class="form-control" id="asset_name" required>
    </div>
      <div class="col-md-4 mb-3">
      <label for="validationDefault01">Category <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="category" id="category" required>
        <!--<option value='Equipment' selected='selected'>Equipment</option>-->
          <?php
   $sel_query1 = "Select * FROM category WHERE status='1' && user_id = '".$_SESSION['uid']."'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
  </div>
       <div class="form-row"> 
        
           <div class="col-md-4 mb-3">
      <label for="validationDefault01">Make / Manufacturer <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="manufacturer" id="manufacturer" required>
        <!--<option value='Male' selected='selected'>Siemens</option>-->
          <?php
   $sel_query1 = "Select * FROM manufacturer WHERE status='1' && user_id = '".$_SESSION['uid']."'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
           <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Model <span style="color:red;">*</span></label>
      <input type="text" name="model" placeholder="Model" class="form-control" id="model" required>
    </div>
           <div class="col-md-4 mb-3">
      <label for="validationDefault01">Supplier <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="supplier" id="supplier" required>
        <!--<option value='ABC & CO' selected='selected'>ABC & CO</option>-->
          <?php
   $sel_query1 = "Select * FROM supplier WHERE status='1' && user_id = '".$_SESSION['uid']."'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
       </div>
        
        
        
        <div class="form-row"> 
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Serial Number <span style="color:red;">*</span></label>
      <input type="text" name="serial_no" placeholder="Serial No" class="form-control" id="serial_no" required>
    </div>
           <div class="col-md-4 mb-3">
      <label for="validationDefault01">Funding Source <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="funding_source" id="funding_source" required>
        <!--<option value='KP DOH' selected='selected'>KP DOH</option>-->
          <?php
   $sel_query1 = "Select * FROM funding_source WHERE status='1' && user_id = '".$_SESSION['uid']."'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Purchase Year <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="p_year" id="p_year" required>
        <!--<option value='1990' selected='selected'>1990</option>-->
    <?php
  // Loops over each int[year] from current year, back to the $earliest_year [1950]
  foreach ( range( $latest_year, $earliest_year ) as $i ) {
    // Prints the option with the next year in range.
    print '<option value="'.$i.'"'.($i === $currently_selected ? ' selected="selected"' : '').'>'.$i.'</option>';
  }
      ?>
        </select>
    </div>
       </div>
        
        <div class="form-row"> 
             
    <div class="col-md-2 mb-3">
      <label for="validationDefault03">Expiry <span style="color:red;">*</span></label>
      <input type="date" name="expiry" min='2020-01-01' value ="<?php echo date('Y-m-d') ?>" class="form-control" id="expiry" required>
    </div>
    <div class="col-md-2 mb-3">
      <label for="validationDefault03">Warranty <span style="color:red;">*</span></label>
      <div class="input-group mb-3">
      <input type="text" name="warranty" placeholder="12" minlength = "0" maxlength = "2" class="form-control" id="warranty" required>
        <div class="input-group-append">
            <span class="input-group-text" style="background: #60A8F2;color: white;" id="basic-addon2">Months</span>
        </div> 
    </div>
    </div>
            
            <div class="col-md-4 mb-3">
      <label for="validationDefault01">Purchase Type <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="purchase_type" id="purchase_type" required>
        <!--<option value='Male' selected='selected'>Local</option>-->
          <?php
   $sel_query1 = "Select * FROM purchase_type WHERE status='1' && user_id = '".$_SESSION['uid']."'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">PO# / Document # <span style="color:red;">*</span></label>
      <input type="text" name="po_no" placeholder="" class="form-control" id="po_no" required>
    </div>
            
  </div>
        
        <div class="form-row"> 
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Purchase Price <span style="color:red;">*</span></label>
      <input type="text" name="p_price" placeholder="Price" class="form-control" id="p_price" required>
    </div>
           <div class="col-md-4 mb-3">
      <label for="validationDefault01">Location of Asset <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="loc_of_asset" id="loc_of_asset" required>
       <?php  if($_SESSION['did'] == '')
       { ?>
                <optgroup label="Provincial Store">
          <?php
   $sel_query1 = "SELECT
                    warehouses.warehouse_name,
                    warehouses.pk_id,
                    warehouses.stakeholder_office_id
                    FROM
                            warehouses
                    WHERE
                    warehouses.province_id = 3 AND
                    warehouses.stakeholder_office_id = 2
                    AND warehouses.status = 1
                    ORDER BY
                            warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php } 
                if($_SESSION['tid'] == '')
       {
       ?>
                <optgroup label="Districts Store">
          <?php
   $sel_query1 = "SELECT
                    warehouses.warehouse_name,
                    warehouses.pk_id,
                    warehouses.stakeholder_office_id
                    FROM
                            warehouses
                    WHERE
                    warehouses.province_id = 3 AND
                    warehouses.stakeholder_office_id = 4
                    AND warehouses.status = 1
                    $districid
                    ORDER BY
                            warehouse_name
                    ";
//   echo $sel_query1;
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php }  if($_SESSION['ucid'] == '')
       {
       ?>
                <optgroup label="Tehsil Store">
          <?php
   $sel_query1 = "SELECT
                        warehouses.warehouse_name,
                        warehouses.pk_id,
                        warehouses.stakeholder_office_id
                        FROM
                                warehouses
                        WHERE
                        warehouses.province_id = 3 AND
                        warehouses.stakeholder_office_id IN (5)
                        AND warehouses.status = 1
                        $districid
                        $thid
                        ORDER BY
                                warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php } if($_SESSION['hfid'] == '')
       {
       ?>
                <optgroup label="UC Stores">
          <?php
   $sel_query1 = "SELECT
                        warehouses.warehouse_name,
                        warehouses.pk_id,
                        warehouses.stakeholder_office_id
                        FROM
                                warehouses
                        WHERE
                        warehouses.province_id = 3 AND
                        warehouses.stakeholder_office_id IN (6)
                        AND warehouses.status = 1
                        $districid
                        $ucid
                        ORDER BY
                                warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php } if($_SESSION['hfid'] != '')
       {
       ?>
                <optgroup label="HF Stores">
          <?php
   $sel_query1 = "SELECT
                        warehouses.warehouse_name,
                        warehouses.pk_id,
                        warehouses.stakeholder_office_id
                        FROM
                                warehouses
                        WHERE
                        warehouses.province_id = 3 AND
                        warehouses.stakeholder_office_id IN (6)
                        AND warehouses.status = 1
                        $districid
                        $hfid
                        ORDER BY
                                warehouse_name
                    ";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['pk_id'].'">'.$row['warehouse_name'].'</option>'; ?>
        
      <?php
                    }
      ?>
                </optgroup>
       <?php } 
       ?>
        </select>
    </div>
       <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Stock Register <span style="color:red;">*</span></label>
      <input type="text" name="stock_reg" placeholder="Stock Register" class="form-control" id="stock_reg" required>
    </div>
       </div>
        
        <div class="form-row"> 
           <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Assigned To <span style="color:red;">*</span></label>
      <input type="text" name="ass_to" placeholder="Assign To" class="form-control" id="ass_to" required>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Depreciation <span style="color:red;">*</span></label>
      <div class="input-group mb-3">
      <input type="number" name="depreciation" placeholder="Depreciation" min="0" max="100" class="form-control" id="depreciation" required>
      <div class="input-group-append">
        <span class="input-group-text" style="background: #60A8F2;color: white;" id="basic-addon2">%</span>
        </div>
      </div>
    </div>
           <div class="col-md-4 mb-3">
      <label for="validationDefault01">Asset Status <span style="color:red;">*</span></label>
      <!--<input type="gender" step="0.01" name="children_age_perc" min="0" placeholder="Gender" class="form-control" id="validationDefault01" placeholder="" required>-->
    <select class="form-control mr-2" name="asset_status" id="asset_status" required>
        <!--<option value='Functional' selected='selected'>Functional</option>-->
          <?php
   $sel_query1 = "Select * FROM status WHERE status='1' && user_id = '".$_SESSION['uid']."'";
                    $result2 = mysqli_query($conn, $sel_query1);
                    while ($row = mysqli_fetch_assoc($result2)) {
   ?>
      
      <?php    echo '<option value="'.$row['id'].'">'.$row['name'].'</option>'; ?>
        
      <?php
                    }
      ?>
        </select>
    </div>
       </div>
                
        <div class="form-row"> 
        <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">GL Code</label>
      <input type="text" name="gl_code" placeholder="GL Code" class="form-control" id="gl_code">
    </div>
           <div class="col-md-4 mb-3">
      <label for="validationDefault03" class="required">Specifications</label>
      <div class="input-group mb-3">
      <input type="text" name="specification" placeholder="Specification" class="form-control" id="specification">
      <div class="input-group-append">
        <span class="input-group-text" style="background: #60A8F2;color: white;" id="basic-addon2">Meter</span>
        </div>
    </div>
       </div>
        </div>
        
        <div class="form-row">
    <label for="exampleFormControlTextarea1">Operation Instructions (if any)</label>
    <textarea class="form-control" name="instructions" id="instructions" rows="3"></textarea>
  </div>
        <br>
         <div class="form-row">
    <label for="exampleFormControlTextarea1">Detail Description / Comments</label>
    <textarea class="form-control" name="d_description" id="d_description" rows="3"></textarea>
  </div>
            <input type="hidden" id="id" name="id" value="">
                                                            </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary waves-effect waves-light">Save changes</button>
                                                                </div>
                                                                </form>
                                                            </div><!-- /.modal-content -->
                                                        </div><!-- /.modal-dialog -->
                                                    </div><!-- /.modal -->
                                                </div>
                    </div> <!-- container-fluid -->

                </div> <!-- content -->

                <footer class="footer">
                    <!--© 2018 Agroxa <span class="d-none d-sm-inline-block">- Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand.</span>-->
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- Parsley js -->
        <script src="../plugins/parsleyjs/parsley.min.js"></script>

        <!-- App js -->
        <script src="js/script.js"></script>
        <script src="assets/js/app.js"></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/fixedcolumns/3.3.2/js/dataTables.fixedColumns.min.js"></script>
        
        <script>
            
//              $(function() {
//    $(".preload").fadeOut(3000, function() {
//        $(".content").fadeIn(4000);        
//    });
//});
$(document).ready(function() {
    $(".preload").fadeOut(1000, function() {
        $(".content").fadeIn(500);        
    });
    });
            $(document).ready(function() {
                $('form').parsley();
            });
            
            
            $(document).ready(function() {
    var table = $('#example').DataTable( {
        initComplete: function () {
            this.api().columns([1,2,3,4,5,6,7]).every( function () {
                var column = this;
                var select = $('<select><option value=""></option></select>')
//                    .appendTo( $(column.footer()).empty() )
            .appendTo( $(column.header()) )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
//                    select.append( '<option value="'+d+'">'+d+'</option>' )
select.append('<option value="' + d + '">' + d.substr(0,10) + '</option>')

                } );
                
            } );
            
        },
        
        scrollY:        "300px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        fixedColumns:   {
            leftColumns:1,
            rightColumns: 1
        }
    } );
} );
            
//            $(document).ready(function() {
//    $('#example').DataTable( {
//        initComplete: function () {
//            this.api().columns([1,2,3,4,5,6,7]).every( function () {
//                var column = this;
//                var select = $('<select><option value=""></option></select>')
////                    .appendTo( $(column.footer()).empty() )
//            .appendTo( $(column.header()) )
//                    .on( 'change', function () {
//                        var val = $.fn.dataTable.util.escapeRegex(
//                            $(this).val()
//                        );
//                        column
//                            .search( val ? '^'+val+'$' : '', true, false )
//                            .draw();
//                    } );
// 
//                column.data().unique().sort().each( function ( d, j ) {
////                    select.append( '<option value="'+d+'">'+d+'</option>' )
//select.append('<option value="' + d + '">' + d.substr(0,10) + '</option>')
//
//                } );
//                
//            } );
//            
//        },
////        "scrollX": true,
//'dom':'<"c8tableTools01"Bf><"c8tableBody"t><"c8tableTools02"lipr>',
//            'autoWidth':true,
////            fixedColumns:   {
////            leftColumns: 2
////        }
//            // 'scrollX': 'true',
//            // 'scrollY': '850px',
//            // 'scrollCollapse': true,
//    } );
////    new $.fn.dataTable.FixedColumns( table, {
////        leftColumns: 2
////    } );
////        table.column(4).visible(false);
////    table.column(5).visible(false);
////    table.column(6).visible(false);
////    table.column(18).visible(false);
//    
//} );

$(document).ready(function() {
    $('#example1').DataTable();
});
$(document).ready(function() {
    $('#example2').DataTable();
});
    
        </script>
    <script type="text/javascript">
  function GetAssetDetailsN(id)
    {
//        alert(id);
        if(id != '')
        {
            location.href = "update_asset.php?id="+id;
        }
    }
    function GetAssetDetailsNA(id)
    {
//        alert(id);
        if(id != '')
        {
            location.href = "update_asset.php?aid="+id;
        }
    }
    </script>
    </body>

</html>

