<?php
//print_r($_REQUEST);exit;
//require_once '../classes/ajax_district.php';
//require_once '../update_population.php';

include '../classes/config.php';
//require_once 'classes/datetime.php';
//$doctors = new districts();
$provid = $_REQUEST['provid'];
$distid = $_REQUEST['distid'];
//$sql="SELECT pk_id,location_name FROM locations WHERE district_id=" .$file_id. "";
$sql="SELECT
	locations.location_name tehsil,
	locations.location_name uc,
        locations.pk_id pk_id
FROM
	locations
WHERE
	locations.province_id = ".$provid."
            AND locations.district_id = " .$distid. "
AND geo_level_id = 5
GROUP BY 
locations.location_name
ORDER BY
	locations.location_name,
	locations.location_name";
//echo $sql;
//exit();
$result = mysqli_query($conn, $sql);
//$file = $doctors->find_by_district($file_id);
    echo "<option value='0'>Select Location</option>";

while($row=mysqli_fetch_array($result))
{
    echo "<option value='" . $row['pk_id'] . "'>" . $row['tehsil'] . "</option>";
}
