<?php
//print_r($_REQUEST);exit;
//require_once '../classes/ajax_district.php';
//require_once '../update_population.php';

include '../classes/config.php';
//require_once 'classes/datetime.php';
//$doctors = new districts();
$provid = $_REQUEST['provid'];
$distid = $_REQUEST['distid'];
$locid = $_REQUEST['locationid'];
//$sql="SELECT pk_id,location_name FROM locations WHERE district_id=" .$file_id. "";
$sql="SELECT
	warehouses.warehouse_name,
	warehouses.pk_id
FROM
	warehouses
INNER JOIN locations ON warehouses.location_id = locations.pk_id
WHERE
	warehouses.district_id IN (" . implode(', ', $distid). ")
AND warehouses.province_id = $provid
AND warehouses.location_id IN (" . implode(', ', $locid). ") 
ORDER BY
	warehouse_name";
//echo $sql;
//exit();
$result = mysqli_query($conn, $sql);
//$file = $doctors->find_by_district($file_id);
    echo "<option value=0>Select Location</option>";

while($row=mysqli_fetch_array($result))
{
    echo "<option value='" . $row['pk_id'] . "'>" . $row['warehouse_name'] . "</option>";
}
