<?php
// check request
if(isset($_POST['id']) && isset($_POST['id']) != "")
{
    // include Database connection file
//    include("db_connection.php");
    include '../classes/config.php';

    // get user id
    $user_id = $_POST['id'];

    // delete User
    $query = "UPDATE funding_source Set status=1 WHERE id = '$user_id'";
    if (!$result = mysqli_query($conn,$query)) {
        exit(mysql_error());
    }
}
?>

