<?php
//print_r($_REQUEST);exit;
//require_once '../classes/ajax_district.php';
//require_once '../update_population.php';

include '../classes/config.php';
//require_once 'classes/datetime.php';
//$doctors = new districts();
$file_id = $_REQUEST['id'];
//$sql="SELECT pk_id,location_name FROM locations WHERE district_id=" .$file_id. "";
$sql="SELECT
DISTINCT
	locations.pk_id,
	locations.location_name
FROM
	locations
INNER JOIN warehouses ON warehouses.district_id = locations.parent_id
WHERE
	warehouses.province_id = 2
AND warehouses.stakeholder_office_id = 6
AND warehouses.district_id = " .$file_id. "
ORDER BY
	location_name";
//echo $sql;
//exit();
$result = mysqli_query($conn, $sql);
//$file = $doctors->find_by_district($file_id);
    echo "<option value=0>Select Location</option>";

while($row=mysqli_fetch_array($result))
{
    echo "<option value=" . $row['pk_id'] . ">" . $row['location_name'] . "</option>";
}
