<?php
// include Database connection file
//include("db_connection.php");
    include '../classes/config.php';

// check request
if(isset($_REQUEST['id']) != "")
{
    // get User ID
    $user_id = $_POST['id'];
//$sql="SELECT pk_id,location_name FROM locations WHERE district_id=" .$file_id. "";
$sql="SELECT
asset_and_specs.id,
asset_and_specs.category_id,
asset_and_specs.`name`,
asset_and_specs.specification,
MAX(asset_and_specs.specs_year) AS specs_year,
asset_and_specs.inserted_by,
asset_and_specs.inserted_date,
asset_and_specs.updated_by,
asset_and_specs.updated_date,
asset_and_specs.user_id,
asset_and_specs.`status`
FROM
asset_and_specs
WHERE category_id = '$user_id'
GROUP BY `name`";
//echo $sql;
//exit();
$result = mysqli_query($conn, $sql);
//$file = $doctors->find_by_district($file_id);

            while($row=mysqli_fetch_array($result))
            {
                echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
            }
}