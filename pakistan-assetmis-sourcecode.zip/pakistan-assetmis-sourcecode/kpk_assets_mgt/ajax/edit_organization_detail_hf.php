<?php
// include Database connection file
//include("db_connection.php");
    include '../classes/config.php';

// check request
if(isset($_REQUEST['id']) != "")
{
    // get User ID
    $user_id = $_POST['id'];
    $qry = "SELECT * from warehouses WHERE pk_id = $user_id";
    $result = mysqli_query($conn,$qry);
    
    while ($row = mysqli_fetch_assoc($result)) {
        $warehouse_typeid = $row['warehouse_type_id'];
    }
    
    
    if($warehouse_typeid == '3' || $warehouse_typeid == '4')
    {
                $query = "SELECT
	warehouses.pk_id,
	warehouses.warehouse_name,
	warehouses.`status`,
	warehouses.province_id,
	warehouses.district_id,
	warehouses.location_id,
	warehouses.stakeholder_office_id,
	warehouses.warehouse_type_id
FROM
	warehouses
WHERE
	warehouses.province_id = 3
AND warehouses.stakeholder_office_id IN (4, 5, 6)
AND warehouses.pk_id = '$user_id'
ORDER BY
	warehouses.warehouse_name";
//    echo $query;
//    exit();
    if (!$result = mysqli_query($conn,$query)) {
        exit(mysqli_error());
    }
    $response = array();
    if(mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $response = $row;
        }
    }
    else
    {
        $response['status'] = 200;
        $response['message'] = "Data not found!";
    }
    // display JSON data
    echo json_encode($response);
    }
    else {
    // Get User Details
//    $query = "SELECT * FROM warehouses WHERE pk_id = '$user_id'";
    $query = "SELECT
        warehouses.pk_id,
	tehsil.location_name tehsil,
	uc.location_name uc,
	warehouses.warehouse_name,
	warehouses.status,
	warehouses.province_id,
	warehouses.district_id,
	warehouses.location_id,
	uc.parent_id,
        warehouses.stakeholder_office_id
FROM
	warehouses
INNER JOIN locations AS uc ON warehouses.location_id = uc.pk_id
INNER JOIN locations AS tehsil ON uc.parent_id = tehsil.pk_id
WHERE
	warehouses.province_id = 3
AND warehouses.stakeholder_office_id IN (4,5,6)
AND warehouses.pk_id = '$user_id'
ORDER BY
	tehsil.location_name,
	uc.location_name,
	warehouses.warehouse_name";
//    echo $query;
//    exit();
    if (!$result = mysqli_query($conn,$query)) {
        exit(mysqli_error());
    }
    $response = array();
    if(mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $response = $row;
        }
    }
    else
    {
        $response['status'] = 200;
        $response['message'] = "Data not found!";
    }
    // display JSON data
    echo json_encode($response);
}
}
else
{
    $response['status'] = 200;
    $response['message'] = "Invalid Request!";
}
