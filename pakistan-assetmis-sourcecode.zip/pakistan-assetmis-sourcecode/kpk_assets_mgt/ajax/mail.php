<?php include '../classes/config.php';

?>
<html>
   
   <head>
      <title>KPK Assets Management System</title>
   </head>
   
   <body>
      
      <?php
      if(isset($_REQUEST['useremail']))
      {
          $query = "SELECT * FROM user where email='" . $_REQUEST['useremail'] . "'";
          $result = mysqli_query($conn,$query);
        $row = mysqli_fetch_assoc($result);
	$fetch_user_id=$row['email'];
//        $email_id=$row['email_id'];
	$password=$row['password'];
	if($_REQUEST['useremail']==$fetch_user_id) {
          $email = $_REQUEST['useremail'];
//          $desc = $_REQUEST['d_description'];
          $to = "$email";
         $from = "feedback@lmis.gov.pk";
         $subject = "KPK Assest Management";
         
         $message = "<b>Your password is : ".$password."</b>";
         $message .= "<p>First copy this password & Decrypt your password to get password in normal text <b>Click on this url</b> : https://www.cmd5.org/</p>";
         
         $header = "From:".$from."\r\n";
//         $header .= "Cc:afgh@somedomain.com \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         
         $retval = mail ($to,$subject,$message,$header);
         
         if( $retval == true ) {
//            echo "Message sent successfully...";
            ?>
            <script>
                alert("Password sent successfully...");
                window.location.href = "../pages-login.php";
            </script>
            <?php
         }else {
//            echo "Message could not be sent...";
            ?>
            <script>
                alert("Password could not be sent...");
                window.location.href = "../pages-login.php";
            </script>
            <?php
         }
        } else 
        {
            ?>
            <script>
                alert("This email is not registered");
                window.location.href = "../pages-login.php";
            </script>
            <?php
        }
      }
      ?>
      
   </body>
</html>