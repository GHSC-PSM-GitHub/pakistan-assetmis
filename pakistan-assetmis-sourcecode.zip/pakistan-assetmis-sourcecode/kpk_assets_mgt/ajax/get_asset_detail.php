<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php
// include Database connection file
//include("db_connection.php");
    include '../classes/config.php';

    if($_SESSION['uid'] == 7){
        $where = "";
    } else {
        $where = " asset_info.user_id = '".$_SESSION['uid']."'
        AND ";
    }
    
// check request
if(isset($_REQUEST['id']) != "")
{
    // get User ID
    $user_id = $_POST['id'];
    // Get User Details
    $query = "SELECT
	A.*, B.*
FROM
	(
		SELECT
                    asset_info.id,
                    asset_info.asset_id,
                    asset_info.asset_name as assetid,
                    asset_info.serial_no,
                    asset_info.asset_location,
                    asset_info.stock_register,
                    asset_info.assigned_to,
                    asset_info.depreciation,
                    asset_info.asset_status,
                    asset_info.gl_code,
                    asset_info.specification,
                    asset_info.oper_inst,
                    asset_info.detail_desc,
                    asset_info.purchase_year,
                    asset_info.purchase_expiry,
                    asset_info.expire_years,
                    asset_info.purchase_warranty,
                    asset_info.purchase_document_no,
                    asset_info.purchase_price,
                    asset_info.purchase_type_id,
                    asset_info.category_id,
                    asset_info.funding_source_id,
                    asset_info.manufacturer_id,
                    asset_info.supplier_id,
                    asset_info.model,
                    asset_info.file,
                    asset_info.`status`,
                    asset_info.user_id,
                    asset_info.specs_year,
                    SUM(
                            asset_accessorie_mang_info.price
                    ) AS accprice,
                    asset_and_specs.`name` AS asset_name
            FROM
                    asset_info
            INNER JOIN asset_accessorie_mang_info ON asset_info.asset_id = asset_accessorie_mang_info.asset_no
            INNER JOIN asset_and_specs ON asset_info.asset_name = asset_and_specs.id
            WHERE
			$where asset_info.id = $user_id
	) A
LEFT JOIN (
	SELECT
		asset_info.asset_id,
		SUM(
			asset_repair_info.repair_amount
		) AS repamount
	FROM
		asset_info
	INNER JOIN asset_repair_info ON asset_info.asset_id = asset_repair_info.asset_no
	WHERE
    $where asset_info.id = $user_id
) B ON A.asset_id = B.asset_id";
    //echo $query;
    //exit();
    if (!$result = mysqli_query($conn,$query)) {
        exit(mysqli_error());
    }
    $response = array();
    if(mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $response = $row;
        }
    }
    else
    {
        $response['status'] = 200;
        $response['message'] = "Data not found!";
    }
    // display JSON data
    echo json_encode($response);
}
else
{
    $response['status'] = 200;
    $response['message'] = "Invalid Request!";
}
