<?php
//print_r($_REQUEST);exit;
require_once '../classes/ajax_district.php';
//require_once '../update_population.php';

//include '../classes/config.php';
//require_once 'classes/datetime.php';
$doctors = new districts();
$file_id = $_REQUEST['id'];

$file = $doctors->find_by_district($file_id);
    echo "<option value=0>Select District</option>";

while ($row = $file->fetch_array()) {
    echo "<option value=" . $row['pk_id'] . ">" . $row['location_name'] . "</option>";
}