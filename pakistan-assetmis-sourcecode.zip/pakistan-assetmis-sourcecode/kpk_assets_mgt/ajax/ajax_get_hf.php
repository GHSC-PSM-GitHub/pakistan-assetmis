<?php

/**
 * ajax_combos
 * @package reports
 * 
 * @author     Ajmal Hussain
 * @email <ahussain@ghsc-psm.org>
 * 
 * @version    2.2
 * 
 */
//include AllClasses
include '../classes/config.php'; 
//get SkOfcLvl
$skOfcLvl = isset($_REQUEST['SkOfcLvl']) ? $_REQUEST['SkOfcLvl'] : '';
//get provId
$provId = isset($_REQUEST['provId']) ? $_REQUEST['provId'] : '';
//get distId
$distId = isset($_REQUEST['distId']) ? $_REQUEST['distId'] : '';
//get tehsilId
$tehsilId = isset($_REQUEST['tehsilId']) ? $_REQUEST['tehsilId'] : '';
//get ucId
$ucId = isset($_REQUEST['ucId']) ? $_REQUEST['ucId'] : '';
//get provSelId
$provSelId = isset($_REQUEST['provSelId']) ? $_REQUEST['provSelId'] : '';
//get distSelId
//$distSelId =array();
$distSelId = isset($_REQUEST['distSelId']) ? $_REQUEST['distSelId'] : '';
//get tehSelId
$tehSelId = isset($_REQUEST['tehSelId']) ? $_REQUEST['tehSelId'] : '';

$ucSelId = isset($_REQUEST['ucSelId']) ? $_REQUEST['ucSelId'] : '';

if ($skOfcLvl != 1 && empty($provId) && empty($distId)) {
//    echo "<option value=\"all\">All</option>";
//query 
    //gets
    //PkLocID
    //LocName
    $qry = "SELECT
                        locations.location_name,
                        locations.pk_id,
                        locations.province_id,
                        locations.geo_level_id
                        FROM
                        locations
                        WHERE
                        locations.province_id = 3 AND
                        locations.geo_level_id = 2
                        ";
    //query result
//    echo $qry;
//    exit;
    $rsQry = mysqli_query($conn,$qry);
    //fetch data from rsQry
    while ($row = mysqli_fetch_array($rsQry)) {
        if ($provSelId == $row['pk_id']) {
            $sel = "selected='selected'";
        } else {
            $sel = "";
        }
        ?>
        <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['location_name']; ?></option>
        <?php
    }
}
if ($skOfcLvl != 1 && !empty($provId) && empty($distSelId) && empty($tehSelId) && empty($ucSelId)) {
    echo "<option value=\"all\">All</option>";
    //query 
    //gets
    //PkLocID
    //LocName
    $qry = "SELECT
                    locations.location_name,
                    locations.pk_id,
                    locations.province_id,
                    locations.geo_level_id
                    FROM
                    locations
                    WHERE
                    locations.province_id = $provId AND
                    locations.geo_level_id = 4
                ";
//    echo $qry;
//    exit;
    //query result
    $rsQry = mysqli_query($conn,$qry);
    //fetch data from rsQry
    while ($row = mysqli_fetch_array($rsQry)) {
        if ($distSelId == $row['pk_id']) {
            $sel = "selected='selected'";
        } else {
            $sel = "";
        }
        ?>
        <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['location_name']; ?></option>
        <?php
    }
}
if ($skOfcLvl != 1 && !empty($distSelId) && empty($tehSelId) && empty($ucSelId)) {
    echo "<option value=\"all\">All</option>";
    //query
    //gets
    //PkLocID
    //LocName
    $qry = "SELECT
	locations.location_name tehsil,
	locations.location_name uc,
        locations.pk_id pk_id
FROM
	locations
WHERE
	locations.province_id = $provId
            AND locations.district_id IN (" . implode(', ', $distSelId). ")
AND geo_level_id = 5
GROUP BY 
locations.location_name
ORDER BY
	locations.location_name,
	locations.location_name";
    echo $qry;
//    exit;
    //query result
    $rsQry = mysqli_query($conn,$qry) or die();
    //fetch data from rsQry
    while ($row = mysqli_fetch_array($rsQry)) {
        if ($tehSelId == $row['pk_id']) {
            $sel = "selected='selected'";
        } else {
            $sel = "";
        }
        ?>
        <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['tehsil']; ?></option>
        <?php
    }
}
if ($skOfcLvl != 1 && !empty($tehSelId) && empty($ucSelId)) {
    echo "<option value=\"all\">All</option>";
      $qry = "SELECT
	locations.location_name tehsil,
	locations.location_name uc,
        locations.pk_id pk_id
FROM
	locations
WHERE
	locations.province_id = $provId
            AND locations.district_id IN (" . implode(', ', $distSelId). ")
AND locations.parent_id IN (" . implode(', ', $tehSelId). ") 
AND geo_level_id = 6
GROUP BY 
locations.location_name
ORDER BY
	locations.location_name,
	locations.location_name";
    echo $qry;
//    exit;
    //query result
    $rsQry = mysqli_query($conn,$qry) or die();
    //fetch data from rsQry
    while ($row = mysqli_fetch_array($rsQry)) {
        if ($tehSelId == $row['pk_id']) {
            $sel = "selected='selected'";
        } else {
            $sel = "";
        }
        ?>
        <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['uc']; ?></option>
        <?php
    }
}
if ($skOfcLvl != 1 && !empty($ucSelId)) {
    echo "<option value=\"all\">All</option>";
    $qry = "SELECT
	warehouses.warehouse_name,
	warehouses.pk_id
FROM
	warehouses
INNER JOIN locations ON warehouses.location_id = locations.pk_id
WHERE
	warehouses.district_id IN (" . implode(', ', $distSelId). ")
AND warehouses.province_id = $provId
AND warehouses.location_id IN (" . implode(', ', $ucSelId). ") 
ORDER BY
	warehouse_name";
    echo $qry;
//    exit;
    $rsQry = mysqli_query($conn,$qry) or die();
    //fetch data from rsQry
    while ($row = mysqli_fetch_array($rsQry)) {
        if ($tehSelId == $row['pk_id']) {
            $sel = "selected='selected'";
        } else {
            $sel = "";
        }
        ?>
        <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['warehouse_name']; ?></option>
        <?php
    }
}
