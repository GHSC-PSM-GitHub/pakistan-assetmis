<?php
//print_r($_REQUEST);exit;
//require_once '../classes/ajax_district.php';
//require_once '../update_population.php';

include '../classes/config.php';
//require_once 'classes/datetime.php';
//$doctors = new districts();
$provid = $_REQUEST['provid'];
$distid = $_REQUEST['distid'];
$locatinid = $_REQUEST['locationid'];
//$sql="SELECT pk_id,location_name FROM locations WHERE district_id=" .$file_id. "";
//$sql="SELECT
//	locations.location_name tehsil,
//	locations.location_name uc,
//        locations.pk_id pk_id
//FROM
//	locations
//WHERE
//	locations.province_id = $provid
//            AND locations.district_id = $distid
//AND locations.location_id = $locatinid
//AND geo_level_id = 6
//GROUP BY 
//locations.location_name
//ORDER BY
//	locations.location_name,
//	locations.location_name";
$sql = "SELECT
warehouses.warehouse_name,
warehouses.pk_id AS pk_id,
locations.pk_id AS locpkid,
locations.location_name,
locations.district_id,
locations.province_id,
locations.parent_id,
locations.geo_level_id
FROM
warehouses
INNER JOIN locations ON warehouses.location_id = locations.pk_id
WHERE
locations.geo_level_id = 6 AND
locations.pk_id = $locatinid AND
locations.province_id = $provid AND
locations.district_id = $distid
";
echo $sql;
//exit();
$result = mysqli_query($conn, $sql);
//$file = $doctors->find_by_district($file_id);
    echo "<option value=0>Select Location</option>";

while($row=mysqli_fetch_array($result))
{
    echo "<option value='" . $row['pk_id'] . "'>" . $row['location_name'] . "</option>";
}
