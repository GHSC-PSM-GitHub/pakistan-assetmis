<?php
    include 'classes/config.php';
//    $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
//                        $last_id = $row['MAX(id)'];
//                    }
    if(isset($_REQUEST['login_id'])) {

    //get the name and comment entered by user
    $loginid = $_REQUEST['login_id'];
    $email = $_REQUEST['email'];
    //connect to the database
//    $dbc = mysqli_connect('host', 'username', 'password', 'dbname') or die('Error connecting to MySQL server');
    $check=mysqli_query($conn,"select * from user where login_id='$loginid' || email='$email'");
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
        $response   =   array("match"=>"0");
       echo json_encode($response);
   } 
   else {  
    
        if(!empty($_REQUEST['id']))
    {
                $rid = $_REQUEST['id'];
                $rlevel = $_REQUEST['role_level'];
                $loginid = $_REQUEST['login_id'];
                $password = md5($_REQUEST['password']);
                $uname = $_REQUEST['user_name'];
                $email = $_REQUEST['email'];
                $phone = $_REQUEST['phone'];
                $address = $_REQUEST['address'];
                
                $query = "UPDATE user SET user_role_id='$rlevel',username='$uname',password='$password',login_id='$loginid',email='$email',phone='$phone',address='$address' WHERE id='$rid'";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
        $response   =   array("chkid"=>"1");
       echo json_encode($response);
    }   
    else{
    $rid =  mt_rand(10000000, 99999999);
//		$rid = $_REQUEST['role_id'];
                $rlevel = $_REQUEST['role_level'];
                $loginid = $_REQUEST['login_id'];
                $password = md5($_REQUEST['password']);
                $uname = $_REQUEST['user_name'];
                $email = $_REQUEST['email'];
                $phone = $_REQUEST['phone'];
                $address = $_REQUEST['address'];
                
                $query = "INSERT INTO user (user_role_id,username,password,email,phone,address,login_id,status)
                VALUES ('$rlevel','$uname', '$password','$email','$phone','$address','$loginid','1')";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
        $response   =   array("chkid"=>"0");
       echo json_encode($response);
    }
    
    }
}
?>

<?php
if(isset($_POST['operation']))
{ ?>
<table id="example" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Username</th>
                                                        <th>User Role</th>
                                                        <th>Action</th>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                `user`.id,
                                                                `user`.username,
                                                                `user`.`password`,
                                                                `user`.email,
                                                                `user`.phone,
                                                                `user`.address,
                                                                `user`.login_id,
                                                                `user`.user_role_id,
                                                                role.role_name
                                                        FROM
                                                        `user`
                                                        INNER JOIN role ON `user`.user_role_id = role.id
                                                        Order by user.id";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['role_name']; ?></td>
            <td>
                <button id="<?php echo $row["id"]; ?>" onclick="UpdateUser(this.id)" class="btn btn-success updatebtn">Update</button>
            </td>
    	</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
    </script>

<?php
}    
?>
