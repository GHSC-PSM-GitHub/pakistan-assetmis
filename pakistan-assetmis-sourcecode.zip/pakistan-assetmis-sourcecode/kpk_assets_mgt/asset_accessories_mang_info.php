<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php
    include 'classes/config.php';
//    $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
//                        $last_id = $row['MAX(id)'];
//                    }
            if(isset($_REQUEST['asset_id1']) && $_REQUEST['asset_id1'] != '')
    {
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
                $ref_id = $_REQUEST['acc_ref_id'];
                $date = $_REQUEST['acc_date'];
                $detail = $_REQUEST['acc_description'];
                $sup_by = $_REQUEST['acc_sup_by'];
                $acc_price = $_REQUEST['acc_price'];
                $acc_quantity = $_REQUEST['acc_quantity'];
                $acc_status = $_REQUEST['acc_status'];
                $acc_detail = $_REQUEST['acc_detail'];
                $id = $_REQUEST['asset_id1'];
//                $asset_id = $_REQUEST['asset_id'];
//		$query = "INSERT INTO patient_table (registration_date,name,cnic,gender,age,contact,email,lab,nationality,address,from_c,to_c,arrive,p_id) VALUES ('$registration_date','$name' ,'$cnic','$gender','$age','$contact','$email','$lab','$nationality','$address','$from','$to','$arrive','$p_id')";
                
                $query = "INSERT INTO asset_accessorie_mang_info (ref_no,asset_no, date, description,supplied_by,price,quantity,status,comment,inserted_by,inserted_date,updated_by,updated_date)
                VALUES ('$ref_id','$id', '$date', '$detail','$sup_by','$acc_price','$acc_quantity','$acc_status','$acc_detail','$insertedby','$insertedtime','$insertedby','$insertedtime')";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
        echo "<script type='text/javascript'> document.location = 'update_asset.php?aid=$id#timeline'; </script>";
	 exit;
                    
    }   
    else{
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
		$ref_id = $_REQUEST['acc_ref_id'];
                $date = $_REQUEST['acc_date'];
                $detail = $_REQUEST['acc_description'];
                $sup_by = $_REQUEST['acc_sup_by'];
                $acc_price = $_REQUEST['acc_price'];
                $acc_quantity = $_REQUEST['acc_quantity'];
                $acc_status = $_REQUEST['acc_status'];
                $acc_detail = $_REQUEST['acc_detail'];
                $asset_id = $_REQUEST['asset_id'];
//		$query = "INSERT INTO patient_table (registration_date,name,cnic,gender,age,contact,email,lab,nationality,address,from_c,to_c,arrive,p_id) VALUES ('$registration_date','$name' ,'$cnic','$gender','$age','$contact','$email','$lab','$nationality','$address','$from','$to','$arrive','$p_id')";
                
                $query = "INSERT INTO asset_accessorie_mang_info (ref_no,asset_no, date, description,supplied_by,price,quantity,status,comment,inserted_by,inserted_date,updated_by,updated_date)
                VALUES ('$ref_id','$asset_id', '$date', '$detail','$sup_by','$acc_price','$acc_quantity','$acc_status','$acc_detail','$insertedby','$insertedtime','$insertedby','$insertedtime')";
                
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
        echo "<script type='text/javascript'> document.location = 'asset_form.php?id=$asset_id#timeline'; </script>";
	 exit;            
    }
?>
