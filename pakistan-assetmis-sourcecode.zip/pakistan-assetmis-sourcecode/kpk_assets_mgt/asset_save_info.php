<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php
    include 'classes/config.php';
    $uploadedFile = ''; 
    $uploadDir = './uploads/'; 
    if(!empty($_FILES["myfile"]["name"])){ 
                 
                // File path config 
                $fileName = basename($_FILES["myfile"]["name"]); 
                $targetFilePath = $uploadDir . $fileName; 
                $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION); 
                 
                // Allow certain file formats 
                $allowTypes = array('pdf', 'doc', 'docx', 'jpg', 'png', 'jpeg'); 
                if(in_array($fileType, $allowTypes)){ 
                    // Upload file to the server 
                    if(move_uploaded_file($_FILES["myfile"]["tmp_name"], $targetFilePath)){ 
                        $uploadedFile = $fileName; 
                    } 
                } 
            } 
    
   if(isset($_REQUEST['asset_name'])) {

    //get the name and comment entered by user
    $aname = $_POST['asset_name'];
    $model = $_REQUEST['model'];
    $po_no = $_REQUEST['po_no'];
    $loc_of_asset = $_REQUEST['loc_of_asset'];
    $ass_to = $_REQUEST['ass_to'];
    $checkrows = 0;
    //connect to the database
//    $dbc = mysqli_connect('host', 'username', 'password', 'dbname') or die('Error connecting to MySQL server');
    if(isset($_REQUEST['id']) && $_REQUEST['id'] != '')
    {
    $check=mysqli_query($conn,"select * from asset_info where asset_name='$aname' AND model='$model' AND purchase_document_no='$po_no' AND asset_location='$loc_of_asset' AND assigned_to='$ass_to' AND user_id = '".$_SESSION['uid']."' AND id NOT IN ('".$_REQUEST['id']."')");
//    echo $check;
//    exit;
    $checkrows=mysqli_num_rows($check);
    }
//    else 
//    {
//    $check=mysqli_query($conn,"select * from asset_info where asset_name='$aname' AND model='$model' AND purchase_document_no='$po_no' AND asset_location='$loc_of_asset' AND assigned_to='$ass_to' AND user_id = '".$_SESSION['uid']."'");
//    $checkrows=mysqli_num_rows($check);
//    }
    
   if($checkrows>0) { 
       
    $response   =   array("match"=>"0");
       echo json_encode($response);
 } 
   else {   
    
    if(isset($_REQUEST['id']) && $_REQUEST['id'] != '')
    {
                date_default_timezone_set('Asia/Karachi');
                $updatedtime = date('Y-m-d H:i:s'); 
                $updatedby = $_SESSION['username'];
                $id = $_REQUEST['id'];
                $asset_name = $_REQUEST['asset_name'];
                $category = $_REQUEST['category'];
                $manufacturer = $_REQUEST['manufacturer'];
                $model = $_REQUEST['model'];
                $supplier = $_REQUEST['supplier'];
                $serial_no = $_REQUEST['serial_no'];
                $funding_source = $_REQUEST['funding_source'];
                $p_year = $_REQUEST['p_year'];
                $expiry = $_REQUEST['expiry'];
                $warranty = $_REQUEST['warranty'];
		$purchase_type = $_REQUEST['purchase_type'];
		$po_no = $_REQUEST['po_no'];
                $p_price = $_REQUEST['p_price'];
                $loc_of_asset = $_REQUEST['loc_of_asset'];
                $stock_reg = $_REQUEST['stock_reg'];
                $ass_to = $_REQUEST['ass_to'];
                $depreciation = $_REQUEST['depreciation'];
                $asset_status = $_REQUEST['asset_status'];
                $gl_code = $_REQUEST['gl_code'];
                $specification = $_REQUEST['specification'];
                $specsyear = $_REQUEST['specs_year'];
                $instructions = $_REQUEST['instructions'];
                $d_description = $_REQUEST['d_description'];
                $cscale = $_REQUEST['scale_name'];
//                $fileupload1 = basename($_FILES["myfile"]["name"]);
                
                $query = "UPDATE asset_info SET asset_name='$asset_name',category_id='$category',manufacturer_id='$manufacturer',model='$model',supplier_id='$supplier',serial_no='$serial_no',"
                        . "funding_source_id='$funding_source',purchase_year='$p_year',expire_years='$expiry',purchase_warranty='$warranty',purchase_type_id='$purchase_type',purchase_document_no='$po_no',"
                        . "purchase_price='$p_price',asset_location='$loc_of_asset',stock_register='$stock_reg',assigned_to='$ass_to',depreciation='$depreciation',asset_status='$asset_status',gl_code='$gl_code'"
                        . ",specification='$specification',oper_inst='$instructions',detail_desc='$d_description',updated_by = '$updatedby',updated_date = '$updatedtime',file='".$uploadedFile."',specs_year='".$specsyear."',currency_scale='".$cscale."' WHERE id=$id"; 
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
        $response   =   array("id"=>"$id");
       echo json_encode($response);
    }   
    else{
//              $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
////                        $last_id = $row['MAX(id)'];
//                    }
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
                 $last_id =  mt_rand(10000000, 99999999);
		$asset_name = $_REQUEST['asset_name'];
                $category = $_REQUEST['category'];
                $manufacturer = $_REQUEST['manufacturer'];
                $model = $_REQUEST['model'];
                $supplier = $_REQUEST['supplier'];
                $serial_no = $_REQUEST['serial_no'];
                $funding_source = $_REQUEST['funding_source'];
                $p_year = $_REQUEST['p_year'];
                $expiry = $_REQUEST['expiry'];
                $warranty = $_REQUEST['warranty'];
		$purchase_type = $_REQUEST['purchase_type'];
		$po_no = $_REQUEST['po_no'];
                $p_price = $_REQUEST['p_price'];
                $loc_of_asset = $_REQUEST['loc_of_asset'];
                $stock_reg = $_REQUEST['stock_reg'];
                $ass_to = $_REQUEST['ass_to'];
                $depreciation = $_REQUEST['depreciation'];
                $asset_status = $_REQUEST['asset_status'];
                $gl_code = $_REQUEST['gl_code'];
                $specification = $_REQUEST['specification'];
                $instructions = $_REQUEST['instructions'];
                $d_description = $_REQUEST['d_description'];
                $cscale = $_REQUEST['scale_name'];
//                $fileupload1 = basename($_FILES["myfile"]["name"]);
                
                
//                $fileupload1 = $_FILES['myfile']['name'];
//
//                // destination of the file on the server
//                $destination = 'uploads/' . $fileupload1;
//
//                // get the file extension
//                $extension = pathinfo($fileupload1, PATHINFO_EXTENSION);
//
//                // the physical file on a temporary uploads directory on the server
//                $file = $_FILES['myfile']['tmp_name'];
//
//                
                $userid = $_SESSION['uid'];
                $specsyear = $_REQUEST['specs_year'];
//                if (move_uploaded_file($file, $destination)) {
                $query = "INSERT INTO asset_info (asset_id, asset_name, serial_no,asset_location,stock_register,assigned_to,depreciation,asset_status,gl_code,specification,oper_inst,detail_desc,category_id,manufacturer_id,funding_source_id,supplier_id,purchase_type_id,purchase_year,expire_years,purchase_warranty,purchase_document_no,purchase_price,model,user_id,inserted_by,inserted_date,updated_by,updated_date,file,specs_year,currency_scale)
                VALUES ('$last_id', '$asset_name', '$serial_no','$loc_of_asset','$stock_reg','$ass_to','$depreciation','$asset_status','$gl_code','$specification','$instructions','$d_description','$category','$manufacturer','$funding_source','$supplier','$purchase_type', '$p_year', '$expiry','$warranty', '$po_no', '$p_price','$model','$userid','$insertedby','$insertedtime','$insertedby','$insertedtime','".$uploadedFile."','$specsyear','$cscale')";
//                }
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
       $response   =   array("lastid"=>"$last_id");
       echo json_encode($response);
        }
   }
   
}
?>
