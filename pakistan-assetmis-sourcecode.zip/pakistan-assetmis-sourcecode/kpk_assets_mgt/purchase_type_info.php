<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php
    include 'classes/config.php';
//    $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
//                        $last_id = $row['MAX(id)'];
//                    }
    
    if(isset($_POST['pur_type_name'])) {

    //get the name and comment entered by user
   $pur_type_name = $_REQUEST['pur_type_name'];

    //connect to the database
//    $dbc = mysqli_connect('host', 'username', 'password', 'dbname') or die('Error connecting to MySQL server');
    $check=mysqli_query($conn,"select * from purchase_type where name='$pur_type_name' && user_id = '".$_SESSION['uid']."'");
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) { 
         $response   =   array("match"=>"0");
       echo json_encode($response);
   } 
   else {  
    
    $id=$_REQUEST['id'];
        if($_REQUEST['id'] != '')
    {
                date_default_timezone_set('Asia/Karachi');
                $updatedtime = date('Y-m-d H:i:s'); 
                $updatedby = $_SESSION['username'];
		$pur_type_name = $_REQUEST['pur_type_name'];
//		$id = $_REQUEST['id'];
		$query = "UPDATE purchase_type SET name='$pur_type_name',updated_by = '$updatedby',updated_date = '$updatedtime' WHERE id=$id";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
                   $response   =   array("chkid"=>"1");
       echo json_encode($response);
	}
else if($_SESSION['userid'] != '4' && $_SESSION['userid'] != '6' ){
                $pur_type_name = $_REQUEST['pur_type_name'];
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
//		$query = "INSERT INTO patient_table (registration_date,name,cnic,gender,age,contact,email,lab,nationality,address,from_c,to_c,arrive,p_id) VALUES ('$registration_date','$name' ,'$cnic','$gender','$age','$contact','$email','$lab','$nationality','$address','$from','$to','$arrive','$p_id')";
                $uid = $_SESSION['uid'];
                $query = "INSERT INTO purchase_type (name,status,user_id,inserted_by,inserted_date,updated_by,updated_date)
                VALUES ('$pur_type_name','1','$uid','$insertedby','$insertedtime','$insertedby','$insertedtime')";
                
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            $response   =   array("chkid"=>"0");
       echo json_encode($response);
 } 
 else if($_SESSION['userid'] == '4' || $_SESSION['userid'] == '6' && isset($_REQUEST['pur_type_name'])){
         $response   =   array("match"=>"2");
            echo json_encode($response);
     }
    }
}
?>

<?php
if(isset($_POST['operation']))
{ ?>
        <table id="example" class="display" style="width:100%;background: #33B23F;">
        <thead style="color: white;">
                                                <tr>
							<th>Sr No.</th>
                                                        <th>Name</th>
                                                        <th>Created By</th>
                                                        <th>Created Date</th>
                                                        <th>Modified By</th>
                                                        <th>Modified Date</th>
             <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
                                                        <th>Action</th>
                                                        <th>Status</th>
            <?php }
            ?>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
                                                $query = "SELECT
                                                                purchase_type.id,
                                                                purchase_type.`name`,
                                                                purchase_type.`status`,
                                                                purchase_type.inserted_by,
                                                                purchase_type.updated_by,
                                                                purchase_type.inserted_date,
                                                                purchase_type.updated_date
                                                                FROM
                                                                purchase_type
                                                                WHERE user_id = '".$_SESSION['uid']."' Order by purchase_type.id";

//	if (!$result = mysql_query($query)) {
//        exit(mysql_error());
//    }
$result = mysqli_query($conn, $query);
    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['inserted_by']; ?></td>
            <td><?php echo $row['inserted_date']; ?></td>
            <td><?php echo $row['updated_by']; ?></td>
            <td><?php echo $row['updated_date']; ?></td>
             <?php if($_SESSION["userid"] == '0' || $_SESSION["userid"] == '' || $_SESSION["userid"] == '1' || $_SESSION["userid"] == '4' || $_SESSION["userid"] == '6')
                {
            ?>
            <td>
                     <button id="<?php echo $row["id"]; ?>" onclick="edit_purchase_detail(this.id)" class="btn btn-success">Update</button>
            </td>
            <td>
                <?php if($row['status'] == 1)
               {?>
                <button onclick="activepurchase(<?php echo $row['id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactivepurchase(<?php echo $row['id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>
            <?php }
            ?>
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
             </table>
<script>
    $(document).ready(function() {
    $('#example').DataTable({
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
} );
    </script>

<?php
}    
?>
