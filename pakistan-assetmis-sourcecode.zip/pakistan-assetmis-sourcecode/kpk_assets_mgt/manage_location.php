<?php 
    include 'classes/config.php';
    $te=0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.JPG">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
        
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
        <!-- Bootstrap CSS File  -->
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

<style>
/*    .content {display:none;}
.preload { width:100px;
    height: 100px;
    position: fixed;
    top: 50%;
    left: 50%;}

    .center_div{
    margin: 0 auto;
    width:80%  value of your choice which suits your alignment 
}*/
/*.ui-datepicker-calendar {
   display: none;
}*/

    </style>
<!--            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <h1>
                    Manage Locations
                </h1>    
                            </nav>-->
<?php        
        $res="SELECT pk_id,geo_level_name FROM geo_levels";
        $result3 = mysqli_query($conn, $res);
        
        $res1="SELECT pk_id,geo_level_name FROM geo_levels";
        $result1 = mysqli_query($conn, $res1);
        
        
        $res3="SELECT pk_id,geo_level_name FROM geo_levels";
        $result4 = mysqli_query($conn, $res3);
        
        $res4="SELECT pk_id,geo_level_name FROM geo_levels";
        $res6="SELECT pk_id,location_name FROM locations WHERE province_id=2 AND geo_level_id=4";
        $result7 = mysqli_query($conn, $res6);
        ?>
</head>
<body>

<!-- Content Section -->
<!--<div class="container">-->
    

    <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <a href="index.php" class="logo">
                        <span>
                            <img src="assets/images/logo.png" alt="" >
                        </span>
                        <i>
                            <img src="assets/images/logo-sm.png" alt="" height="22">
                        </i>
                    </a>
                </div>

                <nav class="navbar-custom">
                    <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                            <button class="button-menu-mobile open-left waves-effect waves-light">
                                <i class="mdi mdi-menu"></i>
                            </button>
                        </li>                        
                        <li class="d-none d-sm-block">
                            <div class="dropdown pt-3 d-inline-block">
                                <a class="waves-effect waves-light" href="#"  aria-haspopup="true" aria-expanded="false">
                                    <h4 style="color: white;">Configuration Management System</h4>
                                </a>
                                
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </li>
                    </ul>

                </nav>

            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php include 'left_menu.php';?>
            <!-- Left Sidebar End -->
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">
                <!-- Start content -->
<!--                <div class="content">
                    <div class="container-fluid">-->
<!--<div class="preload"><img src="http://i.imgur.com/KUJoe.gif">
</div>-->
<!--<div class="content">-->
    <div class="row">
        <div class="col-md-12">
            <div class="pull-right">
                <button class="btn btn-success" data-toggle="modal" data-target="#add_new_record_modal">Add New Record</button>
                <!--<a href="update_population.php?logout='1'" ><button type="button" class="btn btn-success">Logout</button></a>-->
            </div>
        </div>
    </div>
            <h3>Records:</h3>
            
             <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
							<th>No.</th>
                                                        <th>Province</th>
							<th>Location Name</th>
                                                        <th>Action</th>
                                                        <th>Action</th>
						</tr>
             </thead>
        <tbody>                                   
                                                <?php
//                                                    $q = $_REQUEST['id'];
                                                $query = "SELECT
	locations.status,
	prov.location_name province,
	locations.pk_id,
	locations.location_name
FROM
	locations
INNER JOIN locations AS prov ON locations.province_id = prov.pk_id
INNER JOIN geo_levels ON geo_levels.pk_id = locations.geo_level_id
WHERE
	locations.province_id = 3
AND locations.pk_id NOT IN (3)
ORDER BY
	locations.location_name";

	if (!$result = mysqli_query($conn,$query)) {
        exit(mysqli_error());
    }

    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
            ?>
            
        <tr>
            <td><?php echo $number; ?></td>
            <td><?php echo $row['province']; ?></td>
            <td><?php echo $row['location_name']; ?></td>

            <td>
                    <button onclick="GetUserDetails(<?php echo $row['pk_id']; ?>)" class="btn btn-warning">Update</button>
            </td>
            <td>
                   <?php if($row['status'] == 1)
               {?>
                <button onclick="active1(<?php echo $row['pk_id']; ?>)" class="btn btn-success">Active</button>
               <?php } else {?>
                <button onclick="inactive1(<?php echo $row['pk_id']; ?>)" class="btn btn-danger">InActive</button>
               <?php } ?>
            </td>
    		</tr>
<?php
$number++;
        }
    }
?>

        </tbody>
           </table>
            <!--</div>-->
<!--</div>-->
<!-- /Content Section -->
<!-- Bootstrap Modals -->
<!-- Modal - Add New Record/User -->
<div class="modal fade" id="add_new_record_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Add New Record</h4>
            </div>
            <div class="modal-body">
            <div class="form-group">
            <label for="validationDefault03" for="geo_lvl_name">Geo Level Name</label>

            <select class="form-control" id="geo_lvl_name" name="geo_lvl_name">
                <option>Select Office</option>
                          <?php  
                        while($row=mysqli_fetch_array($result3))
            {
            ?>
            <option value="<?php echo $row['pk_id'];?>"><?php echo $row['geo_level_name']; ?></option>
            <?php
            }
            ?>   
            </select>
                </div>            
                <div class="form-group" id="province11">
            <label for="validationDefault03" for="province">Province Name</label>
            <select class="form-control" id="province" name="province">
            <option>Select Province</option>
            <?php echo getProvinceCombo(); ?>
            </select>
                </div>
                <div class="form-group" id="districts11">
            <label for="validationDefault03" for="districts">District Name</label>
            <select class="form-control" id="districts" name="districts">
            <option>Select District</option>
            <?php // echo getDistrictCombo(); ?>
            </select>
                </div>
<!--            <div class="form-group">
            <label for="validationDefault03" for="location_typ_name">Location Type Name</label>
            <select class="form-control" id="location_typ_name" name="location_typ_name">
            <option>Select Location</option>
            <?php // echo getDistrictCombo(); ?>

            </select>
                </div>-->
            <div class="form-group" id="parent_name11">
            <label for="validationDefault03" for="parent_name">Tehsil</label>
            <select class="form-control" id="parent_name" name="parent_name">
            <option>Select Name</option>
                                          //<?php  
//                        while($row=mysqli_fetch_array($result1))
//            {
//            ?>
            <!--<option value="//<?php echo $row['pk_id'];?>"><?php echo $row['geo_level_name']; ?></option>-->
            //<?php // echo getDistrictCombo(); ?>
                //<?php
//            }
//            ?>      
            </select>
                </div>
            
                <div class="form-group">
                    <label for="location_name">Location Name</label>
                    <input type="text" id="location_name" placeholder="location name" class="form-control"/>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary"  onclick="addRecord()">Add Record</button>
            </div>
        </div>
    </div>
</div>
<!-- // Modal -->

<!-- Modal - Update User details -->
<div class="modal fade" id="update_user_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Update</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
            <label for="validationDefault03" for="geo_lvl_name">Geo Level Name</label>

            <select class="form-control" id="geo_lvl_name1" name="geo_lvl_name">
                          <?php  
                        while($row=mysqli_fetch_array($result4))
            {
            ?>
            <option value="<?php echo $row['pk_id'];?>"><?php echo $row['geo_level_name']; ?></option>
            <?php
            }
            ?>   
            </select>
                </div>
                <div class="form-group" id="province22">
            <label for="validationDefault03" for="province1">Province Name</label>
            <select class="form-control" id="province1" name="province1">
            <option>Select Province</option>
            <?php echo getProvinceCombo(); ?>
            </select>
                </div>
                <div class="form-group" id="districts22">
            <label for="validationDefault03" for="districts">District Name</label>
            <select class="form-control" id="districts1" name="districts">
            <option>Select District</option>
                <div class="form-group" id="parent_name22">
            <label for="validationDefault03" for="parent_name">Tehsil</label>
            <select class="form-control" id="parent_name1" name="parent_name">

            </select>
                </div>
                <div class="form-group">
                    <label for="update_location_name">Location Name</label>
                                         <?php  
//                        while($row=mysqli_fetch_array($resultt))
//            {
            ?>
                    <!--<input type="hidden" id="update_warehouse_name" name="warehouse_name"  value="<?php // echo $roww['pk_id']; ?>" class="form-control"/>-->

                    <input type="text" id="update_location_name" name="location_name" value="" class="form-control"/>
                 <?php
//            }
            ?>   
            </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="UpdateUserDetails()" >Save Changes</button>
                <input type="hidden" id="hidden_user_id">
            </div>
        </div>
    </div>
</div>
</div>
    </div>
</div>
    
<!-- // Modal -->
<!-- Jquery JS file -->
<script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- Parsley js -->
        <script src="../plugins/parsleyjs/parsley.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script src="js/script.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
        <script>
            $(document).ready(function() {
                $('form').parsley();
            });
      $(function() {
    $(".preload").fadeOut(3000, function() {
        $(".content").fadeIn(4000);        
    });
});
$("#province11").hide();
$("#districts11").hide();
$("#parent_name11").hide();
///////////
$("#province22").hide();
$("#districts22").hide();
$("#parent_name22").hide();

$("#geo_lvl_name").change(function () {
    var id = $(this).val();
//    alert(id);
    if(id=='1' || id=='2')
    {
        $("#districts11").hide();
        $("#parent_name11").hide();
        $("#province11").hide();
    }
    if(id=='3' || id=='4')
    {
        $("#districts11").hide();
        $("#parent_name11").hide();
        $("#province11").show();
    }
    if(id=='5')
    {
        $("#parent_name11").hide();
        $("#province11").show();
        $("#districts11").show();
    }
    if(id=='6')
    {
        $("#province11").show();
        $("#districts11").show();
        $("#parent_name11").show();
    }

    
});

$("#geo_lvl_name1").change(function () {
    var id = $(this).val();
//    alert(id);
    if(id=='1' || id=='2')
    {
        $("#districts22").hide();
        $("#parent_name22").hide();
        $("#province22").hide();
    }
    if(id=='3' || id=='4')
    {
        $("#districts22").hide();
        $("#parent_name22").hide();
        $("#province22").show();
    }
    if(id=='5')
    {
        $("#parent_name22").hide();
        $("#province22").show();
        $("#districts22").show();
    }
    if(id=='6')
    {
        $("#province22").show();
        $("#districts22").show();
        $("#parent_name22").show();
    }

    
});
//      $('#check').hide();
     $("#province").change(function () {
               var id = $(this).val();
               $.ajax({
                   url: "ajax/getdistricts.php",
                   method: "POST",
                   data: {id: id},
                   success: function (data) {
                       $('#districts').html(data);
                   }
               });
           });
//           $("#geo_level").change(function () {
//               var id = $(this).val();
//               alert(id); 
//               $.ajax({
////                   url: "manage_location.php",
//                   type: "POST",
//                   data: {id: id},
//                   success: function (data) {
//                       $('#check').html(data);
//                   alert(data);
//                   }
//               });
//           });
        $("#districts").click(function () {
            
            var id = $(this).val();
//            var wh_id;
//            var current_year = moment().format('YYYY');
        //var form = $("#validateSubmitForm").serialize();
            $.ajax({
                url: "ajax/getlocation.php",
                method: "POST",
                data: {id: id},
                success: function (data) {
//                    id = $(this).data("pk_id");
//                    Id = $('#warehouse_name').val();
                                               $('#parent_name').html(data);

//                    $('#ddo_data_html').html(data);
                    
//                    contents();
//                    wh_id = $(this).attr('wh_id');
                }
            });
        });
//                $("#districts").change(function () {
//            var id = $(this).val();
//            $.ajax({
//                url: "ajax/get_tehsil.php",
//                method: "POST",
//                data: {id: id},
//                success: function (data) {
//                                               $('#location').html(data);
//
//                }
//            });
//        });
         $("#province1").change(function () {
               var id = $(this).val();
               $.ajax({
                   url: "ajax/getdistricts.php",
                   method: "POST",
                   data: {id: id},
                   success: function (data) {
                       $('#districts1').html(data);
                   }
               });
           });
        $("#districts1").change(function () {
            
            var id = $(this).val();
//            var wh_id;
//            var current_year = moment().format('YYYY');
        //var form = $("#validateSubmitForm").serialize();
            $.ajax({
                url: "ajax/getlocation.php",
                method: "POST",
                data: {id: id},
                success: function (data) {
//                    id = $(this).data("pk_id");
//                    Id = $('#warehouse_name').val();
                                               $('#parent_name1').html(data);

//                    $('#ddo_data_html').html(data);
                    
//                    contents();
//                    wh_id = $(this).attr('wh_id');
                }
            });
        });
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-75591362-1', 'auto');
    ga('send', 'pageview');
    
$(document).ready(function() {
    $('#example').DataTable( {
        initComplete: function () {
            this.api().columns([ 1, 2,3]).every( function () {
                var column = this;
                var select = $('<select><option value=""></option></select>')
//                    .appendTo( $(column.footer()).empty() )
            .appendTo( $(column.header()) )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
//                    select.append( '<option value="'+d+'">'+d+'</option>' )
select.append('<option value="' + d + '">' + d.substr(0,25) + '</option>')

                } );
            } );
        }
    } );
//        table.column(4).visible(false);
//    table.column(5).visible(false);
//    table.column(6).visible(false);
//    table.column(18).visible(false);
    
} );
//function reloadTable(){
////    var table=$('#example').DataTable();
////    table.ajax.reload();
//}

</script>


</body>
</html>
