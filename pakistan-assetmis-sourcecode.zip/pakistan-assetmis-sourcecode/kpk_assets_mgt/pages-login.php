<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>KPK Assets Management System</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/logo-sm.png">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    </head>

    <body>

<?php
include 'classes/config.php';

session_start();
// If form submitted, insert values into the database.
if (isset($_POST['username'])){
        // removes backslashes
 $username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
 $username = mysqli_real_escape_string($conn,$username);
 $password = stripslashes($_REQUEST['password']);
 $password = mysqli_real_escape_string($conn,$password);
 $password = md5($password);
 //Checking is user existing in the database or not
//        $query = "SELECT * FROM `user` WHERE username='$username'
//and password='".md5($password)."'";
        $query = "SELECT * FROM `user` WHERE login_id='$username'
and password='".$password."'";
        $query = "SELECT
	`user`.id,
	`user`.username,
	`user`.`password`,
	`user`.email,
	`user`.phone,
	`user`.address,
	`user`.login_id,
	`user`.user_role_id,
	`user`.`status`,
	role.id AS rid,
	role.district,
	role.province,
	role.tehsil,
	role.uc,
	role.role_level_id,
	role.hf,
        role.dhq,
        role.access_id
FROM
	`user`
INNER JOIN role ON `user`.user_role_id = role.id
WHERE
	login_id = '$username'
AND `password` = '".$password."'";
//        echo $query;exit;
 $result = mysqli_query($conn,$query) or die(mysql_error());
// $rows = mysqli_num_rows($result);
//        if($rows==1){
            if(mysqli_num_rows($result) > 0)
    {
//    	$number = 1;
        while($row = mysqli_fetch_assoc($result))
    {
     $_SESSION['username'] = $row['username'];
     $_SESSION['userid'] = $row['access_id'];
     $_SESSION['rid'] = $row['rid'];
     $_SESSION['uid'] = $row['id'];
     $_SESSION['did'] = $row['district'];
     $_SESSION['tid'] = $row['tehsil'];
     $_SESSION['ucid'] = $row['uc'];
     $_SESSION['hfid'] = $row['hf'];
     $_SESSION['dhqid'] = $row['dhq'];
     $_SESSION['district'] = array();
     $_SESSION['tehsil'] = array();
     $_SESSION['uc'] = array();
     $_SESSION['hf'] = array();
     $_SESSION['district'] = $row['district'];
     $_SESSION['tehsil'] = $row['tehsil'];
     $_SESSION['uc'] = $row['uc'];
     $_SESSION['hf'] = $row['hf'];
     date_default_timezone_set('Asia/Karachi');
     $_SESSION['starttime'] = date('Y-m-d H:i:s'); 
            // Redirect user to index.php
//     header("Location: index.php");
     echo "<script type='text/javascript'> document.location = 'index.php'; </script>";
	 exit;
         }
    }else{ ?>
             
             
        <!-- Background -->
        <div class="login-page"></div>
        <!-- Begin page -->
        <div class="wrapper-page">

            <div class="card">
                <div class="card-body">

                    <h3 class="text-center m-0">
                        <a href="index.php" class="logo logo-admin"><img src="assets/images/logo.png" alt="logo"></a>
                    </h3>

                    <div class="p-3">
                        <h4 class="text-muted font-18 m-b-5 text-center">KP ASSETS MANAGEMENT SYSTEM</h4>
                        <!--<p class="text-muted text-center">KPK.</p>-->
                        <p style="color: red;text-align: center;">Username/password is incorrect.</p>
                        <form class="form-horizontal m-t-30" action="" method="post" name="login">

                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Enter username">
                            </div>

                            <div class="form-group">
                                <label for="userpassword">Password</label>
                                <input type="password" class="form-control" id="userpassword" name="password" placeholder="Enter password">
                            </div>

                            <div class="form-group row m-t-20">
                                <div class="col-6">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="customControlInline">
                                        <label class="custom-control-label" for="customControlInline">Remember me</label>
                                    </div>
                                </div>
                                <div class="col-6 text-right">
                                    <button class="btn btn-primary w-md waves-effect waves-light" type="submit">Log In</button>
                                </div>
                            </div>

                            <div class="form-group m-t-10 mb-0 row">
                                <div class="col-12 m-t-20">
                                    <a href="pages-recoverpw.php" class="text-muted"><i class="mdi mdi-lock"></i> Forgot your password?</a>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>

<!--            <div class="m-t-40 text-center">
                <p class="text-white-50">Don't have an account ? <a href="pages-register.html" class="text-white"> Signup Now </a> </p>
                <p class="text-muted">© 2018 Agroxa. Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</p>
            </div>-->

        </div>

        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
             
             
  <?php           
             
 }
    }else{
?>        
        
        <!-- Background -->
        <div class="login-page"></div>
        <!-- Begin page -->
        <div class="wrapper-page">

            <div class="card">
                <div class="card-body">

                    <h3 class="text-center m-0">
                        <a href="index.php" class="logo logo-admin"><img src="assets/images/logo.png" alt="logo"></a>
                    </h3>

                    <div class="p-3">
                        <h4 class="text-muted font-18 m-b-5 text-center">KP ASSESTS MANAGEMENT SYSTEM</h4>
                        <!--<p class="text-muted text-center">KPK.</p>-->

                        <form class="form-horizontal m-t-30" action="" method="post" name="login">

                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Enter username">
                            </div>

                            <div class="form-group">
                                <label for="userpassword">Password</label>
                                <input type="password" class="form-control" id="userpassword" name="password" placeholder="Enter password">
                            </div>

                            <div class="form-group row m-t-20">
                                <div class="col-6">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="customControlInline">
                                        <label class="custom-control-label" for="customControlInline">Remember me</label>
                                    </div>
                                </div>
                                <div class="col-6 text-right">
                                    <button class="btn btn-primary w-md waves-effect waves-light" type="submit">Log In</button>
                                </div>
                            </div>

                            <div class="form-group m-t-10 mb-0 row">
                                <div class="col-12 m-t-20">
                                    <a href="pages-recoverpw.php" class="text-muted"><i class="mdi mdi-lock"></i> Forgot your password?</a>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>

<!--            <div class="m-t-40 text-center">
                <p class="text-white-50">Don't have an account ? <a href="pages-register.html" class="text-white"> Signup Now </a> </p>
                <p class="text-muted">© 2018 Agroxa. Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</p>
            </div>-->

        </div>

        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metisMenu.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <script src="../plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
<?php } ?>
    </body>

</html>