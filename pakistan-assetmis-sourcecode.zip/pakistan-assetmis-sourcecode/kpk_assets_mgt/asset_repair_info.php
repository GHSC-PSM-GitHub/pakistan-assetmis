<?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: pages-login.php");
exit(); }
?>
<?php
    include 'classes/config.php';
//    $qry="SELECT MAX(id) FROM asset_info";
//                                $result2 = mysqli_query($conn, $qry);
//                    while ($row = mysqli_fetch_assoc($result2)) {
//                        $last_id = $row['MAX(id)'];
//                    }
    if(isset($_REQUEST['asset_idr']) && $_REQUEST['asset_idr'] != '' && !empty($_REQUEST['id']))
    {
                date_default_timezone_set('Asia/Karachi');
                $updatedtime = date('Y-m-d H:i:s'); 
                $updatedby = $_SESSION['username'];
                $id = $_REQUEST['asset_idr'];
                $aid = $_REQUEST['id'];
                $number = $_REQUEST['repair_ref_no'];
                $date = $_REQUEST['date'];
                $detail = $_REQUEST['repair_detail'];
                $repaired_by = $_REQUEST['repair_by'];
                $repaire_warranty = $_REQUEST['repair_warranty'];
                $repair_amount = $_REQUEST['repair_amount'];
                $repair_detail = $_REQUEST['r_comment'];
                $status = $_REQUEST['rstatus'];
                $quantity = $_REQUEST['rquantity'];
                
                $query = "UPDATE asset_repair_info SET repair_po_no='$number',repair_amount='$repair_amount',date='$date',description='$detail',repaired_by_id='$repaired_by',repair_warrenty='$repaire_warranty',comment='$repair_detail',status='$status',quantity='$quantity',updated_by = '$updatedby',updated_date = '$updatedtime' WHERE id=$aid";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
        echo "<script type='text/javascript'> document.location = 'update_asset.php?id=$id#catchme'; </script>";
	 exit;
    }   
     else if(isset($_REQUEST['asset_idr']) && $_REQUEST['asset_idr'] != '' && empty($_REQUEST['id']))
    {
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
                $id = $_REQUEST['asset_idr'];
                $number = $_REQUEST['repair_ref_no'];
                $date = $_REQUEST['date'];
                $detail = $_REQUEST['repair_detail'];
                $repaired_by = $_REQUEST['repair_by'];
                $repaire_warranty = $_REQUEST['repair_warranty'];
                $repair_amount = $_REQUEST['repair_amount'];
                $repair_detail = $_REQUEST['r_comment'];
                $status = $_REQUEST['rstatus'];
                $quantity = $_REQUEST['rquantity'];
                
                $query = "INSERT INTO asset_repair_info (repair_po_no,asset_no, date, description,repaired_by_id,repair_warrenty,repair_amount,comment,status,quantity,inserted_by,inserted_date,updated_by,updated_date)
                VALUES ('$number','$id', '$date', '$detail','$repaired_by','$repaire_warranty','$repair_amount','$repair_detail','$status','$quantity','$insertedby','$insertedtime','$insertedby','$insertedtime')";
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
        echo "<script type='text/javascript'> document.location = 'update_asset.php?id=$id#catchme'; </script>";
	 exit;
    }   
    else{
                date_default_timezone_set('Asia/Karachi');
                $insertedtime = date('Y-m-d H:i:s'); 
                $insertedby = $_SESSION['username'];
		$number = $_REQUEST['repair_ref_no'];
                $date = $_REQUEST['date'];
                $detail = $_REQUEST['repair_detail'];
                $repaired_by = $_REQUEST['repair_by'];
                $repaire_warranty = $_REQUEST['repair_warranty'];
                $repair_amount = $_REQUEST['repair_amount'];
                $repair_detail = $_REQUEST['r_comment'];
                $asset_id = $_REQUEST['asset_id'];
                $status = $_REQUEST['rstatus'];
                $quantity = $_REQUEST['rquantity'];
//		$query = "INSERT INTO patient_table (registration_date,name,cnic,gender,age,contact,email,lab,nationality,address,from_c,to_c,arrive,p_id) VALUES ('$registration_date','$name' ,'$cnic','$gender','$age','$contact','$email','$lab','$nationality','$address','$from','$to','$arrive','$p_id')";
                
                $query = "INSERT INTO asset_repair_info (repair_po_no,asset_no, date, description,repaired_by_id,repair_warrenty,repair_amount,comment,status,quantity,inserted_by,inserted_date,updated_by,updated_date)
                VALUES ('$number','$asset_id', '$date', '$detail','$repaired_by','$repaire_warranty','$repair_amount','$repair_detail','$status','$quantity','$insertedby','$insertedtime','$insertedby','$insertedtime')";
//                
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
            
        echo "<script type='text/javascript'> document.location = 'asset_form.php?id=$asset_id#accordionEx1'; </script>";
	 exit;
    }
?>
