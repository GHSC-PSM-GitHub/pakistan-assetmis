<?php
session_start();
// Destroying All Sessions
include 'classes/config.php';
$userid = $_SESSION['uid'];
$starttime = $_SESSION['starttime'];
    
if(session_destroy())
{
    date_default_timezone_set('Asia/Karachi');
    $endtime = date('Y-m-d H:i:s'); 
    $query = "INSERT INTO login_logout_time (login_time,logout_time,user_id)
                VALUES ('$starttime', '$endtime', '$userid')";
                
//                echo $query;
//                exit();
		if (!$result = mysqli_query($conn, $query)) {
	        exit(mysql_error()); 
	    }
// Redirecting To Home Page
header("Location: pages-login.php");
}
?>